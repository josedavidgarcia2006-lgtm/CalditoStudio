'use strict';
// Sincroniza los mods publicados por los desarrolladores con la carpeta del juego.
const fs = require('fs');
const path = require('path');
const { downloadFile, sha1File } = require('./download');

const MANAGED = '.caldito-managed.json';

function safeName(file) {
  const base = path.basename(String(file || ''));
  if (!base || base !== file || base.startsWith('.')) throw new Error(`Nombre de archivo no permitido: ${file}`);
  return base;
}

/**
 * - Descarga lo que falta o cuyo SHA-1 no coincide.
 * - Borra lo que el launcher instaló antes y ya no está publicado.
 * - Nunca toca mods que el jugador puso por su cuenta.
 */
async function syncMods(gameDir, mods, onProgress) {
  const modsDir = path.join(gameDir, 'mods');
  await fs.promises.mkdir(modsDir, { recursive: true });
  const managedFile = path.join(gameDir, MANAGED);

  let previous = [];
  try { previous = JSON.parse(await fs.promises.readFile(managedFile, 'utf8')).files || []; } catch {}
  const wanted = new Set(mods.map((m) => safeName(m.file)));
  for (const old of previous) {
    if (!wanted.has(old)) await fs.promises.rm(path.join(modsDir, safeName(old)), { force: true }).catch(() => {});
  }

  let i = 0;
  for (const m of mods) {
    i++;
    const name = safeName(m.file);
    const dest = path.join(modsDir, name);
    onProgress?.({ task: `Comprobando ${m.name || name}`, done: i - 1, total: mods.length });
    let ok = false;
    if (fs.existsSync(dest)) ok = m.sha1 ? (await sha1File(dest)) === m.sha1.toLowerCase() : true;
    if (!ok) {
      onProgress?.({ task: `Descargando ${m.name || name}`, done: i - 1, total: mods.length });
      try {
        await downloadFile(m.url, dest, { sha1: m.sha1 });
      } catch (e) {
        if (!m.mirror) throw e;
        onProgress?.({ task: `Descargando ${m.name || name} (copia del equipo)`, done: i - 1, total: mods.length });
        await downloadFile(m.mirror, dest, { sha1: m.sha1 });
      }
    }
  }
  await fs.promises.writeFile(managedFile, JSON.stringify({ files: [...wanted] }, null, 2));
  onProgress?.({ task: 'Mods al día', done: mods.length, total: mods.length || 1 });
}

/**
 * Sincroniza archivos de configuración publicados (solo dentro de config/).
 * Borra los que el launcher puso antes y ya no están publicados.
 */
async function syncFiles(gameDir, files, onProgress) {
  const managedFile = path.join(gameDir, '.caldito-files.json');
  const safe = (rel) => {
    const norm = path.posix.normalize(String(rel || '')).replace(/^\/+/, '');
    if (!norm.startsWith('config/') || norm.includes('..')) throw new Error(`Ruta de configuración no permitida: ${rel}`);
    return norm;
  };
  let previous = [];
  try { previous = JSON.parse(await fs.promises.readFile(managedFile, 'utf8')).files || []; } catch {}
  const wanted = new Set(files.map((f) => safe(f.path)));
  for (const old of previous) if (!wanted.has(old)) await fs.promises.rm(path.join(gameDir, safe(old)), { force: true }).catch(() => {});
  let i = 0;
  for (const f of files) {
    i++;
    const rel = safe(f.path);
    const dest = path.join(gameDir, rel);
    onProgress?.({ task: `Configuración ${path.basename(rel)}`, done: i - 1, total: files.length });
    let ok = false;
    if (fs.existsSync(dest)) ok = f.sha1 ? (await sha1File(dest)) === f.sha1.toLowerCase() : true;
    if (!ok) await downloadFile(f.url, dest, { sha1: f.sha1 });
  }
  await fs.promises.mkdir(gameDir, { recursive: true });
  await fs.promises.writeFile(managedFile, JSON.stringify({ files: [...wanted] }, null, 2));
}

/** Clave para detectar el mismo mod con otro nombre de archivo (p. ej. otra versión). */
function modKey(file) {
  return String(file || '').toLowerCase().replace(/\.jar$/, '').split(/[-_+](?=v?\d|mc)/)[0];
}

module.exports = { syncMods, syncFiles, safeName, modKey };
