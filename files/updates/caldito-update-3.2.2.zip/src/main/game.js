'use strict';
const fs = require('fs');
const { Client, Authenticator } = require('minecraft-launcher-core');
const { Auth } = require('msmc');
const prefs = require('./prefs');
const store = require('./datastore');
const skins = require('./skins');
const modrinth = require('./modrinth');
const { ensureJava } = require('./java');
const { prepareLoader } = require('./loader');
const { syncMods, syncFiles, modKey } = require('./modpack');
const fancymenu = require('./fancymenu');
const stats = require('./stats');
const { ping } = require('./ping');

let running = null;
const VERSION_RE = /\b1\.\d{1,2}(?:\.\d{1,2})?\b/;

/** Versión efectiva de una instancia: la fija, o la que reporta su servidor. */
async function resolveVersion(inst) {
  if (inst.mcVersion && inst.mcVersion !== 'auto') return inst.mcVersion;
  const known = prefs.raw().detectedVersion || {};
  try {
    const st = await ping(inst.host, inst.port || 25565, 4000);
    const m = VERSION_RE.exec(st.version);
    if (m) { prefs.set({ detectedVersion: { ...(typeof known === 'object' ? known : {}), [inst.id]: m[0] } }); return m[0]; }
  } catch {}
  return (typeof known === 'object' && known[inst.id]) || inst.fallbackVersion || '1.21.1';
}

async function getAuthorization(inst) {
  const session = store.getSession();
  if (!session) throw new Error('Inicia sesión primero.');
  if (inst.authMode !== 'microsoft') { const n = skins.mcName(session.name); return { auth: await Authenticator.getAuth(n), name: n }; }
  const ms = prefs.getMicrosoft();
  if (!ms) throw new Error(`"${inst.name}" necesita una cuenta de Microsoft. Vincúlala desde el menú de tu cuenta.`);
  let xbox;
  try { xbox = await new Auth('select_account').refresh(ms.refresh); }
  catch { throw new Error('Tu sesión de Microsoft caducó. Vuelve a vincular tu cuenta.'); }
  const mc = await xbox.getMinecraft();
  prefs.setMicrosoft({ name: mc.profile.name, uuid: mc.profile.id, refresh: xbox.save() });
  return { auth: mc.mclc(), name: mc.profile.name };
}

async function linkMicrosoft() {
  const xbox = await new Auth('select_account').launch('electron', { width: 520, height: 680, resizable: false, title: 'Inicia sesión con Microsoft' });
  const mc = await xbox.getMinecraft();
  if (!mc.profile) throw new Error('Esta cuenta de Microsoft no tiene Minecraft: Java Edition.');
  prefs.setMicrosoft({ name: mc.profile.name, uuid: mc.profile.id, refresh: xbox.save() });
  return mc.profile.name;
}

/** Mods que el launcher añade solo (con sus dependencias), resueltos en Modrinth y recordados. */
async function autoMods(slug, label, version, loader, log, used) {
  const cacheKey = `${slug}:${version}:${loader}`;
  const cache = prefs.raw().cslCache || {};
  const shared = store.sharedAutoMods(cacheKey);
  // Añade a cada mod la copia del equipo en GitHub (por si Modrinth no deja descargar).
  const withMirror = (mods) => mods.map((m) => {
    const s = shared?.find((x) => x.file === m.file && x.sha1 === m.sha1);
    return s?.mirror ? { ...m, mirror: s.mirror } : m;
  });
  let lastError = null;
  for (let attempt = 0; attempt < 3; attempt++) {
    try {
      const mods = await modrinth.resolve(slug, version, loader);
      cache[cacheKey] = mods;
      prefs.set({ cslCache: cache });
      used?.push({ key: cacheKey, mods });
      return withMirror(mods);
    } catch (e) {
      lastError = e;
      if (/No hay versión/.test(e.message)) break;
      await new Promise((r) => setTimeout(r, 1500 * (attempt + 1)));
    }
  }
  if (Array.isArray(cache[cacheKey]) && cache[cacheKey].length) {
    log(`[Caldito] ${label}: Modrinth no respondió; se usa la copia guardada en este PC.`);
    return withMirror(cache[cacheKey]);
  }
  if (shared?.length) {
    log(`[Caldito] ${label}: Modrinth no respondió; se usa la copia del equipo.`);
    return shared;
  }
  log(`[Caldito] No se pudo preparar ${label}: ${lastError?.message || 'sin conexión con Modrinth'}`);
  return [];
}
/** Añade mods sin duplicar los que el equipo ya publicó (mismo proyecto o mismo mod con otra versión). */
function mergeMods(list, extra) {
  for (const m of extra) {
    // Los mods que añade el launcher pueden venir con otro nombre si el equipo los subió a mano.
    const tok = (f) => modKey(f).split(/[-_]/)[0];
    const known = ['customskinloader', 'fancymenu', 'drippyloadingscreen', 'konkrete', 'melody'];
    const dup = list.some((x) => (m.projectId && x.projectId === m.projectId) || modKey(x.file) === modKey(m.file) || (known.includes(tok(m.file)) && tok(x.file) === tok(m.file)));
    if (!dup) list.push(m);
  }
  return list;
}

async function play(instanceId, emit) {
  if (running) throw new Error('El juego ya se está ejecutando.');
  store.requireSession();
  // Traemos lo último publicado (mods nuevos, configuración…) antes de preparar el juego.
  await store.refresh().catch(() => {});
  const inst = store.getInstance(instanceId);
  if (!inst) throw new Error('No hay ninguna instancia disponible.');
  const p = prefs.raw();
  const root = prefs.gameDir();
  const gameDir = prefs.instanceDir(inst.id);
  await fs.promises.mkdir(gameDir, { recursive: true });
  const progress = (stage) => (x) => emit('progress', { stage, ...x });
  const log = (l) => emit('log', l);

  emit('stage', { text: 'Verificando tu cuenta…' });
  const { auth: authorization, name } = await getAuthorization(inst);

  emit('stage', { text: `Consultando ${inst.name}…` });
  const version = await resolveVersion(inst);
  log(`[Caldito] Instancia "${inst.name}" · Minecraft ${version} · ${inst.loader}`);

  emit('stage', { text: 'Preparando Java…' });
  const javaPath = await ensureJava(version, p.javaPath, progress('java'));

  emit('stage', { text: `Preparando ${inst.loader}…` });
  const custom = await prepareLoader(root, { version, loader: inst.loader, loaderVersion: inst.loaderVersion });

  if (inst.loader !== 'vanilla') {
    const mods = [...inst.mods];
    const autoUsed = [];
    if (inst.skins !== false) {
      emit('stage', { text: 'Preparando skins y capas…' });
      mergeMods(mods, await autoMods('customskinloader', 'CustomSkinLoader', version, inst.loader, log, autoUsed));
    }
    if (inst.menu !== false) {
      emit('stage', { text: 'Preparando el menú de Caldito…' });
      const menuMods = await autoMods('fancymenu', 'FancyMenu', version, inst.loader, log, autoUsed);
      if (!menuMods.length) emit('warn', { text: 'No se pudo descargar el menú de Caldito (FancyMenu). El juego abrirá con el menú normal; vuelve a intentarlo en unos minutos o revisa tu conexión.' });
      mergeMods(mods, menuMods);
      mergeMods(mods, await autoMods('drippy-loading-screen', 'Drippy Loading Screen', version, inst.loader, log, autoUsed));
    }
    if (mods.length) {
      emit('stage', { text: 'Sincronizando mods…' });
      await syncMods(gameDir, mods, progress('mods'));
      // El equipo deja una copia de estos mods en GitHub para los jugadores a los que no les funcione Modrinth.
      if (autoUsed.length && store.isStaff()) {
        store.saveSharedAutoMods(autoUsed, require('path').join(gameDir, 'mods')).catch((e) => log('[Caldito] Copia de mods: ' + e.message));
      }
    }
    const files = Array.isArray(inst.files) ? inst.files : [];
    if (files.length) {
      emit('stage', { text: 'Sincronizando configuración…' });
      await syncFiles(gameDir, files, progress('files'));
    }
    if (inst.menu !== false) {
      try {
        fancymenu.prepare(gameDir, inst, { staff: store.isStaff(), customLayouts: files.some((f) => f.path.startsWith('config/fancymenu/customization/')) });
      } catch (e) { log('[Caldito] Menú: ' + e.message); }
    } else {
      try { fancymenu.remove(gameDir); } catch {}
    }
    if (inst.skins !== false) await skins.prepareInstance(gameDir, name).catch((e) => log('[Caldito] Skins: ' + e.message));
  }

  emit('stage', { text: 'Descargando Minecraft…' });
  const launcher = new Client();
  const ram = prefs.effectiveRam(inst.ramMB);
  const port = Number(inst.port) || 25565;
  const address = port === 25565 ? inst.host : `${inst.host}:${port}`;
  const [, minor = 0] = version.split('.').map(Number);

  const opts = {
    authorization,
    root,
    javaPath,
    version: { number: version, type: 'release', ...(custom ? { custom } : {}) },
    memory: { max: `${ram}M`, min: `${Math.min(1024, ram)}M` },
    window: p.fullscreen ? { fullscreen: true } : { width: p.width, height: p.height },
    customArgs: p.jvmArgs ? p.jvmArgs.split(/\s+/).filter(Boolean) : [],
    overrides: { detached: p.afterLaunch === 'close', gameDirectory: gameDir },
  };
  if (inst.host) {
    if (minor >= 20) opts.quickPlay = { type: 'multiplayer', identifier: address };
    else opts.server = { host: inst.host, port: String(port) };
  }

  const names = { assets: 'Descargando recursos', natives: 'Librerías nativas', classes: 'Librerías', 'classes-custom': 'Librerías del cargador', 'classes-maven-custom': 'Librerías del cargador' };
  launcher.on('progress', (x) => emit('progress', { stage: 'game', task: names[x.type] || 'Descargando', done: x.task, total: x.total }));
  launcher.on('debug', (l) => log(String(l)));
  launcher.on('data', (l) => log(String(l)));

  running = launcher;
  const proc = await launcher.launch(opts);
  if (!proc) { running = null; throw new Error('No se pudo iniciar Minecraft. Revisa la consola.'); }
  emit('game', { running: true, instance: inst.id });
  stats.start(name, inst.id);
  launcher.on('close', (code) => { running = null; stats.stop().catch(() => {}); emit('game', { running: false, code }); });
}

module.exports = { play, linkMicrosoft, resolveVersion, isRunning: () => !!running, _autoMods: autoMods };
