'use strict';
// Estado central: datos compartidos, sesión (jugador / moderador / desarrollador) y permisos.
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { app, safeStorage } = require('electron');
const { defaults, defaultInstance } = require('./defaults');
const { LocalProvider, GitHubProvider } = require('./providers');
const s = require('./secure');

const userFile = (n) => path.join(app.getPath('userData'), n);
const readJson = (f) => { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch { return null; } };
const writeJson = (f, v) => { fs.mkdirSync(path.dirname(f), { recursive: true }); fs.writeFileSync(f, JSON.stringify(v, null, 2)); };

function bundledFile(name) {
  const c = [path.join(process.resourcesPath || '', 'config', name), path.join(__dirname, '..', '..', 'config', name)];
  return c.find((f) => fs.existsSync(f)) || c[1];
}

const st = {
  data: null, provider: null, sync: null, source: 'seed',
  session: null,     // { role: 'player'|'mod'|'dev', id, name }
  devKey: null,      // llave del equipo (moderadores y desarrolladores)
  playerKey: null,   // llave de jugadores (para subir skins)
  lastError: null, revoked: false,
};

/* ---------- mezcla con valores por defecto y migraciones ---------- */
const isObj = (v) => v && typeof v === 'object' && !Array.isArray(v);
function deepMerge(base, over) {
  if (!isObj(base) || !isObj(over)) return over === undefined ? base : over;
  const out = { ...base };
  for (const k of Object.keys(over)) out[k] = isObj(base[k]) && isObj(over[k]) ? deepMerge(base[k], over[k]) : over[k];
  return out;
}
function normalizeInstance(i) {
  const d = defaultInstance();
  const out = { ...d, ...i, mods: Array.isArray(i.mods) ? i.mods : [], files: Array.isArray(i.files) ? i.files : [] };
  out.id = String(out.id || s.randomId());
  return out;
}
function normalizeData(raw) {
  raw = raw ? { ...raw } : {};
  // v2 → v3: el servidor único y sus mods pasan a ser la primera instancia.
  if ((!Array.isArray(raw.instances) || !raw.instances.length) && raw.server) {
    raw.instances = [{ ...defaultInstance(), ...raw.server, mods: raw.mods || [] }];
  }
  delete raw.server; delete raw.mods;
  const d = deepMerge(defaults(), raw);
  for (const k of ['news', 'players', 'devs', 'buttons', 'capes', 'instances']) if (!Array.isArray(d[k])) d[k] = [];
  if (!d.instances.length) d.instances = [defaultInstance()];
  d.instances = d.instances.map(normalizeInstance);
  for (const k of ['vault', 'playerVault']) if (!isObj(d[k])) d[k] = {};
  for (const x of d.devs) if (!x.role) x.role = 'dev';
  return d;
}
function seedData() { return normalizeData({ ...(readJson(bundledFile('seed.json')) || {}) }); }
/** Datos que se guardaron en modo local en este PC (antes de conectar GitHub). */
function localStoreData() {
  const raw = readJson(path.join(app.getPath('userData'), 'store', 'launcher-data.json'));
  return raw ? normalizeData(raw) : null;
}

/* ---------- sincronización ---------- */
function loadSync() {
  const local = readJson(userFile('sync.json'));
  const bundled = readJson(bundledFile('launcher.config.json'))?.sync;
  return { provider: 'local', branch: 'main', path: 'launcher-data.json', ...(bundled || {}), ...(local || {}) };
}
function makeProvider(sync, token = null) { return sync.provider === 'github' ? new GitHubProvider(sync, token) : new LocalProvider(); }
const withTimeout = (p, ms) => Promise.race([p, new Promise((_, rej) => setTimeout(() => rej(new Error('Tiempo de espera agotado')), ms))]);

async function boot() {
  st.sync = loadSync();
  try { st.provider = makeProvider(st.sync); }
  catch (e) { st.lastError = e.message; st.sync = { provider: 'local' }; st.provider = new LocalProvider(); }
  await refresh(true);
  await restoreSession();
  return view();
}

async function refresh(initial = false) {
  try {
    const raw = await withTimeout(st.provider.read(), 9000);
    if (raw) { st.data = normalizeData(raw); st.source = 'remote'; }
    else {
      // Repositorio aún vacío: se usan los datos locales de este PC (si los hay) para no perderlos al conectar.
      st.data = st.data || (st.provider.kind === 'github' ? localStoreData() : null) || seedData();
      st.source = 'seed';
      if (st.provider.kind === 'local') await st.provider.write(st.data);
    }
    writeJson(userFile('data-cache.json'), st.data);
    st.lastError = null;
  } catch (e) {
    st.lastError = e.message;
    if (initial || !st.data) {
      const cache = readJson(userFile('data-cache.json'));
      st.data = cache ? normalizeData(cache) : seedData();
      st.source = cache ? 'cache' : 'seed';
    }
  }
  revalidateSession();
  return view();
}

async function mutate(fn, message) {
  requireStaff();
  let latest = st.data;
  try { const raw = await st.provider.read(); if (raw) latest = normalizeData(raw); } catch {}
  const result = await fn(latest);
  latest.updatedAt = new Date().toISOString();
  latest.updatedBy = st.session.name;
  if (JSON.stringify(latest).length > 9 * 1024 * 1024) throw new Error('Los datos superan 9 MB. Usa imágenes más ligeras.');
  await st.provider.write(latest, message || `Cambios de ${st.session.name}`);
  st.data = latest;
  st.source = 'remote';
  writeJson(userFile('data-cache.json'), st.data);
  return result;
}

/* ---------- permisos ---------- */
const isStaff = () => (st.session?.role === 'dev' || st.session?.role === 'mod') && !!st.devKey;
function requireStaff() { if (!isStaff()) throw new Error('Solo el equipo (moderadores o desarrolladores) puede hacer esto.'); }
function requireDev() { if (st.session?.role !== 'dev' || !st.devKey) throw new Error('Solo los desarrolladores pueden hacer esto.'); }
function requireSession() { if (!st.session) throw new Error('Inicia sesión primero.'); }

/* ---------- sesión ---------- */
function protect(str) {
  return safeStorage.isEncryptionAvailable() ? { enc: safeStorage.encryptString(str).toString('base64') } : { raw: Buffer.from(str).toString('base64') };
}
function unprotect(o) {
  if (!o) return null;
  return o.enc ? safeStorage.decryptString(Buffer.from(o.enc, 'base64')) : Buffer.from(o.raw, 'base64').toString();
}

function unlockPlayer(code) {
  const p = st.data.players.find((x) => x.active !== false && s.safeEqual(s.hashCode(code, x.salt), x.codeHash));
  if (!p) return null;
  let playerKey = null;
  const box = st.data.playerVault[p.id];
  if (box && p.vaultSalt) { try { playerKey = Buffer.from(s.decrypt(s.deriveKey(code, p.vaultSalt), box).playerKey, 'base64'); } catch {} }
  return { p, playerKey };
}
/** Código firmado: válido en cualquier PC aunque los datos no estén compartidos. */
function unlockPass(name, code) {
  name = String(name || '').trim();
  if (!/^[A-Za-z0-9_]{3,16}$/.test(name)) return null;
  const gen = s.verifyPass(name, code);
  if (gen < 0) return null;
  const known = st.data.players.find((p) => p.name.toLowerCase() === name.toLowerCase());
  if (known && known.active === false) throw new Error('Tu acceso fue desactivado. Pide un código nuevo a un desarrollador.');
  if (known && typeof known.gen === 'number' && known.gen !== gen) throw new Error('Ese código ya no es válido: un desarrollador generó uno nuevo para ti.');
  return { id: known ? known.id : 'pass:' + name.toLowerCase(), name: known ? known.name : name };
}

async function loginPlayer(code, name = '') {
  if (s.normalize(code).length < 8) throw new Error('Escribe tu código completo.');
  await refresh();
  const r = unlockPlayer(code);
  if (r) {
    st.session = { role: 'player', id: r.p.id, name: r.p.name };
    st.devKey = null;
    st.playerKey = r.playerKey;
    writeJson(userFile('session.json'), { role: 'player', id: r.p.id, code: protect(s.normalize(code)) });
    return view();
  }
  if (!String(name || '').trim()) throw new Error('Escribe tu nombre de jugador y tu código.');
  const pass = unlockPass(name, code);
  if (!pass) throw new Error('El nombre y el código no coinciden. Escríbelos tal como te los dio el equipo.');
  st.session = { role: 'player', id: pass.id, name: pass.name };
  st.devKey = null;
  st.playerKey = null;
  writeJson(userFile('session.json'), { role: 'player', id: pass.id, name: pass.name, pass: true, code: protect(s.normalize(code)) });
  return view();
}

function unlockDev(code) {
  const dev = st.data.devs.find((d) => s.safeEqual(s.hashCode(code, d.salt), d.codeHash));
  if (!dev) return null;
  const box = st.data.vault[dev.id];
  if (!box) throw new Error('Falta la llave de este código. Pide a un desarrollador que lo regenere.');
  const { devKey } = s.decrypt(s.deriveKey(code, dev.vaultSalt), box);
  return { dev, devKey: Buffer.from(devKey, 'base64') };
}
/** Código de equipo largo: lleva la llave del equipo y funciona en cualquier PC. */
function unlockTeam(code) {
  const t = s.decodeTeam(code);
  if (!t) return null;
  // La llave tiene que ser la de este equipo: debe abrir los datos del equipo que hay en este PC.
  const genuine = st.data.devs.some((x) => { try { s.decrypt(t.devKey, x.codeEnc); return true; } catch { return false; } });
  if (!genuine) return null;
  const known = st.data.devs.find((x) => x.id === t.id);
  if (known) {
    if (typeof known.gen === 'number' && known.gen !== t.gen) throw new Error('Ese código de equipo ya no es válido: se generó uno nuevo.');
    return { dev: known, devKey: t.devKey };
  }
  if (st.sync.provider === 'github') throw new Error('Ese código de equipo fue eliminado.');
  return { dev: { id: t.id, name: t.name, role: t.role }, devKey: t.devKey, offline: true };
}

function applyGithubToken() {
  if (st.provider.kind !== 'github' || !st.devKey || !st.data.secrets) return;
  try { st.provider.setToken(s.decrypt(st.devKey, st.data.secrets).githubToken); } catch {}
}
async function loginDev(code, remember = true) {
  if (s.normalize(code).length < 8) throw new Error('Escribe el código completo.');
  await refresh();
  const r = unlockDev(code) || unlockTeam(code);
  if (!r) {
    throw new Error(s.normalize(code).length < 30 && st.sync.provider !== 'github'
      ? 'Código de equipo incorrecto. Si es un código de moderador o desarrollador antiguo, pide que te lo regeneren: los nuevos funcionan en cualquier PC.'
      : 'Código de equipo incorrecto. Pégalo completo, tal como te lo enviaron.');
  }
  st.session = { role: r.dev.role || 'dev', id: r.dev.id, name: r.dev.name, offline: !!r.offline };
  st.devKey = r.devKey;
  st.playerKey = null;
  applyGithubToken();
  if (remember) writeJson(userFile('session.json'), { role: 'staff', id: r.dev.id, code: protect(s.normalize(code)) });
  else fs.rmSync(userFile('session.json'), { force: true });
  return view();
}

async function restoreSession() {
  const saved = readJson(userFile('session.json'));
  if (!saved) return;
  try {
    const code = saved.code ? unprotect(saved.code) : null;
    if (saved.role === 'player' && code) {
      const r = unlockPlayer(code);
      if (r) { st.session = { role: 'player', id: r.p.id, name: r.p.name }; st.playerKey = r.playerKey; }
      else if (saved.pass && saved.name) {
        const p = unlockPass(saved.name, code);
        if (p) st.session = { role: 'player', id: p.id, name: p.name };
      }
    } else if (code) {
      const r = unlockDev(code) || unlockTeam(code);
      if (r) { st.session = { role: r.dev.role || 'dev', id: r.dev.id, name: r.dev.name, offline: !!r.offline }; st.devKey = r.devKey; applyGithubToken(); }
    }
  } catch {}
  if (!st.session) fs.rmSync(userFile('session.json'), { force: true });
}

function revalidateSession() {
  if (!st.session || !st.data) return;
  if (st.session.role === 'player') {
    if (st.session.id.startsWith('pass:')) {
      // Jugador con código firmado: solo se le saca si el equipo lo desactivó o le cambió el código.
      const k = st.data.players.find((x) => x.name.toLowerCase() === st.session.name.toLowerCase());
      if (k && k.active === false) return kick();
      return;
    }
    const p = st.data.players.find((x) => x.id === st.session.id && x.active !== false);
    if (!p) return kick();
    st.session.name = p.name;
  } else {
    const d = st.data.devs.find((x) => x.id === st.session.id);
    // Miembro del equipo que entró con su código en un PC sin datos compartidos: se mantiene.
    if (!d && st.session.offline && st.sync.provider !== 'github') return;
    if (!d) return kick();
    st.session.role = d.role || 'dev';
    st.session.name = d.name;
  }
}
function kick() {
  st.session = null; st.devKey = null; st.playerKey = null; st.revoked = true;
  fs.rmSync(userFile('session.json'), { force: true });
}
function logout() {
  st.session = null; st.devKey = null; st.playerKey = null;
  if (st.provider?.setToken) st.provider.setToken(null);
  fs.rmSync(userFile('session.json'), { force: true });
  return view();
}

/* ---------- conexión para jugadores (sin sesión) ---------- */
function parseConnection(code) {
  const m = /^\s*(?:caldito:\/\/)?([\w.-]+\/[\w.-]+)(?:#([\w./-]+))?\s*$/i.exec(String(code || ''));
  if (!m) throw new Error('Código de conexión no válido. Tiene la forma usuario/repositorio.');
  return { provider: 'github', repo: m[1], branch: m[2] || 'main', path: 'launcher-data.json' };
}
async function connectWithCode(code) {
  const sync = parseConnection(code);
  const gh = new GitHubProvider(sync);
  const raw = await withTimeout(gh.read(), 12000);
  if (!raw) throw new Error('Ese código de conexión no tiene datos de un launcher. Revisa que esté bien escrito.');
  st.sync = sync; st.provider = gh; st.data = normalizeData(raw); st.source = 'remote';
  writeJson(userFile('sync.json'), sync);
  writeJson(userFile('data-cache.json'), st.data);
  st.session = null; st.devKey = null; st.playerKey = null;
  fs.rmSync(userFile('session.json'), { force: true });
  return view();
}
function connectionCode() {
  return st.sync.provider === 'github' && st.sync.repo ? st.sync.repo + (st.sync.branch && st.sync.branch !== 'main' ? '#' + st.sync.branch : '') : '';
}

/* ---------- lo que ve la interfaz ---------- */
function teamKeyReveal(box) { try { return s.decrypt(st.devKey, box).code; } catch { return null; } }
function view() {
  const d = st.data;
  const role = st.session?.role;
  const visibleInstances = d.instances.filter((i) => i.visible !== false || role === 'dev' || role === 'mod');
  const base = {
    theme: d.theme, texts: d.texts, sections: d.sections, splash: d.splash, buttons: d.buttons, news: d.news,
    instances: visibleInstances, capes: d.capes, update: d.update,
    skins: { repo: d.skins?.repo || '', branch: d.skins?.branch || 'main', canUpload: !!getSkinsTokenSafe() },
    session: st.session, revoked: st.revoked,
    sync: { provider: st.sync.provider, repo: st.sync.repo || '', branch: st.sync.branch || 'main', source: st.source, error: st.lastError, connectionCode: connectionCode() },
    needsConnection: st.sync.provider !== 'github' && !d.players.length,
    updatedAt: d.updatedAt, updatedBy: d.updatedBy,
  };
  st.revoked = false;
  if (!isStaff()) return base;
  const extra = { hasGithubToken: !!d.secrets, hasSkinsToken: !!d.skinsSecret };
  if (role === 'dev') {
    Object.assign(extra, {
      players: d.players.map((p) => ({ id: p.id, name: p.name, note: p.note || '', active: p.active !== false, createdAt: p.createdAt, code: teamKeyReveal(p.codeEnc) })),
      devs: d.devs.map((x) => ({ id: x.id, name: x.name, role: x.role || 'dev', founder: !!x.founder, createdAt: x.createdAt, code: teamKeyReveal(x.codeEnc), me: x.id === st.session.id })),
    });
  }
  return { ...base, ...extra };
}

/* ---------- personalización (desarrolladores) ---------- */
const EDITABLE = ['theme', 'texts', 'sections', 'splash', 'buttons', 'news', 'capes'];
async function publish(patch) {
  requireDev();
  await mutate((d) => {
    for (const k of EDITABLE) if (k in patch) d[k] = Array.isArray(patch[k]) ? [...patch[k]] : deepMerge(d[k], patch[k]);
  }, `Personalización actualizada por ${st.session.name}`);
  return view();
}

/* ---------- instancias (moderadores y desarrolladores) ---------- */
function validateInstance(i) {
  if (!String(i.name || '').trim()) throw new Error('La instancia necesita un nombre.');
  if (!String(i.host || '').trim()) throw new Error(`La instancia "${i.name}" necesita la dirección del servidor.`);
  if (i.mcVersion !== 'auto' && !/^1\.\d{1,2}(\.\d{1,2})?$/.test(String(i.mcVersion))) throw new Error(`Versión no válida en "${i.name}" (ej. 1.21.1 o automática).`);
  if (!['vanilla', 'fabric', 'quilt'].includes(i.loader)) throw new Error('Cargador no válido.');
  if (!['offline', 'microsoft'].includes(i.authMode)) throw new Error('Tipo de cuenta no válido.');
}
async function saveInstances(instances) {
  requireStaff();
  if (!Array.isArray(instances) || !instances.length) throw new Error('Debe haber al menos una instancia.');
  const clean = instances.map((i) => {
    const n = normalizeInstance({ ...i, name: String(i.name || '').trim(), host: String(i.host || '').trim(), port: Number(i.port) || 25565, ramMB: Math.max(1024, Number(i.ramMB) || 4096) });
    validateInstance(n);
    return n;
  });
  const ids = new Set();
  for (const i of clean) { if (ids.has(i.id)) i.id = s.randomId(); ids.add(i.id); }
  await mutate((d) => {
    // Los mods se conservan desde lo publicado (se editan en la pestaña Mods).
    const prev = Object.fromEntries(d.instances.map((i) => [i.id, i]));
    d.instances = clean.map((i) => ({ ...i, mods: prev[i.id]?.mods ?? i.mods ?? [], files: prev[i.id]?.files ?? i.files ?? [] }));
  }, `Instancias actualizadas por ${st.session.name}`);
  return view();
}
function getInstance(id) {
  const list = st.data.instances;
  return list.find((i) => i.id === id) || list.find((i) => i.visible !== false) || list[0];
}
async function addMods(instanceId, mods) {
  await mutate((d) => {
    const inst = d.instances.find((i) => i.id === instanceId);
    if (!inst) throw new Error('Esa instancia ya no existe.');
    for (const m of mods) {
      inst.mods = inst.mods.filter((x) => x.file.toLowerCase() !== m.file.toLowerCase() && !(m.projectId && x.projectId === m.projectId));
      inst.mods.push({ id: s.randomId(), addedAt: new Date().toISOString(), ...m });
    }
  }, `Mods en ${instanceId}: ${mods.map((m) => m.name).join(', ')}`);
  return view();
}
async function removeMod(instanceId, modId) {
  const inst = st.data.instances.find((i) => i.id === instanceId);
  const mod = inst?.mods.find((m) => m.id === modId);
  await mutate((d) => {
    const x = d.instances.find((i) => i.id === instanceId);
    if (x) x.mods = x.mods.filter((m) => m.id !== modId);
  }, `Mod eliminado: ${mod?.name || modId}`);
  const stillUsed = st.data.instances.some((i) => i.mods.some((m) => m.url === mod?.url));
  if (mod?.source === 'upload' && !stillUsed) await st.provider.deleteFile(mod.url).catch(() => {});
  return view();
}
async function setInstanceFiles(instanceId, files) {
  await mutate((d) => {
    const inst = d.instances.find((i) => i.id === instanceId);
    if (!inst) throw new Error('Esa instancia ya no existe.');
    inst.files = files;
  }, files.length ? `Configuración publicada en ${instanceId} (${files.length} archivos)` : `Configuración retirada de ${instanceId}`);
  return view();
}
async function putFile(rel, buffer) { requireStaff(); return st.provider.putFile(rel, buffer); }

/* ---------- códigos ---------- */
const newPlayerCode = (name, gen = 0) => s.passCode(name, gen);

function getPlayerKey(d = st.data) {
  if (st.devKey && d.playerKeyEnc) { try { return Buffer.from(s.decrypt(st.devKey, d.playerKeyEnc).playerKey, 'base64'); } catch {} }
  return st.playerKey;
}
function wrapForPlayer(d, p, code, playerKey) {
  if (!playerKey) return;
  p.vaultSalt = p.vaultSalt || s.randomSalt();
  d.playerVault[p.id] = s.encrypt(s.deriveKey(code, p.vaultSalt), { playerKey: playerKey.toString('base64') });
}

async function createPlayer(name, note = '') {
  requireDev();
  name = String(name || '').trim();
  if (!/^[A-Za-z0-9_]{3,16}$/.test(name)) throw new Error('El nombre del jugador debe tener 3–16 caracteres: letras, números o _ (será su nombre en Minecraft).');
  const code = newPlayerCode(name, 0);
  await mutate((d) => {
    if (d.players.some((p) => p.name.toLowerCase() === name.toLowerCase())) throw new Error(`Ya existe un jugador llamado ${name}.`);
    const salt = s.randomSalt();
    const p = { id: s.randomId(), name, note, salt, gen: 0, codeHash: s.hashCode(code, salt), codeEnc: s.encrypt(st.devKey, { code }), active: true, createdAt: new Date().toISOString() };
    wrapForPlayer(d, p, code, getPlayerKey(d));
    d.players.push(p);
  }, `Nuevo jugador: ${name}`);
  return { code, view: view() };
}
async function updatePlayer(id, patch) {
  requireDev();
  let code = null;
  await mutate((d) => {
    const p = d.players.find((x) => x.id === id);
    if (!p) throw new Error('Ese jugador ya no existe.');
    if ('name' in patch) {
      const n = String(patch.name).trim();
      if (!/^[A-Za-z0-9_]{3,16}$/.test(n)) throw new Error('Nombre no válido (3–16 caracteres: letras, números o _).');
      if (d.players.some((x) => x.id !== id && x.name.toLowerCase() === n.toLowerCase())) throw new Error(`Ya existe un jugador llamado ${n}.`);
      // El código va ligado al nombre: si cambia el nombre, se crea un código nuevo.
      if (n.toLowerCase() !== p.name.toLowerCase()) patch.regenerate = true;
      p.name = n;
    }
    if ('note' in patch) p.note = String(patch.note);
    if ('active' in patch) p.active = !!patch.active;
    if (patch.regenerate) {
      p.gen = ((typeof p.gen === 'number' ? p.gen : -1) + 1) & 63;
      code = newPlayerCode(p.name, p.gen);
      p.salt = s.randomSalt(); p.vaultSalt = s.randomSalt();
      p.codeHash = s.hashCode(code, p.salt);
      p.codeEnc = s.encrypt(st.devKey, { code });
      wrapForPlayer(d, p, code, getPlayerKey(d));
    }
  }, 'Jugador actualizado');
  return { code, view: view() };
}
async function deletePlayer(id) {
  requireDev();
  await mutate((d) => { d.players = d.players.filter((p) => p.id !== id); delete d.playerVault[id]; }, 'Jugador eliminado');
  return view();
}
async function createDev(name, role = 'dev') {
  requireDev();
  name = String(name || '').trim();
  if (name.length < 2) throw new Error('Pon un nombre.');
  if (!['dev', 'mod'].includes(role)) role = 'dev';
  const id = s.randomId();
  const code = s.encodeTeam({ id, role, gen: 0, name }, st.devKey);
  await mutate((d) => {
    const salt = s.randomSalt(), vaultSalt = s.randomSalt();
    d.devs.push({ id, name, role, gen: 0, salt, vaultSalt, codeHash: s.hashCode(code, salt), codeEnc: s.encrypt(st.devKey, { code }), createdAt: new Date().toISOString() });
    d.vault[id] = s.encrypt(s.deriveKey(code, vaultSalt), { devKey: st.devKey.toString('base64') });
  }, `Nuevo ${role === 'mod' ? 'moderador' : 'desarrollador'}: ${name}`);
  return { code, view: view() };
}
async function updateDev(id, patch) {
  requireDev();
  let code = null;
  await mutate((d) => {
    const x = d.devs.find((v) => v.id === id);
    if (!x) throw new Error('Ese miembro del equipo ya no existe.');
    if (patch.role && ['dev', 'mod'].includes(patch.role)) {
      if (id === st.session.id && patch.role !== 'dev') throw new Error('No puedes quitarte a ti mismo el rol de desarrollador.');
      x.role = patch.role;
    }
    if (patch.regenerate) {
      x.gen = ((typeof x.gen === 'number' ? x.gen : -1) + 1) & 255;
      code = x.founder ? s.generateCode(4, 'CALDO') : s.encodeTeam({ id: x.id, role: x.role || 'dev', gen: x.gen, name: x.name }, st.devKey);
      x.salt = s.randomSalt(); x.vaultSalt = s.randomSalt();
      x.codeHash = s.hashCode(code, x.salt);
      x.codeEnc = s.encrypt(st.devKey, { code });
      d.vault[id] = s.encrypt(s.deriveKey(code, x.vaultSalt), { devKey: st.devKey.toString('base64') });
    }
  }, 'Equipo actualizado');
  if (code && id === st.session.id && readJson(userFile('session.json'))) writeJson(userFile('session.json'), { role: 'staff', id, code: protect(s.normalize(code)) });
  return { code, view: view() };
}
async function deleteDev(id) {
  requireDev();
  if (id === st.session.id) throw new Error('No puedes eliminar tu propia cuenta.');
  await mutate((d) => {
    if (d.devs.filter((x) => x.id !== id && (x.role || 'dev') === 'dev').length < 1) throw new Error('Debe quedar al menos un desarrollador.');
    d.devs = d.devs.filter((x) => x.id !== id);
    delete d.vault[id];
  }, 'Miembro del equipo eliminado');
  return view();
}

/* ---------- repositorio de skins ---------- */
function getSkinsTokenSafe() {
  try { return getSkinsToken(); } catch { return null; }
}
function getSkinsToken() {
  const d = st.data;
  if (!d?.skinsSecret) return null;
  const key = getPlayerKey();
  if (!key) return null;
  return s.decrypt(key, d.skinsSecret).token;
}
function skinsProvider() {
  const repo = st.data.skins?.repo;
  if (!repo) return null;
  return new GitHubProvider({ repo, branch: st.data.skins.branch || 'main', path: 'README.md' }, getSkinsTokenSafe());
}
async function setSkinsRepo({ repo, branch, token }) {
  requireDev();
  repo = String(repo || '').trim();
  token = String(token || '').trim();
  if (!repo) {
    await mutate((d) => { d.skins = { repo: '', branch: 'main' }; d.skinsSecret = null; }, 'Repositorio de skins desactivado');
    return view();
  }
  const gh = new GitHubProvider({ repo, branch: branch || 'main', path: 'README.md' }, token || getSkinsTokenSafe());
  if (!gh.token) throw new Error('Pega el token del repositorio de skins.');
  await gh.test();
  if (repo === st.sync.repo) throw new Error('Usa un repositorio distinto al de los datos: el token de skins lo tendrán todos los jugadores.');
  await mutate((d) => {
    let playerKey = getPlayerKey(d);
    if (!playerKey) {
      playerKey = crypto.randomBytes(32);
      d.playerKeyEnc = s.encrypt(st.devKey, { playerKey: playerKey.toString('base64') });
    }
    d.skins = { repo, branch: branch || 'main' };
    d.skinsSecret = s.encrypt(playerKey, { token: gh.token });
    // Damos la llave a todos los jugadores que ya existen.
    for (const p of d.players) {
      const code = teamKeyReveal(p.codeEnc);
      if (code) wrapForPlayer(d, p, code, playerKey);
    }
  }, 'Repositorio de skins configurado');
  return view();
}

/* ---------- conexión con GitHub (datos) ---------- */
async function connectGithub({ repo, branch, token }) {
  requireDev();
  const sync = { provider: 'github', repo: String(repo).trim(), branch: String(branch || 'main').trim(), path: 'launcher-data.json' };
  token = String(token || '').trim();
  const gh = new GitHubProvider(sync, token || null);
  if (!token && st.data.secrets) { try { gh.setToken(s.decrypt(st.devKey, st.data.secrets).githubToken); } catch {} }
  if (!gh.token) throw new Error('Pega un token de GitHub con permiso de escritura.');
  await gh.test();
  const existing = await gh.read();
  let data;
  if (existing) {
    data = normalizeData(existing);
    const me = data.devs.find((x) => x.id === st.session.id);
    let same = false;
    try { same = !!(me && s.decrypt(st.devKey, me.codeEnc)); } catch {}
    if (!same) throw new Error('Ese repositorio ya tiene datos de otro launcher y tu código no está en él.');
  } else {
    data = JSON.parse(JSON.stringify(st.data));
    for (const inst of data.instances) {
      for (const m of inst.mods) {
        if (m.url?.startsWith('file:')) m.url = await gh.putFile(`mods/${m.file}`, await fs.promises.readFile(new URL(m.url)));
      }
    }
    if (data.update?.url?.startsWith('file:')) {
      data.update.url = await gh.putFile(`updates/${path.basename(new URL(data.update.url).pathname)}`, await fs.promises.readFile(new URL(data.update.url)));
    }
  }
  if (token) data.secrets = s.encrypt(st.devKey, { githubToken: token });
  data.updatedAt = new Date().toISOString();
  data.updatedBy = st.session.name;
  await gh.write(data, existing ? `Token actualizado por ${st.session.name}` : 'Datos iniciales del launcher');
  st.sync = sync; st.provider = gh; st.data = data; st.source = 'remote';
  writeJson(userFile('sync.json'), sync);
  writeJson(userFile('data-cache.json'), data);
  return view();
}
async function useLocal() {
  requireDev();
  st.sync = { provider: 'local', branch: 'main', path: 'launcher-data.json' };
  writeJson(userFile('sync.json'), st.sync);
  st.provider = new LocalProvider();
  const local = await st.provider.read();
  if (!local) await st.provider.write(st.data); else st.data = normalizeData(local);
  revalidateSession();
  return view();
}

/* ---------- actualizaciones publicadas ---------- */
async function setUpdate(update) {
  requireDev();
  await mutate((d) => { d.update = update; }, `Actualización del launcher ${update?.version || 'retirada'}`);
  return view();
}

/* ---------- mods que instala el launcher (FancyMenu, Drippy, CustomSkinLoader…) ---------- */
// Copia compartida en los datos del equipo: si a un jugador no le responde Modrinth, usa esta lista
// y, si tampoco puede descargar de Modrinth, la copia del archivo subida a GitHub ("mirror").
function sharedAutoMods(key) {
  const list = st.data?.autoMods?.[key];
  return Array.isArray(list) ? list : null;
}
async function saveSharedAutoMods(entries, modsDir) {
  if (!isStaff() || st.provider?.kind !== 'github' || !st.provider.token) return;
  const changes = {};
  for (const { key, mods } of entries) {
    const prev = sharedAutoMods(key) || [];
    const out = [];
    let changed = prev.length !== mods.length;
    for (const m of mods) {
      const old = prev.find((x) => x.file === m.file && x.sha1 === m.sha1);
      let mirror = old?.mirror;
      if (!mirror) {
        changed = true;
        try {
          const buf = await fs.promises.readFile(path.join(modsDir, path.basename(m.file)));
          mirror = await st.provider.putFile(`auto/${path.basename(m.file)}`, buf);
        } catch { mirror = undefined; }
      }
      out.push({ ...m, ...(mirror ? { mirror } : {}) });
    }
    if (changed) changes[key] = out;
  }
  if (!Object.keys(changes).length) return;
  await mutate((d) => {
    d.autoMods = isObj(d.autoMods) ? d.autoMods : {};
    Object.assign(d.autoMods, changes);
  }, 'Copia de los mods del launcher (menú, pantalla de carga, skins)');
}

module.exports = {
  sharedAutoMods, saveSharedAutoMods,
  boot, refresh, view, getData: () => st.data, getSession: () => st.session,
  requireDev, requireStaff, requireSession, isStaff,
  loginPlayer, loginDev, logout, connectWithCode,
  publish, saveInstances, getInstance, addMods, removeMod, putFile, setInstanceFiles,
  createPlayer, updatePlayer, deletePlayer, createDev, updateDev, deleteDev,
  setSkinsRepo, skinsProvider, getSkinsTokenSafe,
  connectGithub, useLocal, setUpdate, bundledFile,
  _internal: { st, normalizeData, deepMerge },
};
