'use strict';
/* =====================================================================
   Caldito Launcher · Reparar (actualizaciones sin reinstalar + arreglos)
   ===================================================================== */
(() => {
  const { S, $, $$, esc, act, toast, confirmBox, openModal, fmtDate } = CA;
  const api = window.caldito;
  let installed = false;

  async function render() {
    const u = (S.updateInfo = await api.update.status());
    $('#upRunning').textContent = u.running;
    $('#upPublished').textContent = u.published?.version || '—';
    $('#upInstalled').textContent = u.installed;
    const pill = $('#upPill');
    if (installed) { pill.textContent = 'Lista: reinicia'; pill.className = 'pill ok'; }
    else if (u.available) { pill.textContent = 'Actualización disponible'; pill.className = 'pill ok'; }
    else if (u.needsReinstall) { pill.textContent = 'Requiere reinstalar'; pill.className = 'pill warn'; }
    else { pill.textContent = 'Al día'; pill.className = 'pill muted'; }
    const p = u.published;
    $('#upNotes').innerHTML = [
      p ? `<b>Versión ${esc(p.version)}</b>${p.publishedAt ? ` · publicada el ${esc(fmtDate(p.publishedAt))}${p.publishedBy ? ' por ' + esc(p.publishedBy) : ''}` : ''}${p.notes ? `<br>${esc(p.notes).replace(/\n/g, '<br>')}` : ''}` : 'El equipo aún no ha publicado actualizaciones.',
      u.needsReinstall ? `<br>⚠️ Esta versión necesita reinstalar el launcher (programa ${esc(p.minShell)} o superior). Pide el instalador nuevo al equipo.` : '',
      u.usingUpdate ? `<br>Estás usando una actualización descargada sobre la versión instalada ${esc(u.installed)}.` : '',
      u.note ? `<br>⚠️ ${esc(u.note)}` : '',
    ].join('');
    $('#upInstall').hidden = !(u.available || installed);
    $('#upInstall').textContent = installed ? 'Reiniciar ahora' : 'Actualizar ahora';
    $('#upRevert').hidden = !u.usingUpdate;
    $('#repInstance').innerHTML = CA.instances().map((i) => `<option value="${esc(i.id)}" ${i.id === CA.selInstance()?.id ? 'selected' : ''}>${esc(i.name)}</option>`).join('');
    $('#diagText').textContent = await api.repair.diagnostics().catch((e) => e.message);
    CA.applyAll?.();
  }
  CA.hooks.repair = () => act(null, render);

  api.onUpdateProgress(({ task, done, total }) => {
    $('#upBarWrap').hidden = false;
    $('#upBar').style.width = `${total ? Math.min(100, (done / total) * 100) : 0}%`;
    $('#upNotes').textContent = task + (total > 10000 ? ` · ${(done / 1048576).toFixed(1)} / ${(total / 1048576).toFixed(1)} MB` : '');
  });

  $('#upCheck').addEventListener('click', (e) => act(e.currentTarget, async () => {
    await CA.periodicRefresh();
    await render();
    return S.updateInfo;
  }, (u) => (u.available ? `Hay una versión nueva: ${u.published.version}` : 'Ya tienes la última versión')));

  $('#upInstall').addEventListener('click', (e) => {
    if (installed) return api.update.restart();
    act(e.currentTarget, async () => {
      const v = await api.update.install();
      installed = true;
      $('#upBarWrap').hidden = true;
      await render();
      openModal({
        title: `Actualización ${v} lista`,
        html: '<p class="hint">Reinicia el launcher para usar la versión nueva. No hace falta reinstalar nada.</p>',
        actions: [{ label: 'Más tarde' }, { label: 'Reiniciar ahora', kind: 'primary', onClick: () => api.update.restart() }],
      });
      return v;
    });
  });

  $('#upRevert').addEventListener('click', async () => {
    if (!(await confirmBox('Volver a la versión instalada', 'El launcher se reiniciará con la versión que venía en el instalador. Podrás actualizar de nuevo cuando quieras.', 'Volver y reiniciar'))) return;
    await act(null, () => api.update.revert());
    api.update.restart();
  });

  api.onRepairProgress(({ task, done, total }) => {
    $('#repStatus').textContent = `🔧 ${task || 'Reparando'}${total > 1 ? ` · ${done}/${total}` : ''}`;
  });
  $$('[data-repair]').forEach((b) => b.addEventListener('click', async () => {
    const tool = b.dataset.repair;
    const labels = { mods: 'reinstalar los mods', minecraft: 'reinstalar Minecraft', java: 'reinstalar Java', cache: 'recargar los datos', settings: 'restablecer los ajustes de este PC' };
    if (S.running) return toast('Cierra Minecraft antes de reparar.', 'err');
    if (tool !== 'cache' && !(await confirmBox('Reparar', `¿Seguro que quieres ${labels[tool]}? Tus mundos y capturas no se tocan.`, 'Sí, reparar'))) return;
    const msg = await act(b, () => api.repair.run(tool, $('#repInstance').value));
    $('#repStatus').textContent = msg ? '✔ ' + msg : '';
    if (msg) toast(msg, 'ok');
    if (tool === 'cache') await CA.periodicRefresh();
    if (tool === 'settings') S.pc = await api.pc.get();
    render();
  }));
  $('#repFolder').addEventListener('click', (e) => act(e.currentTarget, () => api.openFolder('launcher')));
  $('#diagCopy').addEventListener('click', () => { navigator.clipboard.writeText($('#diagText').textContent); toast('Diagnóstico copiado', 'ok'); });

  // --- Publicar (desarrolladores) ---
  $('#upPublish').addEventListener('click', (e) => act(e.currentTarget, async () => {
    const v = await api.update.publish($('#upPubNotes').value.trim());
    if (!v) return null;
    S.view = v;
    $('#upPubNotes').value = '';
    await render();
    return v.update.version;
  }, (ver) => (ver ? `Actualización ${ver} publicada para todos` : null)));
  $('#upRetire').addEventListener('click', async (e) => {
    if (!(await confirmBox('Retirar actualización', 'Los launchers dejarán de ofrecerla. Quien ya la instaló la conserva.', 'Retirar', true))) return;
    act(e.currentTarget, async () => { S.view = await api.update.retire(); await render(); }, 'Actualización retirada');
  });
})();
