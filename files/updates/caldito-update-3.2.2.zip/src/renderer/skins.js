'use strict';
/* =====================================================================
   Caldito Launcher · Skins y capas (todos los usuarios con sesión)
   ===================================================================== */
(() => {
  const { S, $, $$, esc, act, toast, confirmBox, openModal } = CA;
  const api = window.caldito;

  let data = null;            // { skins, capes, active, microsoft }
  let selSkin = null, selCape = 'none';
  let viewer = null, elytra = false;

  /* ---------- vista 3D ---------- */
  function ensureViewer() {
    if (viewer || !window.skinview3d) return;
    const canvas = $('#skinCanvas');
    viewer = new skinview3d.SkinViewer({ canvas, width: 320, height: 420 });
    viewer.zoom = 0.85;
    viewer.fov = 50;
    viewer.autoRotate = true;
    viewer.autoRotateSpeed = 0.6;
    viewer.animation = new skinview3d.IdleAnimation();
    const wrap = $('#stageCanvas');
    const resize = () => { const r = wrap.getBoundingClientRect(); if (r.width > 0 && r.height > 0) viewer.setSize(Math.floor(r.width), Math.floor(r.height)); };
    new ResizeObserver(resize).observe(wrap);
    resize();
  }
  async function showInViewer() {
    ensureViewer();
    if (!viewer) return;
    const skin = data.skins.find((s) => s.id === selSkin);
    try {
      if (skin) await viewer.loadSkin(skin.img, { model: skin.model === 'slim' ? 'slim' : 'default' });
      else viewer.resetSkin();
      const cape = data.capes.find((c) => c.key === selCape);
      if (cape) await viewer.loadCape(cape.img, { backEquipment: elytra ? 'elytra' : 'cape' });
      else viewer.resetCape();
    } catch { /* imagen inválida: se ignora */ }
    $('#skinSelName').textContent = skin ? skin.name : 'Skin por defecto';
    const cape = data.capes.find((c) => c.key === selCape);
    $('#skinSelInfo').textContent = `${skin ? (skin.model === 'slim' ? 'Brazos finos' : 'Brazos normales') : 'Sin skin propia'} · ${cape ? 'Capa ' + cape.name : 'Sin capa'}`;
  }
  $('#svWalk').addEventListener('click', (e) => {
    if (!viewer) return;
    const walking = viewer.animation instanceof skinview3d.WalkingAnimation;
    viewer.animation = walking ? new skinview3d.IdleAnimation() : new skinview3d.WalkingAnimation();
    e.currentTarget.classList.toggle('on', !walking);
  });
  $('#svSpin').addEventListener('click', (e) => { if (!viewer) return; viewer.autoRotate = !viewer.autoRotate; e.currentTarget.classList.toggle('on', viewer.autoRotate); });
  $('#svElytra').addEventListener('click', (e) => { elytra = !elytra; e.currentTarget.classList.toggle('on', elytra); showInViewer(); });

  /* ---------- miniaturas 2D ---------- */
  function loadImg(src) { return new Promise((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = rej; i.src = src; }); }
  async function drawSkinFront(canvas, src, slim) {
    const img = await loadImg(src);
    canvas.width = 16; canvas.height = 32;
    const c = canvas.getContext('2d');
    c.imageSmoothingEnabled = false;
    const legacy = img.height === 32;
    const aw = slim ? 3 : 4;
    const part = (sx, sy, w, h, dx, dy, mirror = false) => {
      if (!mirror) return c.drawImage(img, sx, sy, w, h, dx, dy, w, h);
      c.save(); c.translate(dx + w, dy); c.scale(-1, 1); c.drawImage(img, sx, sy, w, h, 0, 0, w, h); c.restore();
    };
    part(8, 8, 8, 8, 4, 0); part(40, 8, 8, 8, 4, 0);
    part(20, 20, 8, 12, 4, 8);
    part(44, 20, aw, 12, 4 - aw, 8);
    if (legacy) part(44, 20, aw, 12, 12, 8, true); else part(36, 52, aw, 12, 12, 8);
    part(4, 20, 4, 12, 4, 20);
    if (legacy) part(4, 20, 4, 12, 8, 20, true); else part(20, 52, 4, 12, 8, 20);
    if (!legacy) { part(20, 36, 8, 12, 4, 8); part(44, 36, aw, 12, 4 - aw, 8); part(52, 52, aw, 12, 12, 8); part(4, 36, 4, 12, 4, 20); part(4, 52, 4, 12, 8, 20); }
  }
  async function drawCape(canvas, src) {
    const img = await loadImg(src);
    const k = img.width / 64;
    canvas.width = 10; canvas.height = 16;
    const c = canvas.getContext('2d');
    c.imageSmoothingEnabled = false;
    c.drawImage(img, 1 * k, 1 * k, 10 * k, 16 * k, 0, 0, 10, 16);
  }

  /* ---------- listas ---------- */
  function renderSkins() {
    const grid = $('#skinGrid');
    grid.innerHTML = data.skins.map((s) => `
      <div class="skin-card ${s.id === selSkin ? 'sel' : ''} ${s.id === data.active.skin ? 'active' : ''}" data-skin="${s.id}">
        <canvas></canvas><b title="${esc(s.name)}">${esc(s.name)}</b><small>${s.model === 'slim' ? 'Brazos finos' : 'Normal'}</small>
        <div class="card-actions">
          <button class="icon-btn" data-sk-model="${s.id}" title="Cambiar tipo de brazos">💪</button>
          <button class="icon-btn" data-sk-rename="${s.id}" title="Renombrar">✏️</button>
          <button class="icon-btn danger" data-sk-del="${s.id}" title="Eliminar">🗑</button>
        </div>
      </div>`).join('') || '<div class="empty small" style="grid-column:1/-1">Aún no tienes skins. Sube un PNG de 64×64 o copia la de un jugador premium.</div>';
    $$('#skinGrid [data-skin]').forEach((el) => {
      const s = data.skins.find((x) => x.id === el.dataset.skin);
      drawSkinFront($('canvas', el), s.img, s.model === 'slim').catch(() => {});
      el.addEventListener('click', (e) => { if (e.target.closest('button')) return; selSkin = s.id; renderSkins(); showInViewer(); });
    });
  }
  function renderCapes() {
    const grid = $('#capeGrid');
    grid.innerHTML = `<div class="skin-card ${selCape === 'none' ? 'sel' : ''} ${data.active.cape === 'none' ? 'active' : ''}" data-cape="none"><div class="none-cape">∅</div><b>Sin capa</b><small>—</small></div>` +
      data.capes.map((c) => `
      <div class="skin-card ${c.key === selCape ? 'sel' : ''} ${c.key === data.active.cape ? 'active' : ''}" data-cape="${esc(c.key)}">
        <canvas></canvas><b title="${esc(c.name)}">${esc(c.name)}</b><small>${esc(c.kind)}</small>
        ${c.kind === 'Propia' ? `<div class="card-actions"><button class="icon-btn danger" data-cp-del="${c.id}" title="Eliminar">🗑</button></div>` : ''}
      </div>`).join('');
    $$('#capeGrid [data-cape]').forEach((el) => {
      const c = data.capes.find((x) => x.key === el.dataset.cape);
      if (c) drawCape($('canvas', el), c.img).catch(() => {});
      el.addEventListener('click', (e) => { if (e.target.closest('button')) return; selCape = el.dataset.cape; renderCapes(); showInViewer(); });
    });
  }
  function renderHelp() {
    const sk = S.view.skins;
    const name = (() => { let n = String(S.view.session?.name || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^A-Za-z0-9_]/g, '_').slice(0, 16); return n.length < 3 ? (n + '___').slice(0, 3) : n; })();
    const url = sk.repo ? `https://raw.githubusercontent.com/${sk.repo}/${sk.branch || 'main'}/skins/${name}.png` : '';
    $('#skinHelp').innerHTML = sk.canUpload
      ? `✅ <b>Skins compartidas activas.</b> Al pulsar "Ponérmela", tu skin y tu capa se suben para todos. Se ven en instancias con Fabric o Quilt (el launcher instala CustomSkinLoader solo).
         <br>En servidores con <b>SkinsRestorer</b> también puedes usar en el chat: <span class="mono">/skin url ${esc(url)}</span> <button class="link" id="srCopy">Copiar</button>`
      : `ℹ️ Tu skin y tu capa se verán <b>en tu juego</b> en instancias con Fabric o Quilt. ${S.view.session?.role === 'dev' ? 'Activa el <b>repositorio de skins</b> en Conexión para que todos se vean entre sí.' : 'Cuando el equipo active las skins compartidas, todos te verán.'}
         Con cuenta <b>premium</b> puedes ponerla también en tu cuenta oficial.`;
    $('#srCopy')?.addEventListener('click', () => { navigator.clipboard.writeText(`/skin url ${url}`); toast('Comando copiado', 'ok'); });
  }
  async function renderPremium() {
    const box = $('#premiumBody');
    if (!data.microsoft) {
      box.innerHTML = `<div class="card"><h3>Cuenta premium</h3><p class="hint">Si tienes Minecraft original, vincula tu cuenta de Microsoft para cambiar tu skin oficial y elegir tus capas de Mojang (Migrator, Vanilla, eventos…).</p>
        <div class="row"><button class="primary" id="pmLink">Vincular cuenta de Microsoft</button></div></div>`;
      $('#pmLink').addEventListener('click', (e) => act(e.currentTarget, async () => { await api.auth.microsoft(); S.pc = await api.pc.get(); await load(); CA.applyAll(); }, 'Cuenta vinculada'));
      return;
    }
    box.innerHTML = `<div class="card"><h3>Cuenta premium: ${esc(data.microsoft)}</h3><p class="hint">Tus capas oficiales de Mojang. Se ven en cualquier servidor premium.</p><div class="mojang-capes" id="mjCapes"><div class="empty small">Cargando…</div></div></div>`;
    try {
      const prof = await api.skins.mojangProfile();
      const cards = prof.capes.map((c) => `<div class="skin-card ${c.active ? 'active sel' : ''}"><canvas data-src="${esc(c.url.replace('http://', 'https://'))}"></canvas><b>${esc(c.alias)}</b>
        <button class="ghost small" data-mj="${esc(c.id)}">${c.active ? 'En uso' : 'Usar'}</button></div>`).join('');
      $('#mjCapes').innerHTML = cards + `<div class="skin-card"><div class="none-cape">∅</div><b>Ninguna</b><button class="ghost small" data-mj="">Ocultar capa</button></div>`;
      $$('#mjCapes canvas').forEach((cv) => drawCape(cv, cv.dataset.src).catch(() => {}));
      $$('#mjCapes [data-mj]').forEach((b) => b.addEventListener('click', () => act(b, async () => { await api.skins.mojangCape(b.dataset.mj || null); await renderPremium(); }, 'Capa de Mojang actualizada')));
      if (!prof.capes.length) $('#mjCapes').insertAdjacentHTML('afterbegin', '<p class="hint" style="grid-column:1/-1">Esta cuenta no tiene capas de Mojang.</p>');
    } catch (e) {
      $('#mjCapes').innerHTML = `<div class="empty small">${esc(e.message)}</div>`;
    }
  }

  async function load() {
    data = await api.skins.list();
    if (selSkin == null || !data.skins.find((s) => s.id === selSkin)) selSkin = data.active.skin || data.skins[0]?.id || null;
    if (!data.capes.find((c) => c.key === selCape) && selCape !== 'none') selCape = 'none';
    if (selCape === 'none' && data.active.cape) selCape = data.active.cape;
    $('#premiumWrap').hidden = !data.microsoft;
    renderSkins(); renderCapes(); renderHelp(); showInViewer();
    if (!$('#skinPane-premium').hidden) renderPremium();
  }
  CA.hooks.skins = () => act(null, load);

  $$('#skinTabs [data-st]').forEach((b) => b.addEventListener('click', () => {
    $$('#skinTabs [data-st]').forEach((x) => x.classList.toggle('on', x === b));
    for (const p of ['skins', 'capes', 'premium']) $('#skinPane-' + p).hidden = p !== b.dataset.st;
    if (b.dataset.st === 'premium') renderPremium();
  }));

  /* ---------- acciones ---------- */
  $('#skinUpload').addEventListener('click', (e) => act(e.currentTarget, async () => {
    const id = await api.skins.upload('skin');
    if (id) { selSkin = id; await load(); }
    return id;
  }, (id) => (id ? 'Skin añadida' : null)));
  $('#capeUpload').addEventListener('click', (e) => act(e.currentTarget, async () => {
    const id = await api.skins.upload('cape');
    if (id) { selCape = 'custom:' + id; await load(); }
    return id;
  }, (id) => (id ? 'Capa añadida' : null)));
  $('#skinImportForm').addEventListener('submit', (e) => {
    e.preventDefault();
    act($('button', e.target), async () => {
      const id = await api.skins.importName($('#skinImportName').value);
      $('#skinImportName').value = '';
      selSkin = id; await load();
    }, 'Skin copiada');
  });
  $('#skinGrid').addEventListener('click', async (e) => {
    const b = e.target.closest('button');
    if (!b) return;
    if (b.dataset.skModel) {
      const s = data.skins.find((x) => x.id === b.dataset.skModel);
      await act(b, () => api.skins.update(s.id, { model: s.model === 'slim' ? 'classic' : 'slim' }));
      await load();
    } else if (b.dataset.skRename) {
      const s = data.skins.find((x) => x.id === b.dataset.skRename);
      openModal({
        title: 'Renombrar skin', html: `<label class="field">Nombre<input id="rnName" value="${esc(s.name)}" maxlength="32" /></label>`,
        actions: [{ label: 'Cancelar' }, { label: 'Guardar', kind: 'primary', onClick: async () => { await act(null, () => api.skins.update(s.id, { name: $('#rnName').value })); await load(); } }],
      });
    } else if (b.dataset.skDel) {
      if (!(await confirmBox('Eliminar skin', 'Se borrará de tu biblioteca.', 'Eliminar', true))) return;
      await act(b, () => api.skins.remove('skin', b.dataset.skDel));
      selSkin = null; await load();
    }
  });
  $('#capeGrid').addEventListener('click', async (e) => {
    const b = e.target.closest('[data-cp-del]');
    if (!b) return;
    if (!(await confirmBox('Eliminar capa', 'Se borrará de tu biblioteca.', 'Eliminar', true))) return;
    await act(b, () => api.skins.remove('cape', b.dataset.cpDel));
    await load();
  });
  $('#skinApply').addEventListener('click', (e) => act(e.currentTarget, async () => {
    const r = await api.skins.apply({ skinId: selSkin, capeKey: selCape, premium: $('#skinPremium').checked });
    $('#skinApplied').innerHTML = '✔ Aplicada: ' + r.done.map(esc).join(' · ');
    await load();
    return r;
  }, '¡Skin y capa puestas!'));
})();
