'use strict';
// Llave con la que se firman los códigos de jugador. Es la misma en todos los launchers de Caldito,
// así que un código creado en el PC de un desarrollador funciona en el PC de cualquier jugador.
// Si se cambia, todos los códigos de jugador creados antes dejan de funcionar.
module.exports = Buffer.from('er2tWtncEJ2kFvAZekL+Bazb5FSIPChS4NGwnvDTXSI=', 'base64');
