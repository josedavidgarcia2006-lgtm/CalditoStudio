'use strict';
// Server List Ping (protocolo de estado de Minecraft Java), sin dependencias.
const net = require('net');
const dns = require('dns').promises;

function varint(n) {
  const out = [];
  n >>>= 0;
  do {
    let b = n & 0x7f;
    n >>>= 7;
    if (n) b |= 0x80;
    out.push(b);
  } while (n);
  return Buffer.from(out);
}

function readVarint(buf, offset) {
  let num = 0, shift = 0, pos = offset;
  while (true) {
    if (pos >= buf.length) return null;
    const b = buf[pos++];
    num |= (b & 0x7f) << shift;
    if (!(b & 0x80)) return { value: num, size: pos - offset };
    shift += 7;
    if (shift > 35) throw new Error('VarInt demasiado grande');
  }
}

function packet(id, payload = Buffer.alloc(0)) {
  const body = Buffer.concat([varint(id), payload]);
  return Buffer.concat([varint(body.length), body]);
}

function mcString(s) {
  const b = Buffer.from(s, 'utf8');
  return Buffer.concat([varint(b.length), b]);
}

async function resolve(host, port) {
  if (port !== 25565 || net.isIP(host)) return { host, port };
  try {
    const [srv] = await dns.resolveSrv(`_minecraft._tcp.${host}`);
    if (srv) return { host: srv.name, port: srv.port };
  } catch {}
  return { host, port };
}

/** Convierte el MOTD (texto o componente JSON) a texto plano. */
function flattenMotd(desc) {
  if (!desc) return '';
  if (typeof desc === 'string') return desc.replace(/§./g, '');
  let s = desc.text || '';
  if (Array.isArray(desc.extra)) s += desc.extra.map(flattenMotd).join('');
  return s.replace(/§./g, '');
}

async function ping(hostIn, portIn = 25565, timeout = 5000) {
  const { host, port } = await resolve(hostIn, portIn);
  return new Promise((res, rej) => {
    const sock = net.createConnection({ host, port });
    let buf = Buffer.alloc(0);
    let start = 0;
    const fail = (e) => { sock.destroy(); rej(e); };
    sock.setTimeout(timeout, () => fail(new Error('Tiempo de espera agotado')));
    sock.on('error', fail);

    sock.on('connect', () => {
      const port16 = Buffer.alloc(2);
      port16.writeUInt16BE(port);
      const handshake = Buffer.concat([varint(767), mcString(hostIn), port16, varint(1)]);
      sock.write(packet(0x00, handshake));
      start = Date.now();
      sock.write(packet(0x00));
    });

    sock.on('data', (chunk) => {
      buf = Buffer.concat([buf, chunk]);
      try {
        const len = readVarint(buf, 0);
        if (!len || buf.length < len.size + len.value) return;
        let off = len.size;
        const id = readVarint(buf, off); off += id.size;
        const strLen = readVarint(buf, off); off += strLen.size;
        const json = JSON.parse(buf.slice(off, off + strLen.value).toString('utf8'));
        const latency = Date.now() - start;
        sock.destroy();
        res({
          online: true,
          latency,
          version: json.version?.name || '',
          players: { online: json.players?.online ?? 0, max: json.players?.max ?? 0, sample: (json.players?.sample || []).map((p) => p.name) },
          motd: flattenMotd(json.description),
          favicon: json.favicon || null,
        });
      } catch (e) {
        fail(e);
      }
    });
  });
}

module.exports = { ping, flattenMotd };
