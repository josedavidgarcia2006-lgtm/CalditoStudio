'use strict';
/* =====================================================================
   Caldito Launcher · panel del equipo (moderadores y desarrolladores):
   instancias y mods. El proceso principal vuelve a comprobar el rol.
   ===================================================================== */
(() => {
  const { S, $, $$, esc, clone, act, toast, openModal, confirmBox } = CA;
  const api = window.caldito;
  const staff = api.staff;

  /* ---------------- INSTANCIAS ---------------- */
  let draft = null;      // copia en edición de la lista
  let selected = null;   // id de la instancia abierta
  const list = () => draft || S.view.instances;
  const dirty = () => { $('#instBar').hidden = false; };

  function renderList() {
    const items = list();
    if (!items.find((i) => i.id === selected)) selected = items[0]?.id;
    $('#instList').innerHTML = items.map((i, n) => `
      <button class="inst-item ${i.id === selected ? 'on' : ''}" data-open="${esc(i.id)}">
        <span class="inst-icon" data-icon="${n}"></span>
        <span class="meta"><b>${esc(i.name || 'Sin nombre')}</b><small>${esc(i.host || 'sin dirección')} · ${i.loader}${i.visible === false ? ' · oculta' : ''}</small></span>
      </button>`).join('');
    $$('#instList [data-icon]').forEach((el) => {
      const i = items[+el.dataset.icon];
      el.style.backgroundImage = i.image ? `url("${i.image}")` : '';
      el.textContent = i.image ? '' : i.icon || '🎮';
    });
    $$('#instList [data-open]').forEach((b) => b.addEventListener('click', () => { selected = b.dataset.open; renderAll(); }));
  }

  const F = (key, label, attrs = '') => `<label class="field">${label}<input data-k="${key}" value="${esc(cur()[key] ?? '')}" ${attrs} /></label>`;
  const cur = () => list().find((i) => i.id === selected);

  function renderEditor() {
    const i = cur();
    const box = $('#instEditor');
    if (!i) { box.innerHTML = '<div class="empty">Crea una instancia.</div>'; return; }
    const st = S.statuses[i.id];
    box.innerHTML = `
      <div class="row between"><h2>${esc(i.name || 'Sin nombre')}</h2>
        <div class="row"><button class="icon-btn" data-move="-1" title="Subir">↑</button><button class="icon-btn" data-move="1" title="Bajar">↓</button>
        <button class="ghost" id="instDup">Duplicar</button><button class="ghost danger" id="instDel">Eliminar</button></div></div>
      <p class="hint" style="margin-bottom:14px">${st ? (st.online ? `🟢 En línea · ${st.players.online}/${st.players.max} jugadores · ${esc(st.version)}` : '🔴 El servidor no responde ahora mismo.') : 'Estado sin comprobar.'}</p>

      <div class="card"><h3>Presentación</h3>
        <div class="grid-2">${F('name', 'Nombre', 'maxlength="40"')}${F('icon', 'Icono (emoji)', 'maxlength="4"')}</div>
        ${F('description', 'Descripción corta', 'maxlength="90"')}
        <div class="img-field"><div class="thumb" style="background-image:url('${esc(i.image || '')}')"></div>
          <span class="hint grow">Imagen de la instancia (opcional, sustituye al icono).</span>
          <button class="ghost" id="instImg">Subir imagen</button><button class="ghost" id="instImgDel">Quitar</button></div>
        <div class="toggle-row"><div><b>Visible para jugadores</b><small>Ocúltala mientras la preparas.</small></div><button class="switch ${i.visible !== false ? 'on' : ''}" data-tg="visible"></button></div>
      </div>

      <div class="card"><h3>Servidor</h3>
        <div class="grid-2">${F('host', 'Dirección (IP o dominio)')}${F('port', 'Puerto', 'type="number" min="1" max="65535"')}</div>
        <div class="row end"><button class="ghost" id="instTest">Probar conexión</button></div>
      </div>

      <div class="card"><h3>Juego</h3>
        <div class="grid-2">
          <label class="field">Versión de Minecraft
            <select data-k="mcMode"><option value="auto" ${i.mcVersion === 'auto' ? 'selected' : ''}>Automática (la detecta del servidor)</option><option value="fixed" ${i.mcVersion !== 'auto' ? 'selected' : ''}>Fija</option></select></label>
          ${i.mcVersion === 'auto' ? F('fallbackVersion', 'Versión si no se puede detectar', 'placeholder="1.21.1"') : F('mcVersion', 'Versión fija', 'placeholder="1.21.1"')}
          <label class="field">Cargador de mods
            <select data-k="loader">${[['vanilla', 'Vanilla (sin mods)'], ['fabric', 'Fabric'], ['quilt', 'Quilt']].map(([v, l]) => `<option value="${v}" ${i.loader === v ? 'selected' : ''}>${l}</option>`).join('')}</select></label>
          ${F('loaderVersion', 'Versión del cargador', 'placeholder="latest"')}
          <label class="field">Tipo de cuenta
            <select data-k="authMode"><option value="offline" ${i.authMode === 'offline' ? 'selected' : ''}>Sin premium (nombre del código)</option><option value="microsoft" ${i.authMode === 'microsoft' ? 'selected' : ''}>Premium (cuenta de Microsoft)</option></select></label>
          ${F('ramMB', 'RAM recomendada (MB)', 'type="number" min="1024" step="256"')}
        </div>
        <div class="toggle-row"><div><b>Menú Permadeath y pantalla de carga de Caldito</b><small>Instala FancyMenu y Drippy Loading Screen con el diseño de Caldito. Solo con Fabric o Quilt.</small></div><button class="switch ${i.menu !== false ? 'on' : ''}" data-tg="menu"></button></div>
        <div class="toggle-row"><div><b>Skins y capas de Caldito</b><small>Instala CustomSkinLoader para ver las skins y capas del launcher. Solo con Fabric o Quilt.</small></div><button class="switch ${i.skins !== false ? 'on' : ''}" data-tg="skins"></button></div>
        <p class="hint">Mods de esta instancia: <b>${(i.mods || []).length}</b> · <button class="link" id="instMods">Gestionar mods →</button></p>
      </div>`;

    box.querySelectorAll('[data-k]').forEach((el) => el.addEventListener(el.tagName === 'SELECT' ? 'change' : 'input', () => {
      ensure();
      const x = cur();
      const k = el.dataset.k;
      if (k === 'mcMode') { x.mcVersion = el.value === 'auto' ? 'auto' : x.fallbackVersion || '1.21.1'; renderEditor(); }
      else if (k === 'port' || k === 'ramMB') x[k] = Number(el.value);
      else x[k] = el.value;
      if (k === 'name' || k === 'icon' || k === 'host' || k === 'loader') renderList();
      if (k === 'loader') renderEditor();
      dirty();
    }));
    box.querySelectorAll('[data-tg]').forEach((b) => b.addEventListener('click', () => {
      ensure();
      const on = !b.classList.contains('on');
      b.classList.toggle('on', on);
      cur()[b.dataset.tg] = on;
      renderList();
      dirty();
    }));
    box.querySelectorAll('[data-move]').forEach((b) => b.addEventListener('click', () => {
      ensure();
      const arr = draft, idx = arr.findIndex((x) => x.id === selected), j = idx + Number(b.dataset.move);
      if (j < 0 || j >= arr.length) return;
      [arr[idx], arr[j]] = [arr[j], arr[idx]];
      renderList(); dirty();
    }));
    $('#instDup').addEventListener('click', () => {
      ensure();
      const copy = { ...clone(cur()), id: 'i' + Date.now().toString(36), name: cur().name + ' (copia)', mods: clone(cur().mods || []) };
      draft.splice(draft.findIndex((x) => x.id === selected) + 1, 0, copy);
      selected = copy.id; renderAll(); dirty();
    });
    $('#instDel').addEventListener('click', async () => {
      if (list().length < 2) return toast('Debe quedar al menos una instancia.', 'err');
      if (!(await confirmBox('Eliminar instancia', `Se eliminará <b>${esc(cur().name)}</b> para todos al guardar. Los mundos de cada jugador se quedan en su PC.`, 'Eliminar', true))) return;
      ensure();
      draft = draft.filter((x) => x.id !== selected);
      selected = draft[0]?.id; renderAll(); dirty();
    });
    $('#instImg').addEventListener('click', (e) => act(e.currentTarget, async () => {
      const img = await staff.pickImage();
      if (img) { ensure(); cur().image = img; renderAll(); dirty(); }
    }));
    $('#instImgDel').addEventListener('click', () => { ensure(); cur().image = ''; renderAll(); dirty(); });
    $('#instTest').addEventListener('click', (e) => act(e.currentTarget, async () => {
      const r = await api.ping({ host: cur().host, port: cur().port });
      S.statuses[cur().id] = r;
      return r;
    }, (r) => `Conectado: ${r.version} · ${r.players.online}/${r.players.max} jugadores · ${r.latency} ms`));
    $('#instMods').addEventListener('click', () => { modInstance = selected; CA.go('mods'); });
  }
  function ensure() { if (!draft) draft = clone(S.view.instances); }
  function renderAll() { renderList(); renderEditor(); }

  $('#instNew').addEventListener('click', () => {
    ensure();
    const base = clone(S.defaultInstance || {});
    const n = { ...base, id: 'i' + Date.now().toString(36), name: 'Nueva instancia', description: '', host: '', icon: '⛏️', visible: false, mods: [] };
    draft.push(n);
    selected = n.id; renderAll(); dirty();
  });
  $('#instDiscard').addEventListener('click', async () => {
    if (!(await confirmBox('Descartar cambios', 'Se perderán los cambios de instancias sin guardar.', 'Descartar', true))) return;
    draft = null; $('#instBar').hidden = true; renderAll();
  });
  $('#instSave').addEventListener('click', (e) => act(e.currentTarget, async () => {
    S.view = await staff.saveInstances(draft || S.view.instances);
    draft = null;
    $('#instBar').hidden = true;
    renderAll();
    CA.applyAll();
    CA.refreshStatus();
  }, 'Instancias publicadas'));

  CA.hooks.instances = () => { renderAll(); };

  /* ---------------- MODS ---------------- */
  let modInstance = null;
  let modCtx = null;
  const instOf = () => S.view.instances.find((i) => i.id === modInstance) || S.view.instances[0];
  function renderModSelect() {
    if (!S.view.instances.find((i) => i.id === modInstance)) modInstance = CA.selInstance()?.id || S.view.instances[0]?.id;
    $('#modInstance').innerHTML = S.view.instances.map((i) => `<option value="${esc(i.id)}" ${i.id === modInstance ? 'selected' : ''}>${esc(i.icon || '')} ${esc(i.name)}</option>`).join('');
  }
  function renderMods() {
    const mods = instOf()?.mods || [];
    $('#modCount').textContent = mods.length;
    $('#modList').innerHTML = mods.map((m) => `
      <li>
        ${m.icon ? `<img class="mod-icon" src="${esc(m.icon)}" alt="" />` : '<span class="mod-icon">🧩</span>'}
        <div class="mod-main"><b>${esc(m.name)}</b><small>${esc(m.file)}${m.size ? ' · ' + (m.size / 1048576).toFixed(1) + ' MB' : ''}${m.version ? ' · v' + esc(m.version) : ''}</small></div>
        <span class="badge ${m.source}">${{ modrinth: 'Modrinth', upload: 'Subido', url: 'Enlace' }[m.source] || m.source}</span>
        <button class="icon-btn danger" data-mod-del="${m.id}" title="Quitar">🗑</button>
      </li>`).join('') || '<li class="empty small">Esta instancia aún no tiene mods.</li>';
    $$('[data-mod-del]').forEach((b) => b.addEventListener('click', async () => {
      const m = mods.find((x) => x.id === b.dataset.modDel);
      if (!(await confirmBox('Quitar mod', `Se quitará <b>${esc(m.name)}</b> de "${esc(instOf().name)}" para todos la próxima vez que jueguen.`, 'Quitar', true))) return;
      const v = await act(b, () => staff.modRemove(modInstance, m.id), 'Mod quitado');
      if (v) { S.view = v; renderMods(); }
    }));
  }
  async function loadModCtx() {
    try {
      modCtx = await staff.modContext(modInstance);
      $('#modVanilla').hidden = true;
      $('#modCtx').textContent = `Minecraft ${modCtx.version} · ${modCtx.loader[0].toUpperCase() + modCtx.loader.slice(1)}`;
    } catch (e) {
      modCtx = null;
      $('#modVanilla').hidden = false;
      $('#modCtx').textContent = /vanilla/i.test(e.message) ? 'Sin cargador de mods' : e.message;
    }
    for (const id of ['modUpload', 'modUrlToggle']) $('#' + id).disabled = !modCtx;
    $('#mrQuery').disabled = !modCtx;
    $('#mrList').innerHTML = '<li class="empty small">Busca un mod para añadirlo con sus dependencias.</li>';
  }
  // --- Mods desde la carpeta del equipo ---
  async function scanFolder() {
    try {
      const r = await staff.modsFolderScan(modInstance);
      $('#mfList').innerHTML = r.fresh.map((f) => `<li><span class="mod-icon">📦</span><div class="mod-main"><b>${esc(f.file)}</b><small>${(f.size / 1048576).toFixed(1)} MB · nuevo en tu carpeta</small></div></li>`).join('');
      $('#mfPublish').disabled = !r.fresh.length;
      $('#mfPublish').textContent = r.fresh.length ? `Publicar ${r.fresh.length} mod${r.fresh.length > 1 ? 's' : ''} nuevo${r.fresh.length > 1 ? 's' : ''}` : 'Publicar mods nuevos';
      return r;
    } catch (e) { $('#mfList').innerHTML = `<li class="empty small">${esc(e.message)}</li>`; return null; }
  }
  function renderCfg() {
    const i = instOf();
    const n = (i?.files || []).length;
    $('#cfgInfo').innerHTML = i?.menu === false
      ? 'El menú de Caldito está desactivado en esta instancia (actívalo en Instancias).'
      : n ? `Los jugadores reciben <b>tu configuración publicada</b> (${n} archivos de config/fancymenu).`
        : 'Los jugadores ven el <b>menú Permadeath de Caldito</b> y la pantalla de carga de Caldito Studio. Si lo editas dentro de Minecraft (Ctrl+Alt+C), publica aquí tu versión.';
    $('#cfgReset').disabled = !n;
  }
  $('#mfOpen').addEventListener('click', (e) => act(e.currentTarget, () => staff.modsFolderOpen(modInstance)));
  $('#mfScan').addEventListener('click', (e) => act(e.currentTarget, scanFolder, (r) => (r ? (r.fresh.length ? `${r.fresh.length} mods nuevos encontrados` : 'No hay mods nuevos en tu carpeta') : null)));
  $('#mfPublish').addEventListener('click', (e) => act(e.currentTarget, async () => {
    const r = await staff.modsFolderPublish(modInstance);
    S.view = r.view; renderMods(); await scanFolder();
    return r;
  }, (r) => `Publicados ${r.added.length} mods para todos los jugadores`));
  $('#cfgPublish').addEventListener('click', (e) => act(e.currentTarget, async () => {
    const r = await staff.configPublish(modInstance);
    S.view = r.view; renderCfg();
    return r;
  }, (r) => `Configuración publicada (${r.count} archivos)`));
  $('#cfgReset').addEventListener('click', async (e) => {
    if (!(await confirmBox('Volver al menú de Caldito', 'Los jugadores volverán a ver el menú Permadeath que trae el launcher.', 'Volver'))) return;
    act(e.currentTarget, async () => { S.view = await staff.configReset(modInstance); renderCfg(); }, 'Menú de Caldito restaurado');
  });

  CA.hooks.mods = () => { renderModSelect(); renderMods(); loadModCtx(); renderCfg(); scanFolder(); };
  $('#modInstance').addEventListener('change', (e) => { modInstance = e.target.value; renderMods(); loadModCtx(); renderCfg(); scanFolder(); });
  const afterAdd = (r) => { if (r) { S.view = r.view; renderMods(); } return r; };
  $('#modUpload').addEventListener('click', (e) => act(e.currentTarget, async () => afterAdd(await staff.modUpload(modInstance)), (r) => (r ? `Añadido: ${r.added.join(', ')}` : null)));
  $('#modUrlToggle').addEventListener('click', () => { $('#modUrlForm').hidden = !$('#modUrlForm').hidden; $('#modUrl').focus(); });
  $('#modUrlForm').addEventListener('submit', (e) => {
    e.preventDefault();
    const urls = $('#modUrl').value.split(/\s+/).map((u) => u.trim()).filter(Boolean);
    act($('button', e.target), async () => { const r = afterAdd(await staff.modAddUrl(modInstance, urls)); $('#modUrl').value = ''; return r; }, (r) => `Añadidos ${r.added.length}: ${r.added.join(', ')}`);
  });
  $('#mrForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const box = $('#mrList');
    box.innerHTML = '<li class="empty small">Buscando…</li>';
    try {
      const r = await staff.modSearch(modInstance, $('#mrQuery').value.trim());
      const have = new Set((instOf()?.mods || []).map((m) => m.projectId));
      box.innerHTML = r.hits.map((h) => `
        <li>
          ${h.icon ? `<img class="mod-icon" src="${esc(h.icon)}" alt="" />` : '<span class="mod-icon">🧩</span>'}
          <div class="mod-main"><b>${esc(h.title)}</b><small>${esc(h.description)}</small><small>⬇ ${h.downloads.toLocaleString('es')} · ${esc(h.author)}${h.client === 'unsupported' ? ' · solo servidor' : ''}</small></div>
          <button class="ghost small" data-mr="${h.id}" ${have.has(h.id) ? 'disabled' : ''}>${have.has(h.id) ? 'Añadido' : 'Añadir'}</button>
          <input type="checkbox" class="mr-check" data-sel="${h.id}" ${have.has(h.id) ? 'disabled' : ''} title="Seleccionar" />
        </li>`).join('') || '<li class="empty small">Sin resultados para esta versión.</li>';
      $('#mrBulk').hidden = !r.hits.length;
      $('#mrAll').checked = false;
      updateSel();
      $$('[data-mr]', box).forEach((b) => b.addEventListener('click', () => act(b, async () => {
        const res = afterAdd(await staff.modAddModrinth(modInstance, b.dataset.mr));
        b.textContent = 'Añadido';
        setTimeout(() => (b.disabled = true));
        return res;
      }, (res) => `Añadido: ${res.added.join(', ')}`)));
    } catch (err) {
      box.innerHTML = `<li class="empty small">${esc(err.message)}</li>`;
    }
  });

  // --- Añadir varios mods de Modrinth de una vez ---
  const selBoxes = () => $$('#mrList [data-sel]:not(:disabled)');
  function updateSel() {
    const n = selBoxes().filter((c) => c.checked).length;
    $('#mrAddSel').textContent = `Añadir seleccionados (${n})`;
    $('#mrAddSel').disabled = n === 0;
  }
  $('#mrList').addEventListener('change', (e) => { if (e.target.dataset.sel !== undefined) updateSel(); });
  $('#mrList').addEventListener('click', (e) => {
    // Clic en la fila (no en botones) = marcar/desmarcar
    const li = e.target.closest('li');
    if (!li || e.target.closest('button, input')) return;
    const cb = $('[data-sel]', li);
    if (cb && !cb.disabled) { cb.checked = !cb.checked; updateSel(); }
  });
  $('#mrAll').addEventListener('change', (e) => { selBoxes().forEach((c) => (c.checked = e.target.checked)); updateSel(); });
  $('#mrAddSel').addEventListener('click', (e) => act(e.currentTarget, async () => {
    const ids = selBoxes().filter((c) => c.checked).map((c) => c.dataset.sel);
    const r = await staff.modAddModrinthMany(modInstance, ids);
    afterAdd(r);
    for (const id of ids) {
      const btn = $(`#mrList [data-mr="${id}"]`); if (btn) { btn.textContent = 'Añadido'; btn.disabled = true; }
      const cb = $(`#mrList [data-sel="${id}"]`); if (cb) { cb.checked = false; cb.disabled = true; }
    }
    $('#mrAll').checked = false;
    updateSel();
    return r;
  }, (r) => `Añadidos ${r.added.length} mods${r.failed.length ? ` (${r.failed.length} sin versión compatible)` : ''}`));

  const prev = CA.hooks.refreshed;
  CA.hooks.refreshed = () => { prev?.(); if (S.current === 'mods') renderMods(); if (S.current === 'instances' && !draft) renderAll(); };
})();
