'use strict';
// Skins y capas: biblioteca local, cuenta premium (API de Mojang) y
// sistema Caldito (repositorio de skins + CustomSkinLoader en el juego).
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { app } = require('electron');
const { Auth } = require('msmc');
const prefs = require('./prefs');
const store = require('./datastore');
const { UA, fetchBuffer } = require('./download');

const dir = (n) => path.join(app.getPath('userData'), n);
const libFile = () => dir('skins/library.json');
const BUILTIN_CAPES = [
  { id: 'caldito', name: 'Caldito' },
  { id: 'fogon', name: 'Fogón' },
  { id: 'noche', name: 'Noche' },
  { id: 'menta', name: 'Menta' },
];
const builtinCapePath = (id) => path.join(__dirname, '..', 'renderer', 'assets', 'capes', `${id}.png`);

/** Nombre válido para Minecraft (3–16 caracteres: letras, números o _). "Caldito Studio" → "Caldito_Studio". */
function mcName(n) {
  let s = String(n || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^A-Za-z0-9_]/g, '_').slice(0, 16);
  if (s.length < 3) s = (s + '___').slice(0, 3);
  return s;
}

/* ---------- utilidades PNG ---------- */
function pngSize(buf) {
  if (buf.length < 24 || buf.readUInt32BE(0) !== 0x89504e47) throw new Error('El archivo no es un PNG.');
  return { w: buf.readUInt32BE(16), h: buf.readUInt32BE(20) };
}
function checkSkin(buf) {
  const { w, h } = pngSize(buf);
  if (!(w === 64 && (h === 64 || h === 32))) throw new Error(`Una skin debe medir 64×64 (o 64×32). Esta mide ${w}×${h}.`);
  if (buf.length > 300 * 1024) throw new Error('La skin pesa demasiado.');
}
function checkCape(buf) {
  const { w, h } = pngSize(buf);
  if (!(w === h * 2 && [32, 64, 128].includes(h)) && !(w === 64 && h === 32)) throw new Error(`Una capa debe medir 64×32 (o 128×64 / 256×128). Esta mide ${w}×${h}.`);
  if (buf.length > 500 * 1024) throw new Error('La capa pesa demasiado.');
}
const dataUrl = (buf) => `data:image/png;base64,${buf.toString('base64')}`;
const readLib = () => { try { return JSON.parse(fs.readFileSync(libFile(), 'utf8')); } catch { return { skins: [], capes: [] }; } };
const writeLib = (l) => { fs.mkdirSync(path.dirname(libFile()), { recursive: true }); fs.writeFileSync(libFile(), JSON.stringify(l, null, 2)); };

/* ---------- lista para la interfaz ---------- */
function list() {
  const lib = readLib();
  const skins = lib.skins.map((s) => {
    try { return { ...s, img: dataUrl(fs.readFileSync(dir(`skins/${s.id}.png`))) }; } catch { return null; }
  }).filter(Boolean);
  const capes = [
    ...BUILTIN_CAPES.map((c) => ({ ...c, key: `builtin:${c.id}`, kind: 'Caldito', img: dataUrl(fs.readFileSync(builtinCapePath(c.id))) })),
    ...(store.getData().capes || []).map((c) => ({ id: c.id, name: c.name, key: `official:${c.id}`, kind: 'Oficial', img: c.img })),
    ...lib.capes.map((c) => {
      try { return { ...c, key: `custom:${c.id}`, kind: 'Propia', img: dataUrl(fs.readFileSync(dir(`skins/capes/${c.id}.png`))) }; } catch { return null; }
    }).filter(Boolean),
  ];
  const p = prefs.raw();
  return { skins, capes, active: { skin: p.activeSkin || null, cape: p.activeCape || 'none' }, microsoft: prefs.getMicrosoft()?.name || null };
}

/* ---------- añadir / quitar ---------- */
function addSkin(buf, name, model = 'auto') {
  checkSkin(buf);
  const lib = readLib();
  const id = crypto.randomBytes(5).toString('hex');
  fs.mkdirSync(dir('skins'), { recursive: true });
  fs.writeFileSync(dir(`skins/${id}.png`), buf);
  lib.skins.unshift({ id, name: String(name || 'Skin').slice(0, 32), model: model === 'slim' ? 'slim' : model === 'classic' ? 'classic' : detectModel(buf), addedAt: new Date().toISOString() });
  writeLib(lib);
  return id;
}
function addCape(buf, name) {
  checkCape(buf);
  const lib = readLib();
  const id = crypto.randomBytes(5).toString('hex');
  fs.mkdirSync(dir('skins/capes'), { recursive: true });
  fs.writeFileSync(dir(`skins/capes/${id}.png`), buf);
  lib.capes.unshift({ id, name: String(name || 'Capa').slice(0, 32), addedAt: new Date().toISOString() });
  writeLib(lib);
  return id;
}
function updateSkin(id, patch) {
  const lib = readLib();
  const s = lib.skins.find((x) => x.id === id);
  if (!s) throw new Error('Esa skin ya no existe.');
  if (patch.name) s.name = String(patch.name).slice(0, 32);
  if (patch.model && ['slim', 'classic'].includes(patch.model)) s.model = patch.model;
  writeLib(lib);
}
function removeItem(kind, id) {
  const lib = readLib();
  if (kind === 'skin') { lib.skins = lib.skins.filter((x) => x.id !== id); fs.rmSync(dir(`skins/${id}.png`), { force: true }); if (prefs.raw().activeSkin === id) prefs.set({ activeSkin: null }); }
  else { lib.capes = lib.capes.filter((x) => x.id !== id); fs.rmSync(dir(`skins/capes/${id}.png`), { force: true }); if (prefs.raw().activeCape === `custom:${id}`) prefs.set({ activeCape: 'none' }); }
  writeLib(lib);
}

/** Detecta brazos finos: en las skins "slim" el píxel (54,20) del brazo es transparente. */
function detectModel(buf) {
  try {
    const { w, h } = pngSize(buf);
    if (h !== 64 || w !== 64) return 'classic';
    const zlib = require('zlib');
    let off = 8, idat = [], bitDepth, colorType;
    while (off < buf.length) {
      const len = buf.readUInt32BE(off), type = buf.toString('ascii', off + 4, off + 8);
      if (type === 'IHDR') { bitDepth = buf[off + 16]; colorType = buf[off + 17]; }
      if (type === 'IDAT') idat.push(buf.slice(off + 8, off + 8 + len));
      if (type === 'IEND') break;
      off += 12 + len;
    }
    if (colorType !== 6 || bitDepth !== 8) return 'classic';
    const raw = zlib.inflateSync(Buffer.concat(idat));
    const stride = w * 4;
    // Reconstruye las filas (filtros PNG) hasta la 20.
    const rows = [];
    let prev = Buffer.alloc(stride);
    for (let y = 0; y <= 20; y++) {
      const f = raw[y * (stride + 1)];
      const line = Buffer.from(raw.slice(y * (stride + 1) + 1, (y + 1) * (stride + 1)));
      for (let i = 0; i < stride; i++) {
        const a = i >= 4 ? line[i - 4] : 0, b = prev[i], c = i >= 4 ? prev[i - 4] : 0;
        let v = line[i];
        if (f === 1) v += a; else if (f === 2) v += b; else if (f === 3) v += (a + b) >> 1;
        else if (f === 4) { const p = a + b - c, pa = Math.abs(p - a), pb = Math.abs(p - b), pc = Math.abs(p - c); v += pa <= pb && pa <= pc ? a : pb <= pc ? b : c; }
        line[i] = v & 255;
      }
      rows.push(line); prev = line;
    }
    return rows[20][54 * 4 + 3] === 0 ? 'slim' : 'classic';
  } catch { return 'classic'; }
}

/* ---------- copiar la skin de un jugador premium ---------- */
async function importFromName(name) {
  name = String(name || '').trim();
  if (!/^[A-Za-z0-9_]{3,16}$/.test(name)) throw new Error('Escribe un nombre de Minecraft válido.');
  const r1 = await fetch(`https://api.mojang.com/users/profiles/minecraft/${name}`, { headers: { 'User-Agent': UA } });
  if (r1.status === 404 || r1.status === 204) throw new Error(`No existe ninguna cuenta premium llamada ${name}.`);
  if (!r1.ok) throw new Error(`Mojang respondió ${r1.status}.`);
  const { id } = await r1.json();
  const r2 = await fetch(`https://sessionserver.mojang.com/session/minecraft/profile/${id}`, { headers: { 'User-Agent': UA } });
  const prof = await r2.json();
  const tex = JSON.parse(Buffer.from(prof.properties.find((p) => p.name === 'textures').value, 'base64').toString());
  const skin = tex.textures?.SKIN;
  if (!skin) throw new Error(`${name} usa la skin por defecto.`);
  const buf = await fetchBuffer(skin.url.replace('http://', 'https://'));
  return addSkin(buf, name, skin.metadata?.model === 'slim' ? 'slim' : 'classic');
}

/* ---------- textura de la capa elegida ---------- */
async function capeBuffer(key) {
  if (!key || key === 'none') return null;
  const [kind, id] = key.split(':');
  if (kind === 'builtin') return fs.readFileSync(builtinCapePath(id));
  if (kind === 'custom') return fs.readFileSync(dir(`skins/capes/${id}.png`));
  if (kind === 'official') {
    const c = (store.getData().capes || []).find((x) => x.id === id);
    if (!c) return null;
    return Buffer.from(c.img.split(',')[1], 'base64');
  }
  return null;
}
function skinBuffer(id) {
  try { return fs.readFileSync(dir(`skins/${id}.png`)); } catch { return null; }
}

/* ---------- cuenta premium ---------- */
async function msToken() {
  const ms = prefs.getMicrosoft();
  if (!ms) throw new Error('Vincula tu cuenta de Microsoft desde el menú de tu cuenta.');
  const xbox = await new Auth('select_account').refresh(ms.refresh);
  const mc = await xbox.getMinecraft();
  prefs.setMicrosoft({ name: mc.profile.name, uuid: mc.profile.id, refresh: xbox.save() });
  return mc.mcToken;
}
async function mojangProfile() {
  const token = await msToken();
  const r = await fetch('https://api.minecraftservices.com/minecraft/profile', { headers: { Authorization: `Bearer ${token}`, 'User-Agent': UA } });
  if (!r.ok) throw new Error(`Mojang respondió ${r.status} al leer tu perfil.`);
  const p = await r.json();
  return { name: p.name, capes: (p.capes || []).map((c) => ({ id: c.id, alias: c.alias, url: c.url, active: c.state === 'ACTIVE' })), token };
}
async function mojangUploadSkin(buf, model) {
  const token = await msToken();
  const fd = new FormData();
  fd.append('variant', model === 'slim' ? 'slim' : 'classic');
  fd.append('file', new Blob([buf], { type: 'image/png' }), 'skin.png');
  const r = await fetch('https://api.minecraftservices.com/minecraft/profile/skins', { method: 'POST', headers: { Authorization: `Bearer ${token}`, 'User-Agent': UA }, body: fd });
  if (!r.ok) throw new Error(`Mojang rechazó la skin (${r.status}).`);
}
async function mojangSetCape(capeId) {
  const token = await msToken();
  const url = 'https://api.minecraftservices.com/minecraft/profile/capes/active';
  const r = capeId
    ? await fetch(url, { method: 'PUT', headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json', 'User-Agent': UA }, body: JSON.stringify({ capeId }) })
    : await fetch(url, { method: 'DELETE', headers: { Authorization: `Bearer ${token}`, 'User-Agent': UA } });
  if (!r.ok) throw new Error(`Mojang respondió ${r.status} al cambiar la capa.`);
}

/* ---------- aplicar ---------- */
async function apply({ skinId, capeKey, premium }) {
  if (!store.getSession()?.name) throw new Error('Inicia sesión primero.');
  const name = mcName(store.getSession().name);
  const lib = readLib();
  const skin = skinId ? lib.skins.find((x) => x.id === skinId) : null;
  if (skinId && !skin) throw new Error('Esa skin ya no existe.');
  prefs.set({ activeSkin: skinId || null, activeCape: capeKey || 'none' });
  const done = ['En tu PC (se verá en el juego al entrar)'];

  const gh = store.skinsProvider();
  if (gh?.token) {
    const sb = skin ? skinBuffer(skin.id) : null;
    if (sb) await gh.putRaw(`skins/${name}.png`, sb, `Skin de ${name}`);
    else await gh.deleteRaw(`skins/${name}.png`, `Skin de ${name} eliminada`).catch(() => {});
    const cb = await capeBuffer(capeKey);
    if (cb) await gh.putRaw(`capes/${name}.png`, cb, `Capa de ${name}`);
    else await gh.deleteRaw(`capes/${name}.png`, `Capa de ${name} eliminada`).catch(() => {});
    done.push('Para el resto de jugadores de Caldito');
  }
  if (premium && skin) {
    await mojangUploadSkin(skinBuffer(skin.id), skin.model);
    done.push('En tu cuenta premium de Minecraft');
  }
  return { done, skinUrl: gh ? gh.rawUrl(`skins/${name}.png`) : null };
}

/* ---------- preparar el juego (CustomSkinLoader) ---------- */
function rawBase() {
  const d = store.getData();
  if (!d.skins?.repo) return null;
  return `https://raw.githubusercontent.com/${d.skins.repo}/${d.skins.branch || 'main'}`;
}
async function prepareInstance(gameDir, name) {
  const p = prefs.raw();
  const csl = path.join(gameDir, 'CustomSkinLoader');
  const local = path.join(csl, 'LocalSkin');
  for (const sub of ['skins', 'capes', 'elytras']) fs.mkdirSync(path.join(local, sub), { recursive: true });

  const sb = p.activeSkin ? skinBuffer(p.activeSkin) : null;
  const cb = await capeBuffer(p.activeCape).catch(() => null);
  const put = (sub, buf) => {
    const f = path.join(local, sub, `${name}.png`);
    if (buf) fs.writeFileSync(f, buf); else fs.rmSync(f, { force: true });
  };
  put('skins', sb); put('capes', cb); put('elytras', cb);

  const base = rawBase();
  const loadlist = [
    { name: 'LocalSkin', type: 'Legacy', checkPNG: false, skin: 'LocalSkin/skins/{USERNAME}.png', model: 'auto', cape: 'LocalSkin/capes/{USERNAME}.png', elytra: 'LocalSkin/elytras/{USERNAME}.png' },
    ...(base ? [{ name: 'Caldito', type: 'Legacy', checkPNG: true, skin: `${base}/skins/{USERNAME}.png`, model: 'auto', cape: `${base}/capes/{USERNAME}.png`, elytra: `${base}/capes/{USERNAME}.png` }] : []),
    { name: 'Mojang', type: 'MojangAPI' },
  ];
  const cfgFile = path.join(csl, 'CustomSkinLoader.json');
  let cfg = {};
  try { cfg = JSON.parse(fs.readFileSync(cfgFile, 'utf8')); } catch {}
  cfg.enable = true;
  cfg.loadlist = loadlist;
  fs.writeFileSync(cfgFile, JSON.stringify(cfg, null, 2));
}

module.exports = {
  mcName, list, addSkin, addCape, updateSkin, removeItem, importFromName, checkSkin, checkCape,
  apply, prepareInstance, mojangProfile, mojangSetCape, rawBase, BUILTIN_CAPES,
};
