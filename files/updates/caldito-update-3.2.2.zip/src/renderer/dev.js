'use strict';
/* =====================================================================
   Caldito Launcher · paneles de desarrollador
   (el proceso principal vuelve a comprobar el rol en cada acción)
   ===================================================================== */
(() => {
  const { S, $, $$, esc, clone, act, toast, openModal, confirmBox, showCode, fmtDate, gb } = CA;
  const api = window.caldito;
  const dev = api.dev;

  const DRAFT_KEYS = ['theme', 'texts', 'sections', 'splash', 'buttons', 'news', 'capes'];

  /* ---------------- borrador de personalización ---------------- */
  function ensureDraft() { if (!S.draft) S.draft = clone(S.view); return S.draft; }
  function getPath(obj, path) { return path.split('.').reduce((o, k) => (o == null ? o : o[k]), obj); }
  function setPath(obj, path, val) {
    const ks = path.split('.');
    const last = ks.pop();
    const target = ks.reduce((o, k) => (o[k] ??= {}), obj);
    target[last] = val;
  }
  let applyTimer;
  function changed(immediate = false) {
    $('#publishBar').hidden = false;
    clearTimeout(applyTimer);
    if (immediate) CA.applyAll(); else applyTimer = setTimeout(CA.applyAll, 60);
  }
  function setDraft(path, val, immediate) { setPath(ensureDraft(), path, val); changed(immediate); }

  $('#pubDiscard').addEventListener('click', async () => {
    if (!(await confirmBox('Descartar cambios', 'Se perderán los cambios que no has publicado.', 'Descartar', true))) return;
    S.draft = null;
    $('#publishBar').hidden = true;
    CA.applyAll();
    renderSub();
  });
  $('#pubSave').addEventListener('click', (e) => act(e.currentTarget, async () => {
    const patch = Object.fromEntries(DRAFT_KEYS.map((k) => [k, S.draft[k]]));
    S.view = await dev.publish(patch);
    S.draft = null;
    $('#publishBar').hidden = true;
    CA.applyAll();
    renderSub();
  }, 'Publicado: todos los jugadores verán los cambios'));

  /* ---------------- constructores de campos ---------------- */
  const val = (path) => getPath(CA.cur(), path);
  const F = {
    text: (path, label, ph = '') => `<label class="field">${label}<input data-path="${path}" value="${esc(val(path) ?? '')}" placeholder="${esc(ph)}" /></label>`,
    area: (path, label, ph = '') => `<label class="field">${label}<textarea data-path="${path}" placeholder="${esc(ph)}">${esc(val(path) ?? '')}</textarea></label>`,
    color: (path, label) => {
      const v = val(path) || '#000000';
      return `<div class="color-item"><input type="color" data-color="${path}" value="${esc(v)}" /><span>${label}</span><input type="text" data-colortext="${path}" value="${esc(v)}" maxlength="7" /></div>`;
    },
    range: (path, label, min, max, step, fmt = (v) => v) => {
      fmtFns[path] = fmt;
      return `<label class="field">${label} <b data-out="${path}">${fmt(val(path))}</b>
      <input type="range" data-path="${path}" data-num="1" min="${min}" max="${max}" step="${step}" value="${val(path)}" /></label>`;
    },
    toggle: (path, label, desc = '') => `<div class="toggle-row"><div><b>${label}</b>${desc ? `<small>${desc}</small>` : ''}</div><button class="switch ${val(path) !== false ? 'on' : ''}" data-toggle="${path}" aria-label="${esc(label)}"></button></div>`,
    select: (path, label, opts) => `<label class="field">${label}<select data-path="${path}">${opts.map(([v, l]) => `<option value="${esc(v)}" ${String(val(path)) === String(v) ? 'selected' : ''}>${esc(l)}</option>`).join('')}</select></label>`,
  };
  const fmtFns = {};

  /* ---------------- secciones de Personalizar ---------------- */
  let sub = 'brand';
  const COLOR_LABELS = {
    bg: 'Fondo', bg2: 'Fondo secundario', surface: 'Tarjetas', surface2: 'Botones secundarios', line: 'Bordes',
    text: 'Texto', muted: 'Texto suave', accent: 'Acento (claro)', accent2: 'Acento (oscuro)', accentText: 'Texto sobre acento',
    glow: 'Resplandor', success: 'Éxito / en línea', danger: 'Error / apagado', logo: 'Color del logo',
  };
  const TEXT_GROUPS = [
    ['Botón JUGAR', [['play', 'Texto del botón'], ['preparing', 'Mientras prepara'], ['playing', 'Con el juego abierto']]],
    ['Barra de juego', [['readyTitle', 'Título en espera'], ['readySubtitle', 'Subtítulo en espera ({ip} = dirección, {instance} = instancia)'], ['runningTitle', 'Título jugando'], ['runningSubtitle', 'Subtítulo jugando ({player} = nombre)']]],
    ['Estado del servidor', [['online', 'Encendido'], ['offline', 'Apagado'], ['offlineMotd', 'Mensaje cuando está apagado']]],
    ['Noticias', [['newsTitle', 'Título en Inicio'], ['newsPageTitle', 'Título de la página']]],
    ['Inicio de sesión', [['loginTitle', 'Título'], ['loginSubtitle', 'Subtítulo'], ['playerTab', 'Pestaña jugador'], ['devTab', 'Pestaña desarrollador'], ['playerHint', 'Ayuda para jugadores'], ['devHint', 'Ayuda para desarrolladores'], ['footer', 'Pie de página']]],
    ['Menú', [['navHome', 'Pestaña Inicio'], ['navNews', 'Pestaña Noticias'], ['navSkins', 'Pestaña Skins'], ['navRepair', 'Pestaña Reparar'], ['instancesTitle', 'Nombre de "Instancias"']]],
  ];

  const SUBS = {
    brand: () => `
      <h2>Marca</h2><p class="hint">Nombre, logo e identidad. Todo se ve al instante; publícalo cuando te guste.</p>
      <div class="card">
        <div class="grid-2">
          ${F.text('texts.studioName', 'Nombre del estudio (logo y barra superior)')}
          ${F.text('texts.appTitle', 'Título de la ventana')}
          ${F.text('texts.heroTitle', 'Título grande de Inicio')}
          ${F.text('texts.heroEyebrow', 'Etiqueta sobre el título (vacío = oculta)')}
        </div>
        ${F.text('texts.tagline', 'Frase / eslogan')}
      </div>
      <div class="card">
        <h3>Logo</h3>
        <div class="row">
          <div class="logo-preview"><div class="logo-slot" data-logo></div></div>
          <div style="display:grid;gap:8px;flex:1">
            <p class="hint">PNG, SVG o JPG de hasta 1,5 MB. Con fondo transparente queda mejor.</p>
            <div class="row"><button class="ghost" id="logoUp">Subir logo</button><button class="ghost" id="logoReset">Usar logo de Caldito Studio</button></div>
            ${F.color('theme.colors.logo', 'Color del logo de Caldito')}
          </div>
        </div>
      </div>
      <div class="card">
        <h3>Imagen de fondo</h3>
        <div class="img-field"><div class="thumb" style="background-image:url('${esc(val('theme.background') || '')}')"></div>
          <input data-path="theme.background" placeholder="https://… o súbela" value="${esc(val('theme.background')?.startsWith('data:') ? '(imagen subida)' : val('theme.background') || '')}" />
          <button class="ghost" id="bgUp">Subir</button><button class="ghost" id="bgClear">Quitar</button></div>
        ${F.range('theme.backgroundOpacity', 'Opacidad de la imagen', 0.05, 1, 0.05, (v) => Math.round(v * 100) + '%')}
      </div>
      <div class="card">
        ${F.range('theme.radius', 'Redondez de esquinas', 0, 28, 1, (v) => v + ' px')}
        ${F.toggle('theme.animations', 'Animaciones', 'Vapor, brillos y transiciones.')}
      </div>`,

    colors: () => `
      <h2>Colores</h2><p class="hint">Elige una paleta base y ajusta cada color.</p>
      <div class="card"><h3>Paletas</h3><div class="presets">
        ${Object.entries(S.presets).map(([k, p]) => `<button class="preset ${val('theme.preset') === k ? 'on' : ''}" data-preset="${k}">
          <span class="swatches">${['bg', 'surface', 'accent2', 'accent', 'text'].map((c) => `<i style="background:${p.colors[c]}"></i>`).join('')}</span>${esc(p.name)}</button>`).join('')}
      </div></div>
      <div class="card"><h3>Colores uno a uno</h3><div class="color-grid">
        ${Object.entries(COLOR_LABELS).map(([k, l]) => F.color(`theme.colors.${k}`, l)).join('')}
      </div></div>`,

    type: () => {
      const opts = S.fonts.map((f) => [f, f === 'Sistema' ? 'Fuente del sistema' : f]);
      return `
      <h2>Tipografía</h2><p class="hint">Todas las fuentes van incluidas en el launcher: funcionan sin internet.</p>
      <div class="card">
        <div class="grid-2">${F.select('theme.fonts.display', 'Títulos y botones', opts)}${F.select('theme.fonts.body', 'Texto general', opts)}</div>
        ${F.range('theme.fontScale', 'Tamaño del texto', 0.85, 1.25, 0.05, (v) => Math.round(v * 100) + '%')}
        <div class="font-preview"><div class="d">${esc(val('texts.heroTitle'))}</div><p>${esc(val('texts.tagline'))} — Áá Éé Ññ 0123456789</p></div>
      </div>`;
    },

    texts: () => `
      <h2>Textos</h2><p class="hint">Cambia cualquier texto que ven los jugadores.</p>
      ${TEXT_GROUPS.map(([g, fields]) => `<div class="card"><h3>${g}</h3><div class="grid-2">${fields.map(([k, l]) => F.text('texts.' + k, l)).join('')}</div></div>`).join('')}`,

    sections: () => `
      <h2>Secciones</h2><p class="hint">Muestra u oculta partes de la pantalla de Inicio.</p>
      <div class="edit-list">
        ${F.toggle('sections.serverStatus', 'Estado del servidor', 'Encendido/apagado, jugadores, ping y versión.')}
        ${F.toggle('sections.motd', 'Mensaje del servidor (MOTD)')}
        ${F.toggle('sections.playerList', 'Nombres de jugadores conectados')}
        ${F.toggle('sections.heroLogo', 'Logo grande en Inicio')}
        ${F.toggle('sections.steam', 'Vapor animado sobre el logo')}
        ${F.toggle('sections.newsOnHome', 'Noticias en Inicio')}
        <div class="card">${F.range('sections.newsOnHomeCount', 'Cuántas noticias en Inicio', 1, 6, 1)}</div>
        ${F.toggle('sections.quickButtons', 'Botones rápidos', 'Los que configuras en la sección Botones.')}
      </div>`,

    buttons: () => {
      const list = val('buttons') || [];
      const folderOpts = [['root', 'Carpeta del juego'], ['mods', 'Mods'], ['screenshots', 'Capturas'], ['resourcepacks', 'Paquetes de recursos'], ['shaderpacks', 'Shaders'], ['logs', 'Registros']];
      return `
      <h2>Botones</h2><p class="hint">Botones rápidos de la pantalla de Inicio: enlaces (Discord, web, tienda…) o carpetas del juego.</p>
      <div class="edit-list">
        ${list.map((b, i) => `
        <div class="edit-item"><div class="btn-row">
          <input class="emoji" data-path="buttons.${i}.icon" value="${esc(b.icon || '')}" maxlength="4" title="Emoji" />
          <input data-path="buttons.${i}.label" value="${esc(b.label)}" placeholder="Texto" />
          <select data-path="buttons.${i}.type" data-rerender="1"><option value="link" ${b.type === 'link' ? 'selected' : ''}>Enlace</option><option value="folder" ${b.type === 'folder' ? 'selected' : ''}>Carpeta</option></select>
          ${b.type === 'folder'
            ? `<select data-path="buttons.${i}.value">${folderOpts.map(([v, l]) => `<option value="${v}" ${b.value === v ? 'selected' : ''}>${l}</option>`).join('')}</select>`
            : `<input data-path="buttons.${i}.value" value="${esc(b.value || '')}" placeholder="https://…" />`}
          <div class="row" style="flex-wrap:nowrap">
            <button class="switch ${b.visible !== false ? 'on' : ''}" data-toggle="buttons.${i}.visible" title="Visible"></button>
            <button class="icon-btn" data-move="buttons:${i}:-1" title="Subir">↑</button>
            <button class="icon-btn" data-move="buttons:${i}:1" title="Bajar">↓</button>
            <button class="icon-btn" data-test-btn="${i}" title="Probar">▶</button>
            <button class="icon-btn danger" data-del="buttons:${i}" title="Eliminar">🗑</button>
          </div>
        </div></div>`).join('') || '<div class="empty small">No hay botones.</div>'}
      </div>
      <div class="row" style="margin-top:12px"><button class="ghost" id="btnAdd">+ Añadir botón</button></div>`;
    },

    newsEd: () => {
      const list = val('news') || [];
      return `
      <h2>Noticias</h2><p class="hint">Se ordenan por fecha (la más reciente primero).</p>
      <div class="row" style="margin-bottom:12px"><button class="primary" id="newsAdd">+ Nueva noticia</button></div>
      <div class="edit-list">
        ${list.map((n, i) => `
        <div class="edit-item">
          <div class="grid-2">
            <label class="field">Título<input data-path="news.${i}.title" value="${esc(n.title)}" /></label>
            <div class="grid-2"><label class="field">Etiqueta<input data-path="news.${i}.tag" value="${esc(n.tag || '')}" /></label><label class="field">Fecha<input type="date" data-path="news.${i}.date" value="${esc(n.date || '')}" /></label></div>
          </div>
          <label class="field">Texto<textarea data-path="news.${i}.body">${esc(n.body || '')}</textarea></label>
          <div class="grid-2">
            <label class="field">Imagen (opcional)
              <div class="img-field"><div class="thumb" style="background-image:url('${esc(n.image || '')}')"></div>
                <input data-path="news.${i}.image" value="${esc(n.image?.startsWith('data:') ? '(imagen subida)' : n.image || '')}" placeholder="https://…" />
                <button class="ghost small" data-news-img="${i}">Subir</button></div></label>
            <label class="field">Enlace "Leer más" (opcional)<input data-path="news.${i}.url" value="${esc(n.url || '')}" placeholder="https://…" /></label>
          </div>
          <div class="row end"><button class="ghost danger small" data-del="news:${i}">Eliminar noticia</button></div>
        </div>`).join('') || '<div class="empty small">No hay noticias.</div>'}
      </div>`;
    },

    capesEd: () => {
      const list = val('capes') || [];
      return `
      <h2>Capas oficiales</h2><p class="hint">Capas que el equipo ofrece a todos los jugadores, además de las 4 de Caldito incluidas. PNG de 64×32.</p>
      <div class="row" style="margin-bottom:12px"><button class="primary" id="capeAdd">+ Subir capa oficial</button></div>
      <div class="edit-list">
        ${list.map((c, i) => `<div class="edit-item"><div class="row">
          <img src="${esc(c.img)}" alt="" style="width:96px;height:48px;image-rendering:pixelated;border-radius:6px;background:var(--bg)" />
          <input data-path="capes.${i}.name" value="${esc(c.name)}" placeholder="Nombre" />
          <button class="icon-btn danger" data-del="capes:${i}" title="Eliminar">🗑</button></div></div>`).join('') || '<div class="empty small">Aún no hay capas oficiales.</div>'}
      </div>`;
    },

    splashEd: () => `
      <h2>Pantalla de carga</h2><p class="hint">Lo primero que se ve al abrir el launcher.</p>
      <div class="card">
        ${F.text('texts.splashText', 'Texto bajo el logo')}
        ${F.range('splash.durationMs', 'Duración mínima', 500, 8000, 100, (v) => (v / 1000).toFixed(1) + ' s')}
        ${F.toggle('splash.showBar', 'Barra de progreso')}
        <div class="row"><button class="primary" id="splashPreview">▶ Ver pantalla de carga</button></div>
      </div>`,
  };

  function renderSub() {
    if (S.current !== 'custom') return;
    $$('#customNav [data-sub]').forEach((b) => b.classList.toggle('on', b.dataset.sub === sub));
    const body = $('#customBody');
    const scroll = body.scrollTop;
    body.innerHTML = SUBS[sub]();
    body.scrollTop = scroll;
    CA.renderLogos(val('theme.logo'));
    bindSub();
  }
  CA.openSub = (name) => { sub = name; renderSub(); };
  $$('#customNav [data-sub]').forEach((b) => b.addEventListener('click', () => { sub = b.dataset.sub; $('#customBody').scrollTop = 0; renderSub(); }));

  // Delegación de eventos para todos los campos del panel
  const body = $('#customBody');
  body.addEventListener('input', (e) => {
    const el = e.target;
    if (el.dataset.path) {
      if (el.value === '(imagen subida)') return;
      let v = el.dataset.num ? Number(el.value) : el.value;
      setDraft(el.dataset.path, v);
      const out = $(`[data-out="${el.dataset.path}"]`, body);
      if (out) out.textContent = (fmtFns[el.dataset.path] || ((x) => x))(v);
      if (el.dataset.path.startsWith('theme.fonts') || el.dataset.path.startsWith('texts.hero') || el.dataset.path === 'texts.tagline') {
        const fp = $('.font-preview', body);
        if (fp && sub === 'type') { $('.d', fp).textContent = val('texts.heroTitle'); }
      }
    } else if (el.dataset.color) {
      setDraft(el.dataset.color, el.value);
      setDraft('theme.preset', 'custom');
      $(`[data-colortext="${el.dataset.color}"]`, body).value = el.value;
    } else if (el.dataset.colortext && /^#[0-9a-f]{6}$/i.test(el.value)) {
      setDraft(el.dataset.colortext, el.value);
      setDraft('theme.preset', 'custom');
      $(`[data-color="${el.dataset.colortext}"]`, body).value = el.value;
    }
  });
  body.addEventListener('change', (e) => { if (e.target.dataset.rerender) renderSub(); });
  body.addEventListener('click', async (e) => {
    const t = e.target.closest('button');
    if (!t) return;
    if (t.dataset.toggle) {
      const on = !t.classList.contains('on');
      t.classList.toggle('on', on);
      setDraft(t.dataset.toggle, on);
    } else if (t.dataset.preset) {
      const p = S.presets[t.dataset.preset];
      ensureDraft().theme.colors = { ...p.colors };
      setDraft('theme.preset', t.dataset.preset, true);
      renderSub();
    } else if (t.dataset.move) {
      const [key, i, d] = t.dataset.move.split(':');
      const arr = ensureDraft()[key];
      const j = +i + +d;
      if (j < 0 || j >= arr.length) return;
      [arr[i], arr[j]] = [arr[j], arr[i]];
      changed(true); renderSub();
    } else if (t.dataset.del) {
      const [key, i] = t.dataset.del.split(':');
      const what = { news: 'esta noticia', buttons: 'este botón', capes: 'esta capa' }[key];
      if (!(await confirmBox('Eliminar', `¿Seguro que quieres eliminar ${what}?`, 'Eliminar', true))) return;
      ensureDraft()[key].splice(+i, 1);
      changed(true); renderSub();
    } else if (t.dataset.testBtn) {
      const b = val('buttons')[+t.dataset.testBtn];
      if (b.type === 'folder') act(null, () => api.openFolder(b.value || 'root'));
      else act(null, () => api.openLink(b.value));
    } else if (t.dataset.newsImg) {
      const img = await act(t, () => dev.pickImage(1200));
      if (img) { setDraft(`news.${t.dataset.newsImg}.image`, img, true); renderSub(); }
    }
  });

  function bindSub() {
    const on = (id, fn) => { const el = $('#' + id); if (el) el.addEventListener('click', fn); };
    on('logoUp', async (e) => { const img = await act(e.currentTarget, () => dev.pickImage(1500)); if (img) { setDraft('theme.logo', img, true); renderSub(); } });
    on('logoReset', () => { setDraft('theme.logo', '', true); renderSub(); });
    on('bgUp', async (e) => { const img = await act(e.currentTarget, () => dev.pickImage(2500)); if (img) { setDraft('theme.background', img, true); renderSub(); } });
    on('bgClear', () => { setDraft('theme.background', '', true); renderSub(); });
    on('btnAdd', () => { ensureDraft().buttons.push({ id: 'b-' + Date.now(), label: 'Nuevo botón', icon: '⭐', type: 'link', value: 'https://', visible: true }); changed(true); renderSub(); });
    on('newsAdd', () => {
      ensureDraft().news.unshift({ id: 'n-' + Date.now(), title: 'Nueva noticia', tag: 'Anuncio', date: new Date().toISOString().slice(0, 10), body: '', image: '', url: '' });
      changed(true); renderSub();
    });
    on('splashPreview', () => CA.previewSplash());
    on('capeAdd', async (e) => {
      const c = await act(e.currentTarget, () => dev.pickCape());
      if (c) { ensureDraft().capes = [...(ensureDraft().capes || []), { id: 'c-' + Date.now(), name: c.name, img: c.img }]; changed(true); renderSub(); }
    });
  }

  $('#themeExport').addEventListener('click', (e) => act(e.currentTarget, async () => {
    const c = CA.cur();
    const f = await dev.exportTheme({ caldito: 'tema', theme: c.theme, texts: c.texts, sections: c.sections, splash: c.splash, buttons: c.buttons });
    return f;
  }, (f) => (f ? 'Tema exportado' : null)));
  $('#themeImport').addEventListener('click', (e) => act(e.currentTarget, async () => {
    const j = await dev.importTheme();
    if (!j) return;
    const d = ensureDraft();
    for (const k of ['theme', 'texts', 'sections', 'splash', 'buttons']) if (j[k]) d[k] = k === 'buttons' ? j[k] : { ...d[k], ...j[k] };
    changed(true); renderSub();
    toast('Tema importado: revísalo y publícalo', 'ok');
  }));
  $('#themeReset').addEventListener('click', async () => {
    if (!(await confirmBox('Restablecer apariencia', 'Vuelve los colores, letras, textos, secciones, botones y pantalla de carga a los de Caldito Studio. Las noticias no se tocan. No se publica hasta que pulses "Publicar cambios".', 'Restablecer', true))) return;
    const d = ensureDraft();
    for (const k of ['theme', 'texts', 'sections', 'splash', 'buttons']) d[k] = clone(S.defaults[k]);
    changed(true); renderSub();
  });

  /* ---------------- CONEXIÓN ---------------- */
  function renderConnection() {
    const y = S.view.sync;
    const gh = y.provider === 'github';
    $('#syncPill').textContent = gh ? 'GitHub' : 'Local';
    $('#syncPill').className = 'pill ' + (gh ? 'ok' : 'warn');
    $('#syncInfo').innerHTML = gh
      ? `Conectado a <b>${esc(y.repo)}</b> (${esc(y.branch)}). Todos los launchers conectados comparten noticias, instancias, mods, personalización y códigos.${y.error ? ` <br>⚠️ ${esc(y.error)}` : ''}`
      : '<b>Modo local:</b> los cambios y códigos solo existen en este PC. Conecta un repositorio de GitHub para que funcionen en el PC de cada jugador.';
    $('#ghRepo').value = y.repo || '';
    $('#ghBranch').value = y.branch || 'main';
    $('#ghToken').placeholder = S.view.hasGithubToken ? 'Token guardado (cifrado). Pega uno nuevo solo para cambiarlo.' : 'github_pat_…';
    $('#ghLocal').hidden = !gh;
    $('#connCodeBox').hidden = !gh;
    $('#connCode').textContent = y.connectionCode || '';
    const sk = S.view.skins;
    $('#skPill').textContent = sk.repo ? 'Activo' : 'Desactivado';
    $('#skPill').className = 'pill ' + (sk.repo ? 'ok' : 'muted');
    $('#skRepo').value = sk.repo || '';
    $('#skBranch').value = sk.branch || 'main';
    $('#skToken').placeholder = S.view.hasSkinsToken ? 'Token guardado (cifrado). Pega uno nuevo solo para cambiarlo.' : 'github_pat_…';
    $('#skOff').hidden = !sk.repo;
    fillPc();
  }
  CA.hooks.connection = renderConnection;
  const playerMessage = (code, name = '') => {
    const t = CA.cur().texts;
    const conn = S.view.sync.connectionCode;
    const lines = [`¡Hola! Para entrar a ${t.studioName || 'Caldito Studio'}:`, '1) Instala el Caldito Launcher.'];
    if (conn) lines.push(`2) (Opcional) Pulsa "¿Primera vez? Conectar…" y escribe este código de conexión: ${conn}`);
    lines.push(`${conn ? 3 : 2}) En "${t.playerTab || 'Jugador'}" escribe tu nombre${name ? ': ' + name : ''} y tu código de acceso${code ? ': ' + code : ' (te lo envío por privado)'}.`);
    return lines.join('\n');
  };
  CA.playerMessage = playerMessage;
  $('#connCopy').addEventListener('click', () => { navigator.clipboard.writeText(S.view.sync.connectionCode); toast('Código de conexión copiado', 'ok'); });
  $('#connMsg').addEventListener('click', () => { navigator.clipboard.writeText(playerMessage('')); toast('Mensaje copiado', 'ok'); });
  $('#ghConnect').addEventListener('click', (e) => act(e.currentTarget, async () => {
    S.view = await dev.githubConnect({ repo: $('#ghRepo').value, branch: $('#ghBranch').value, token: $('#ghToken').value });
    $('#ghToken').value = '';
    CA.applyAll();
    renderConnection();
  }, 'Conectado con GitHub. Comparte el código de conexión con los jugadores.'));
  $('#ghLocal').addEventListener('click', async (e) => {
    if (!(await confirmBox('Usar modo local', 'Este PC dejará de leer y publicar en GitHub. Los datos de GitHub no se borran.', 'Cambiar a local'))) return;
    act(e.currentTarget, async () => { S.view = await dev.useLocal(); CA.applyAll(); renderConnection(); }, 'Modo local activado');
  });
  $('#skSave').addEventListener('click', (e) => act(e.currentTarget, async () => {
    S.view = await dev.skinsRepo({ repo: $('#skRepo').value, branch: $('#skBranch').value, token: $('#skToken').value });
    $('#skToken').value = '';
    renderConnection();
  }, 'Repositorio de skins guardado: los jugadores ya pueden compartir su skin'));
  $('#skOff').addEventListener('click', async (e) => {
    if (!(await confirmBox('Desactivar skins compartidas', 'Los jugadores dejarán de subir sus skins. Las que ya están en el repositorio no se borran.', 'Desactivar', true))) return;
    act(e.currentTarget, async () => { S.view = await dev.skinsRepo({ repo: '' }); renderConnection(); }, 'Skins compartidas desactivadas');
  });
  $('#ghHelp').addEventListener('click', () => openModal({
    title: 'Conectar con GitHub (gratis)',
    html: `<ol>
      <li>Crea una cuenta en <b>github.com</b>.</li>
      <li>Crea un repositorio <b>público</b>, por ejemplo <b>caldito-launcher-datos</b>, marcando "Add a README". Para las skins crea otro, por ejemplo <b>caldito-skins</b>.</li>
      <li>Ve a <b>Settings → Developer settings → Personal access tokens → Fine-grained tokens → Generate new token</b>.</li>
      <li>En <b>Repository access</b> elige "Only select repositories" y marca <b>solo</b> el repositorio correspondiente (un token para datos y otro para skins).</li>
      <li>En <b>Permissions → Contents</b> elige <b>Read and write</b>. Pon caducidad larga.</li>
      <li>Pega aquí el repositorio en formato <b>usuario/repositorio</b> y el token.</li>
    </ol><p class="hint" style="margin-top:10px">El token de datos solo lo puede abrir el equipo. El de skins lo reciben los jugadores (cifrado), por eso debe ser de un repositorio aparte.</p>`,
    actions: [{ label: 'Abrir GitHub', kind: 'primary', onClick: () => { api.openLink('https://github.com/settings/personal-access-tokens/new'); return true; } }, { label: 'Cerrar' }],
  }));

  // --- Este PC ---
  function fillPc() {
    const p = S.pc;
    const max = Math.max(2048, Math.floor((p.totalMemMB * 0.75) / 256) * 256);
    const r = $('#pcRam');
    const rec = CA.selInstance()?.ramMB || 4096;
    r.max = max;
    r.value = p.ramMB || Math.min(rec, max);
    $('#pcRamOut').textContent = gb(+r.value);
    $('#pcRamHint').textContent = `${p.ramMB ? 'Elegida en este PC' : 'Usando la recomendada por cada instancia'} · tu equipo tiene ${gb(p.totalMemMB)}.`;
    $('#pcWidth').value = p.width; $('#pcHeight').value = p.height; $('#pcFull').checked = p.fullscreen;
    $$('#pcAfter button').forEach((b) => b.classList.toggle('on', b.dataset.v === p.afterLaunch));
    $('#pcJava').value = p.javaPath; $('#pcJvm').value = p.jvmArgs; $('#pcDir').value = p.gameDir || p.defaultGameDir;
  }
  const savePc = async (patch, msg = 'Guardado en este PC') => { S.pc = await api.pc.set(patch); fillPc(); toast(msg, 'ok'); };
  $('#pcRam').addEventListener('input', (e) => ($('#pcRamOut').textContent = gb(+e.target.value)));
  $('#pcRam').addEventListener('change', (e) => savePc({ ramMB: +e.target.value }));
  $('#pcWidth').addEventListener('change', (e) => savePc({ width: +e.target.value || 1280 }));
  $('#pcHeight').addEventListener('change', (e) => savePc({ height: +e.target.value || 720 }));
  $('#pcFull').addEventListener('change', (e) => savePc({ fullscreen: e.target.checked }));
  $$('#pcAfter button').forEach((b) => b.addEventListener('click', () => savePc({ afterLaunch: b.dataset.v })));
  $('#pcJava').addEventListener('change', (e) => savePc({ javaPath: e.target.value.trim() }));
  $('#pcJvm').addEventListener('change', (e) => savePc({ jvmArgs: e.target.value.trim() }));
  $('#pcJavaPick').addEventListener('click', (e) => act(e.currentTarget, async () => { const p = await api.pc.pickJava(); if (p) await savePc({ javaPath: p }); }));
  $('#pcJavaAuto').addEventListener('click', () => savePc({ javaPath: '' }, 'Java automático'));
  $('#pcDirPick').addEventListener('click', (e) => act(e.currentTarget, async () => { const p = await api.pc.pickDir(); if (p) await savePc({ gameDir: p }); }));
  $('#pcDirOpen').addEventListener('click', (e) => act(e.currentTarget, () => api.openFolder('root', CA.selInstance()?.id)));

  /* ---------------- CÓDIGOS ---------------- */
  const mask = (c) => (c ? (c.length > 30 ? c.slice(0, 6) + '••••••••••••••••' : c.replace(/[A-Z0-9]/g, '•')) : '—');
  let hours = null;
  const mcName = (n) => { let s = String(n || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^A-Za-z0-9_]/g, '_').slice(0, 16); return (s.length < 3 ? (s + '___').slice(0, 3) : s).toLowerCase(); };
  const fmtHours = (secs) => { const h = Math.floor(secs / 3600), m = Math.floor((secs % 3600) / 60); return h ? `${h} h ${m} min` : `${m} min`; };
  function hoursPill(name) {
    if (!hours) return '<span class="hours none">⏱ …</span>';
    const st = hours.stats[mcName(name)];
    if (!st) return '<span class="hours none" title="Aún no ha jugado con el launcher">⏱ 0 h</span>';
    return `<span class="hours" title="Última vez: ${esc(fmtDate((st.lastPlayed || '').slice(0, 10)))}${st.sessions ? ' · ' + st.sessions + ' sesiones' : ''}">⏱ ${fmtHours(st.totalSeconds)}</span>`;
  }
  async function loadHours() {
    try { hours = await dev.stats(); } catch (e) { hours = { stats: {}, shared: false, error: e.message }; }
    if (S.current === 'codes') renderCodes(false);
  }
  function renderCodes(reload = true) {
    if (reload) loadHours();
    const q = $('#plSearch').value.trim().toLowerCase();
    const players = (S.view.players || []).filter((p) => !q || p.name.toLowerCase().includes(q) || p.note.toLowerCase().includes(q));
    $('#plCount').textContent = (S.view.players || []).length;
    $('#plHoursNote').innerHTML = hours && !hours.shared ? '⏱ Las horas solo muestran lo jugado en este PC. Activa el repositorio de jugadores en <b>Conexión</b> para ver las de todos.' : hours?.error ? '⚠️ ' + esc(hours.error) : '';
    $('#plTable').innerHTML = players.map((p) => `
      <div class="trow ${p.active ? '' : 'off'}">
        <div class="who"><b>${esc(p.name)}${hoursPill(p.name)}</b><small>Creado ${esc(fmtDate((p.createdAt || '').slice(0, 10)))}</small></div>
        <div class="code-cell"><span data-code="${esc(p.code || '')}">${mask(p.code)}</span>
          <button class="icon-btn" data-reveal title="Ver">👁</button><button class="icon-btn" data-copy="${esc(p.code || '')}" title="Copiar">📋</button></div>
        <div class="note" title="${esc(p.note)}">${esc(p.note) || '<span class="hint">Sin nota</span>'}</div>
        <div class="actions">
          <button class="switch ${p.active ? 'on' : ''}" data-pl-toggle="${p.id}" title="${p.active ? 'Activo' : 'Desactivado'}"></button>
          <button class="icon-btn" data-pl-edit="${p.id}" title="Editar">✏️</button>
          <button class="icon-btn" data-pl-regen="${p.id}" title="Regenerar código">🔄</button>
          <button class="icon-btn danger" data-pl-del="${p.id}" title="Eliminar">🗑</button>
        </div>
      </div>`).join('') || `<div class="empty small">${q ? 'Ningún jugador coincide.' : 'Todavía no hay jugadores. Crea el primer código arriba.'}</div>`;

    $('#dvCount').textContent = (S.view.devs || []).length;
    $('#dvTable').innerHTML = (S.view.devs || []).map((d) => `
      <div class="trow">
        <div class="who"><b>${esc(d.name)}${d.me ? ' (tú)' : ''}${hoursPill(d.name)}</b><small>${d.founder ? 'Fundador' : fmtDate(d.createdAt) ? 'Creado ' + esc(fmtDate(d.createdAt)) : 'Desarrollador'}</small></div>
        <div class="code-cell"><span data-code="${esc(d.code || '')}">${mask(d.code)}</span>
          <button class="icon-btn" data-reveal title="Ver">👁</button><button class="icon-btn" data-copy="${esc(d.code || '')}" title="Copiar">📋</button></div>
        <div class="note"><select data-dv-role="${d.id}" ${d.me ? 'disabled' : ''}><option value="mod" ${d.role === 'mod' ? 'selected' : ''}>Moderador</option><option value="dev" ${d.role !== 'mod' ? 'selected' : ''}>Desarrollador</option></select></div>
        <div class="actions">
          <button class="icon-btn" data-dv-regen="${d.id}" title="Regenerar código">🔄</button>
          <button class="icon-btn danger" data-dv-del="${d.id}" title="Eliminar" ${d.me ? 'disabled' : ''}>🗑</button>
        </div>
      </div>`).join('');
  }
  CA.hooks.codes = renderCodes;
  const prevRefreshed = CA.hooks.refreshed;
  CA.hooks.refreshed = () => { prevRefreshed?.(); if (S.current === 'codes') renderCodes(); };
  $('#plSearch').addEventListener('input', () => renderCodes(false));
  $('#dvTable').addEventListener('change', (e) => {
    const sel = e.target.closest('[data-dv-role]');
    if (!sel) return;
    act(sel, async () => { const r = await dev.devUpdate(sel.dataset.dvRole, { role: sel.value }); S.view = r.view; renderCodes(); }, 'Rol actualizado');
  });
  const codesView = $('#view-codes');
  codesView.addEventListener('click', async (e) => {
    const b = e.target.closest('button');
    if (!b) return;
    const findP = (id) => S.view.players.find((p) => p.id === id);
    if ('reveal' in b.dataset) {
      const span = $('[data-code]', b.parentElement);
      const shown = span.textContent === span.dataset.code;
      span.textContent = shown ? mask(span.dataset.code) : span.dataset.code;
    } else if (b.dataset.copy !== undefined) {
      if (!b.dataset.copy) return toast('Este código no se puede mostrar', 'err');
      navigator.clipboard.writeText(b.dataset.copy); toast('Código copiado', 'ok');
    } else if (b.dataset.plToggle) {
      const p = findP(b.dataset.plToggle);
      const r = await act(b, () => dev.playerUpdate(p.id, { active: !p.active }), p.active ? `${p.name} desactivado` : `${p.name} activado`);
      if (r) { S.view = r.view; renderCodes(); }
    } else if (b.dataset.plEdit) {
      const p = findP(b.dataset.plEdit);
      openModal({
        title: `Editar ${p.name}`,
        html: `<label class="field">Nombre en Minecraft<input id="edName" value="${esc(p.name)}" maxlength="16" /></label><label class="field">Nota<input id="edNote" value="${esc(p.note)}" /></label>`,
        actions: [{ label: 'Cancelar' }, { label: 'Guardar', kind: 'primary', onClick: async (btn) => {
          const newName = $('#edName').value.trim();
          const r = await act(btn, () => dev.playerUpdate(p.id, { name: newName, note: $('#edNote').value }), 'Jugador actualizado');
          if (!r) return true;
          S.view = r.view; renderCodes();
          if (r.code) showCode(`Nuevo código de ${newName}`, r.code, 'El código va ligado al nombre, así que al cambiar el nombre se creó uno nuevo. Envíaselo por privado.');
        } }],
      });
    } else if (b.dataset.plRegen) {
      const p = findP(b.dataset.plRegen);
      if (!(await confirmBox('Regenerar código', `El código actual de <b>${esc(p.name)}</b> dejará de funcionar y su sesión se cerrará.`, 'Regenerar', true))) return;
      const r = await act(b, () => dev.playerUpdate(p.id, { regenerate: true }));
      if (r) { S.view = r.view; renderCodes(); showCode(`Nuevo código de ${p.name}`, r.code, 'Envíaselo por privado. Lo puedes volver a ver aquí cuando quieras.'); }
    } else if (b.dataset.plDel) {
      const p = findP(b.dataset.plDel);
      if (!(await confirmBox('Eliminar jugador', `Se eliminará a <b>${esc(p.name)}</b> y su código dejará de funcionar.`, 'Eliminar', true))) return;
      const v = await act(b, () => dev.playerDelete(p.id), 'Jugador eliminado');
      if (v) { S.view = v; renderCodes(); }
    } else if (b.dataset.dvRegen) {
      const d = S.view.devs.find((x) => x.id === b.dataset.dvRegen);
      if (!(await confirmBox('Regenerar código de desarrollador', `El código actual de <b>${esc(d.name)}</b> dejará de funcionar.${d.me ? ' Es tu propio código: apunta el nuevo antes de cerrar la ventana.' : ''}`, 'Regenerar', true))) return;
      const r = await act(b, () => dev.devUpdate(d.id, { regenerate: true }));
      if (r) { S.view = r.view; renderCodes(); showCode(`Nuevo código de ${d.name}`, r.code, 'Guárdalo en un lugar seguro y compártelo solo por privado.'); }
    } else if (b.dataset.dvDel) {
      const d = S.view.devs.find((x) => x.id === b.dataset.dvDel);
      if (!(await confirmBox('Eliminar desarrollador', `<b>${esc(d.name)}</b> perderá el acceso de desarrollador.`, 'Eliminar', true))) return;
      const v = await act(b, () => dev.devDelete(d.id), 'Desarrollador eliminado');
      if (v) { S.view = v; renderCodes(); }
    }
  });
  $('#plForm').addEventListener('submit', (e) => {
    e.preventDefault();
    act($('button', e.target), async () => {
      const r = await dev.playerCreate($('#plName').value, $('#plNote').value.trim());
      S.view = r.view;
      const name = $('#plName').value.trim();
      $('#plName').value = ''; $('#plNote').value = '';
      renderCodes();
      openModal({
        title: `Código de ${name}`,
        html: `<p class="hint">Envíaselo a <b>${esc(name)}</b> por privado. Para entrar tendrá que escribir su nombre (<b>${esc(name)}</b>) y este código. Funciona en cualquier PC.</p><div class="code-big">${esc(r.code)}</div>`,
        actions: [
          { label: 'Copiar código', kind: 'primary', onClick: () => { navigator.clipboard.writeText(r.code); toast('Código copiado', 'ok'); return true; } },
          { label: 'Copiar mensaje completo', onClick: () => { navigator.clipboard.writeText(playerMessage(r.code, name)); toast('Mensaje copiado', 'ok'); return true; } },
          { label: 'Listo' },
        ],
      });
    });
  });
  $('#dvForm').addEventListener('submit', (e) => {
    e.preventDefault();
    act($('button', e.target), async () => {
      const name = $('#dvName').value.trim();
      const role = $('#dvRole').value;
      const r = await dev.devCreate(name, role);
      S.view = r.view;
      $('#dvName').value = '';
      renderCodes();
      showCode(`Código de ${role === 'mod' ? 'moderador' : 'desarrollador'} de ${name}`, r.code, (role === 'mod' ? 'Compártelo por privado: permite gestionar instancias y mods.' : 'Compártelo solo por privado: da acceso total al launcher.') + ' Funciona en cualquier PC: usa "Copiar código" y que lo pegue completo en la pestaña Desarrollador.');
    });
  });

  /* ---------------- ganchos ---------------- */
  CA.hooks.custom = () => renderSub();
  CA.hooks.enter = () => { $('#publishBar').hidden = true; };
})();
