'use strict';
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const { app, BrowserWindow, ipcMain, shell, dialog, nativeImage } = require('electron');

const store = require('./datastore');
const prefs = require('./prefs');
const game = require('./game');
const skins = require('./skins');
const updater = require('./updater');
const stats = require('./stats');
const modrinth = require('./modrinth');
const { ping } = require('./ping');
const { sha1File, fetchBuffer } = require('./download');
const { safeName } = require('./modpack');
const { PRESETS, FONTS, defaults, defaultInstance } = require('./defaults');

// Una sola ventana del launcher a la vez.
if (!app.requestSingleInstanceLock()) { app.quit(); return; }

let win = null;
const ICON = path.join(__dirname, '..', 'renderer', 'assets', 'icon.png');

function createWindow() {
  win = new BrowserWindow({
    width: 1200, height: 760, minWidth: 1000, minHeight: 660,
    frame: false, backgroundColor: '#0e0914', show: false, title: 'Caldito Launcher',
    icon: nativeImage.createFromPath(ICON),
    webPreferences: { preload: path.join(__dirname, '..', 'preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true },
  });
  win.loadFile(path.join(__dirname, '..', 'renderer', 'index.html'));
  win.once('ready-to-show', () => { win.show(); updater.BOOT.confirm(); });
  if (process.argv.includes('--dev')) win.webContents.openDevTools({ mode: 'detach' });
  win.webContents.setWindowOpenHandler(({ url }) => { if (/^https?:\/\//.test(url)) shell.openExternal(url); return { action: 'deny' }; });
  // Al cerrar la ventana se olvida: así nadie intenta usar una ventana ya destruida
  win.on('closed', () => { win = null; });
}
const alive = () => !!win && !win.isDestroyed();
// Abrir el launcher otra vez (p. ej. con el juego abierto y la ventana cerrada): se muestra o se vuelve a crear
app.on('second-instance', () => {
  if (!alive()) { if (app.isReady()) createWindow(); return; }
  if (win.isMinimized()) win.restore();
  win.show();
  win.focus();
});

const send = (ch, data) => alive() && win.webContents.send(ch, data);
function handle(channel, fn) {
  ipcMain.handle(channel, async (_e, ...args) => {
    try { return { ok: true, data: await fn(...args) }; }
    catch (err) { return { ok: false, error: err?.message || String(err) }; }
  });
}
const devHandle = (ch, fn) => handle(ch, async (...a) => { store.requireDev(); return fn(...a); });
const staffHandle = (ch, fn) => handle(ch, async (...a) => { store.requireStaff(); return fn(...a); });
const netError = (e) => /fetch failed|ENOTFOUND|ECONNRESET|ECONNREFUSED|ETIMEDOUT|EAI_AGAIN/i.test(e.message);
const friendly = (e) => (netError(e) ? new Error('No hay conexión con internet o el servicio no responde. Revisa tu conexión (o el antivirus/firewall).') : e);

/* ---------- ventana ---------- */
ipcMain.on('win:minimize', () => win?.minimize());
ipcMain.on('win:maximize', () => (win?.isMaximized() ? win.unmaximize() : win?.maximize()));
ipcMain.on('win:close', () => win?.close());

/* ---------- arranque y sesión ---------- */
handle('boot', async () => ({
  view: await store.boot(), pc: prefs.get(), appVersion: updater.status().running,
  presets: PRESETS, fonts: FONTS, defaults: defaults(), defaultInstance: defaultInstance(), update: updater.status(),
}));
handle('refresh', () => store.refresh());
handle('auth:player', (code, name) => store.loginPlayer(code, name));
handle('auth:dev', (code, remember) => store.loginDev(code, remember));
handle('auth:logout', () => store.logout());
handle('auth:connect', async (code) => { try { return await store.connectWithCode(code); } catch (e) { throw friendly(e); } });
handle('auth:microsoft', () => game.linkMicrosoft());
handle('auth:microsoftUnlink', () => { prefs.setMicrosoft(null); return true; });

/* ---------- servidor ---------- */
handle('server:ping', (target) => {
  let t = target;
  if (typeof target === 'string' || !target) t = store.getInstance(target);
  else if (!store.isStaff()) t = store.getInstance();
  return ping(String(t.host || '').trim(), Number(t.port) || 25565);
});

/* ---------- jugar ---------- */
handle('game:play', async (instanceId) => {
  prefs.set({ selectedInstance: instanceId });
  try {
    await game.play(instanceId, (ch, data) => {
      send(`game:${ch}`, data);
      if (ch === 'game' && data.running) {
        const mode = prefs.raw().afterLaunch;
        if (mode === 'hide' && alive()) win.hide();
        if (mode === 'close') setTimeout(() => app.quit(), 4000);
      }
      if (ch === 'game' && !data.running) {
        if (alive()) win.show();
        else app.quit();   // la ventana se cerró mientras se jugaba: al salir del juego se cierra el launcher
      }
    });
  } catch (e) {
    if (netError(e)) send('game:log', '[Caldito] ' + e.message + (e.cause ? ' · ' + e.cause.message : ''));
    throw friendly(e);
  }
});

/* ---------- carpetas y enlaces ---------- */
handle('folder:open', async (which, instanceId) => {
  const sub = { mods: 'mods', screenshots: 'screenshots', resourcepacks: 'resourcepacks', shaderpacks: 'shaderpacks', logs: 'logs', saves: 'saves' }[which] || '';
  const base = which === 'launcher' ? app.getPath('userData') : prefs.instanceDir(store.getInstance(instanceId || prefs.raw().selectedInstance)?.id || 'principal');
  const dir = path.join(base, which === 'launcher' ? '' : sub);
  await fs.promises.mkdir(dir, { recursive: true });
  const err = await shell.openPath(dir);
  if (err) throw new Error(err);
  return true;
});
handle('link:open', async (url) => {
  if (!/^https?:\/\//i.test(String(url))) throw new Error('Enlace no válido (debe empezar por https://).');
  await shell.openExternal(url);
  return true;
});

/* ---------- ajustes de este PC ---------- */
handle('pc:get', () => prefs.get());
handle('pc:set', (patch) => {
  const staff = store.isStaff();
  const open = ['ramMB', 'width', 'height', 'fullscreen', 'afterLaunch', 'selectedInstance'];
  const allowed = staff ? patch : Object.fromEntries(Object.entries(patch).filter(([k]) => open.includes(k)));
  return prefs.set(allowed);
});
staffHandle('pc:pickDir', async () => { const r = await dialog.showOpenDialog(win, { properties: ['openDirectory', 'createDirectory'] }); return r.canceled ? null : r.filePaths[0]; });
staffHandle('pc:pickJava', async () => { const r = await dialog.showOpenDialog(win, { properties: ['openFile'], title: 'Selecciona java / javaw.exe' }); return r.canceled ? null : r.filePaths[0]; });

/* ---------- skins y capas (todos con sesión) ---------- */
const needSession = (fn) => async (...a) => { store.requireSession(); return fn(...a); };
handle('skins:list', needSession(() => skins.list()));
handle('skins:upload', needSession(async (kind) => {
  const r = await dialog.showOpenDialog(win, { properties: ['openFile'], filters: [{ name: 'PNG', extensions: ['png'] }] });
  if (r.canceled) return null;
  const f = r.filePaths[0];
  const buf = await fs.promises.readFile(f);
  const name = path.basename(f, path.extname(f));
  return kind === 'cape' ? skins.addCape(buf, name) : skins.addSkin(buf, name);
}));
handle('skins:importName', needSession(async (name) => { try { return await skins.importFromName(name); } catch (e) { throw friendly(e); } }));
handle('skins:update', needSession((id, patch) => skins.updateSkin(id, patch)));
handle('skins:remove', needSession((kind, id) => skins.removeItem(kind, id)));
handle('skins:apply', needSession(async (opts) => { try { return await skins.apply(opts); } catch (e) { throw friendly(e); } }));
handle('skins:mojangProfile', needSession(async () => { try { return await skins.mojangProfile(); } catch (e) { throw friendly(e); } }));
handle('skins:mojangCape', needSession((id) => skins.mojangSetCape(id)));

/* ---------- reparar y actualizar ---------- */
handle('update:status', () => updater.status());
handle('update:install', needSession(async () => {
  try { return await updater.install((p) => send('update:progress', p)); } catch (e) { throw friendly(e); }
}));
handle('update:revert', () => updater.revert());
handle('update:restart', () => updater.restart());
handle('repair:run', needSession(async (tool, arg) => {
  try { return await updater.repair(tool, arg, (p) => send('repair:progress', p)); } catch (e) { throw friendly(e); }
}));
handle('repair:diagnostics', () => updater.diagnostics());
devHandle('update:publish', async (notes) => {
  const r = await dialog.showOpenDialog(win, { properties: ['openFile'], filters: [{ name: 'Paquete de actualización', extensions: ['zip'] }] });
  if (r.canceled) return null;
  return updater.publish(r.filePaths[0], notes);
});
devHandle('update:retire', () => store.setUpdate(null));

/* ---------- desarrolladores: personalización ---------- */
devHandle('dev:publish', (patch) => store.publish(patch));
devHandle('dev:pickImage', async (maxKB = 1500) => {
  const r = await dialog.showOpenDialog(win, { properties: ['openFile'], filters: [{ name: 'Imágenes', extensions: ['png', 'jpg', 'jpeg', 'webp', 'gif', 'svg'] }] });
  if (r.canceled) return null;
  const f = r.filePaths[0];
  const buf = await fs.promises.readFile(f);
  if (buf.length > maxKB * 1024) throw new Error(`La imagen pesa ${(buf.length / 1024).toFixed(0)} KB; el máximo es ${maxKB} KB.`);
  const ext = path.extname(f).slice(1).toLowerCase().replace('jpg', 'jpeg').replace('svg', 'svg+xml');
  return `data:image/${ext};base64,${buf.toString('base64')}`;
});
devHandle('dev:pickCape', async () => {
  const r = await dialog.showOpenDialog(win, { properties: ['openFile'], filters: [{ name: 'PNG', extensions: ['png'] }] });
  if (r.canceled) return null;
  const buf = await fs.promises.readFile(r.filePaths[0]);
  skins.checkCape(buf);
  return { name: path.basename(r.filePaths[0], '.png'), img: `data:image/png;base64,${buf.toString('base64')}` };
});
devHandle('dev:exportTheme', async (json) => {
  const r = await dialog.showSaveDialog(win, { defaultPath: 'caldito-tema.json', filters: [{ name: 'JSON', extensions: ['json'] }] });
  if (r.canceled) return null;
  await fs.promises.writeFile(r.filePath, JSON.stringify(json, null, 2));
  return r.filePath;
});
devHandle('dev:importTheme', async () => {
  const r = await dialog.showOpenDialog(win, { properties: ['openFile'], filters: [{ name: 'JSON', extensions: ['json'] }] });
  if (r.canceled) return null;
  try { return JSON.parse(await fs.promises.readFile(r.filePaths[0], 'utf8')); } catch { throw new Error('Ese archivo no es un tema válido.'); }
});

/* ---------- códigos ---------- */
devHandle('dev:playerCreate', (n, note) => store.createPlayer(n, note));
devHandle('dev:playerUpdate', (id, p) => store.updatePlayer(id, p));
devHandle('dev:playerDelete', (id) => store.deletePlayer(id));
devHandle('dev:devCreate', (n, role) => store.createDev(n, role));
devHandle('dev:devUpdate', (id, p) => store.updateDev(id, p));
devHandle('dev:devDelete', (id) => store.deleteDev(id));

/* ---------- instancias y mods (moderadores y desarrolladores) ---------- */
staffHandle('staff:saveInstances', (list) => store.saveInstances(list));
async function modContext(instanceId) {
  const inst = store.getInstance(instanceId);
  if (inst.loader === 'vanilla') throw new Error(`"${inst.name}" está en modo vanilla. Cambia su cargador a Fabric o Quilt en Instancias para usar mods.`);
  return { version: await game.resolveVersion(inst), loader: inst.loader, instance: inst.id };
}
staffHandle('staff:modContext', modContext);
staffHandle('staff:modSearch', async (instanceId, q) => {
  const c = await modContext(instanceId);
  try { return { ...c, hits: await modrinth.search(q, c.version, c.loader) }; } catch (e) { throw friendly(e); }
});
staffHandle('staff:modAddModrinth', async (instanceId, projectId) => {
  const c = await modContext(instanceId);
  const mods = await modrinth.resolve(projectId, c.version, c.loader).catch((e) => { throw friendly(e); });
  return { added: mods.map((m) => m.name), view: await store.addMods(instanceId, mods) };
});
staffHandle('staff:modAddModrinthMany', async (instanceId, ids) => {
  const c = await modContext(instanceId);
  const seen = new Set();
  const mods = [], failed = [];
  for (const id of [...new Set(ids || [])]) {
    try {
      for (const m of await modrinth.resolve(id, c.version, c.loader, seen)) mods.push(m);
    } catch (e) { failed.push(netError(e) ? 'sin conexión' : e.message); }
  }
  if (!mods.length) throw new Error(failed[0] || 'No se pudo añadir ningún mod.');
  return { added: mods.map((m) => m.name), failed, view: await store.addMods(instanceId, mods) };
});
staffHandle('staff:modUpload', async (instanceId) => {
  const r = await dialog.showOpenDialog(win, { properties: ['openFile', 'multiSelections'], filters: [{ name: 'Mods', extensions: ['jar'] }] });
  if (r.canceled) return null;
  const mods = [];
  for (const f of r.filePaths) {
    const file = safeName(path.basename(f));
    const buf = await fs.promises.readFile(f);
    const url = await store.putFile(`mods/${file}`, buf);
    mods.push({ name: file.replace(/\.jar$/i, ''), file, url, sha1: await sha1File(f), size: buf.length, source: 'upload' });
  }
  return { added: mods.map((m) => m.name), view: await store.addMods(instanceId, mods) };
});
staffHandle('staff:modAddUrl', async (instanceId, urls) => {
  // Acepta uno o varios enlaces (uno por línea).
  const list = (Array.isArray(urls) ? urls : String(urls || '').split(/\s+/)).map((u) => u.trim()).filter(Boolean);
  if (!list.length) throw new Error('Pega al menos un enlace a un archivo .jar');
  const mods = [];
  for (const url of list) {
    if (!/^https:\/\//i.test(url)) throw new Error(`El enlace debe empezar por https:// (${url})`);
    let file = decodeURIComponent(new URL(url).pathname.split('/').pop() || '');
    if (!/\.jar$/i.test(file)) throw new Error(`El enlace debe apuntar directamente a un archivo .jar (${url})`);
    file = safeName(file);
    const buf = await fetchBuffer(url).catch((e) => { throw friendly(e); });
    mods.push({ name: file.replace(/\.jar$/i, ''), file, url, sha1: crypto.createHash('sha1').update(buf).digest('hex'), size: buf.length, source: 'url' });
  }
  return { added: mods.map((m) => m.name), view: await store.addMods(instanceId, mods) };
});
staffHandle('staff:modRemove', (instanceId, id) => store.removeMod(instanceId, id));

/* ---------- mods y configuración desde la carpeta de la instancia del equipo ---------- */
function instanceFolderInfo(instanceId) {
  const inst = store.getInstance(instanceId);
  const dir = prefs.instanceDir(inst.id);
  let managed = [];
  try { managed = JSON.parse(fs.readFileSync(path.join(dir, '.caldito-managed.json'), 'utf8')).files || []; } catch {}
  const published = new Set(inst.mods.map((m) => m.file.toLowerCase()));
  const skip = new Set(managed.map((f) => f.toLowerCase()));
  let jars = [];
  try { jars = fs.readdirSync(path.join(dir, 'mods')).filter((f) => /\.jar$/i.test(f)); } catch {}
  const fresh = jars.filter((f) => !published.has(f.toLowerCase()) && !skip.has(f.toLowerCase()))
    .map((f) => ({ file: f, size: fs.statSync(path.join(dir, 'mods', f)).size }));
  return { inst, dir, fresh };
}
staffHandle('staff:modsFolderScan', (instanceId) => {
  const { dir, fresh } = instanceFolderInfo(instanceId);
  return { folder: path.join(dir, 'mods'), fresh };
});
staffHandle('staff:modsFolderOpen', async (instanceId) => {
  const { dir } = instanceFolderInfo(instanceId);
  await fs.promises.mkdir(path.join(dir, 'mods'), { recursive: true });
  const err = await shell.openPath(path.join(dir, 'mods'));
  if (err) throw new Error(err);
  return true;
});
staffHandle('staff:modsFolderPublish', async (instanceId) => {
  const { inst, dir, fresh } = instanceFolderInfo(instanceId);
  if (!fresh.length) throw new Error('No hay mods nuevos en tu carpeta de mods de esta instancia.');
  const mods = [];
  for (const { file } of fresh) {
    const name = safeName(file);
    const full = path.join(dir, 'mods', name);
    const buf = await fs.promises.readFile(full);
    const url = await store.putFile(`mods/${name}`, buf);
    mods.push({ name: name.replace(/\.jar$/i, ''), file: name, url, sha1: await sha1File(full), size: buf.length, source: 'upload' });
  }
  const view = await store.addMods(inst.id, mods);
  return { added: mods.map((m) => m.name), view };
});
const CONFIG_DIRS = ['config/fancymenu', 'config/drippyloadingscreen'];
staffHandle('staff:configPublish', async (instanceId) => {
  const { inst, dir } = instanceFolderInfo(instanceId);
  const files = [];
  const walk = (rel) => {
    const full = path.join(dir, rel);
    if (!fs.existsSync(full)) return;
    for (const e of fs.readdirSync(full, { withFileTypes: true })) {
      const r = `${rel}/${e.name}`;
      if (e.isDirectory()) walk(r);
      else if (!/\.(log|tmp|lock)$/i.test(e.name)) files.push(r);
    }
  };
  CONFIG_DIRS.forEach(walk);
  if (!files.some((f) => f.startsWith('config/fancymenu/customization/'))) throw new Error('No encontré diseños de FancyMenu en tu carpeta de esta instancia. Abre Minecraft con esta instancia y guarda tu diseño primero.');
  const out = [];
  for (const rel of files) {
    const buf = await fs.promises.readFile(path.join(dir, rel));
    if (buf.length > 20 * 1024 * 1024) continue;
    const url = await store.putFile(`instances/${inst.id}/${rel}`, buf);
    out.push({ path: rel, url, sha1: crypto.createHash('sha1').update(buf).digest('hex'), size: buf.length });
  }
  return { count: out.length, view: await store.setInstanceFiles(inst.id, out) };
});
staffHandle('staff:configReset', (instanceId) => store.setInstanceFiles(store.getInstance(instanceId).id, []));
staffHandle('staff:pickImage', async () => {
  const r = await dialog.showOpenDialog(win, { properties: ['openFile'], filters: [{ name: 'Imágenes', extensions: ['png', 'jpg', 'jpeg', 'webp'] }] });
  if (r.canceled) return null;
  const buf = await fs.promises.readFile(r.filePaths[0]);
  if (buf.length > 600 * 1024) throw new Error('La imagen de la instancia debe pesar menos de 600 KB.');
  const ext = path.extname(r.filePaths[0]).slice(1).toLowerCase().replace('jpg', 'jpeg');
  return `data:image/${ext};base64,${buf.toString('base64')}`;
});

/* ---------- conexión ---------- */
devHandle('dev:stats', async () => { try { return await stats.list(); } catch (e) { throw friendly(e); } });
devHandle('dev:githubConnect', async (cfg) => { try { return await store.connectGithub(cfg); } catch (e) { throw friendly(e); } });
devHandle('dev:useLocal', () => store.useLocal());
devHandle('dev:skinsRepo', async (cfg) => { try { return await store.setSkinsRepo(cfg); } catch (e) { throw friendly(e); } });

app.whenReady().then(createWindow);
app.on('window-all-closed', () => { if (!game.isRunning()) app.quit(); });
app.on('activate', () => BrowserWindow.getAllWindows().length === 0 && createWindow());
