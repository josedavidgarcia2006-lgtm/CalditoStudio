'use strict';
// Actualizaciones del launcher sin reinstalar + herramientas de reparación.
const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const { app } = require('electron');
const store = require('./datastore');
const prefs = require('./prefs');
const { downloadFile, sha1File } = require('./download');

const BOOT = global.CALDITO_BOOT || {
  root: path.join(__dirname, '..'), builtinSrc: path.join(__dirname, '..'),
  builtinVersion: readVersion(path.join(__dirname, '..')), activeVersion: readVersion(path.join(__dirname, '..')),
  codeDir: path.join(app.getPath('userData'), 'app-code'), shellVersion: app.getVersion(), note: null, confirm() {},
};
function readVersion(src) { try { return JSON.parse(fs.readFileSync(path.join(src, 'version.json'), 'utf8')).version; } catch { return '0.0.0'; } }
function cmp(a, b) {
  const x = String(a).split('.').map(Number), y = String(b).split('.').map(Number);
  for (let i = 0; i < 3; i++) if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) - (y[i] || 0);
  return 0;
}
const sha256File = (f) => new Promise((res, rej) => {
  const h = crypto.createHash('sha256');
  fs.createReadStream(f).on('data', (d) => h.update(d)).on('end', () => res(h.digest('hex'))).on('error', rej);
});

/* ---------- estado ---------- */
function status() {
  const u = store.getData()?.update || null;
  const running = BOOT.activeVersion;
  const tooNew = u?.minShell && cmp(BOOT.shellVersion, u.minShell) < 0;
  return {
    running, installed: BOOT.builtinVersion, shell: BOOT.shellVersion, electron: process.versions.electron,
    usingUpdate: running !== BOOT.builtinVersion, note: BOOT.note,
    published: u, available: !!(u && cmp(u.version, running) > 0 && !tooNew), needsReinstall: !!(u && cmp(u.version, running) > 0 && tooNew),
  };
}

/* ---------- instalar la actualización publicada ---------- */
async function install(onProgress) {
  const st = status();
  const u = st.published;
  if (!u) throw new Error('No hay ninguna actualización publicada.');
  if (st.needsReinstall) throw new Error(`Esta actualización necesita el instalador ${u.minShell} o superior. Descárgalo desde el enlace que comparta el equipo.`);
  if (!st.available) throw new Error('Ya tienes la última versión.');

  const tmp = path.join(os.tmpdir(), `caldito-update-${u.version}.zip`);
  await downloadFile(u.url, tmp, { onProgress: (d, t) => onProgress?.({ task: 'Descargando actualización', done: d, total: t || u.size || d }) });
  if (u.sha256 && (await sha256File(tmp)) !== u.sha256) { fs.rmSync(tmp, { force: true }); throw new Error('La actualización llegó dañada (no coincide su huella). Inténtalo de nuevo.'); }

  onProgress?.({ task: 'Instalando', done: 0, total: 1 });
  const dest = path.join(BOOT.codeDir, u.version);
  fs.rmSync(dest, { recursive: true, force: true });
  await require('extract-zip')(tmp, { dir: dest });
  fs.rmSync(tmp, { force: true });
  const src = path.join(dest, 'src');
  if (!fs.existsSync(path.join(src, 'main', 'main.js')) || readVersion(src) !== u.version) {
    fs.rmSync(dest, { recursive: true, force: true });
    throw new Error('El paquete de actualización no es válido.');
  }
  fs.writeFileSync(path.join(BOOT.codeDir, 'current.json'), JSON.stringify({ version: u.version, src, installedAt: new Date().toISOString() }, null, 2));
  // Borramos versiones viejas descargadas.
  for (const d of fs.readdirSync(BOOT.codeDir)) {
    const full = path.join(BOOT.codeDir, d);
    if (/^\d+\.\d+\.\d+$/.test(d) && d !== u.version && full !== BOOT.root.replace(/[\\/]src$/, '')) fs.rmSync(full, { recursive: true, force: true });
  }
  return u.version;
}

function revert() {
  fs.rmSync(path.join(BOOT.codeDir, 'current.json'), { force: true });
  return true;
}
function restart() { app.relaunch(); app.exit(0); }

/* ---------- publicar (desarrolladores) ---------- */
async function inspectPackage(file) {
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'caldito-pkg-'));
  try {
    await require('extract-zip')(file, { dir: tmp });
    const src = path.join(tmp, 'src');
    if (!fs.existsSync(path.join(src, 'main', 'main.js')) || !fs.existsSync(path.join(src, 'version.json'))) throw new Error('Ese .zip no es un paquete de actualización de Caldito Launcher.');
    const meta = JSON.parse(fs.readFileSync(path.join(src, 'version.json'), 'utf8'));
    return { version: meta.version, minShell: meta.minShell || null, notes: meta.notes || '' };
  } finally { fs.rmSync(tmp, { recursive: true, force: true }); }
}
async function publish(file, notes) {
  store.requireDev();
  const info = await inspectPackage(file);
  const current = store.getData().update?.version || BOOT.activeVersion;
  if (cmp(info.version, current) <= 0) throw new Error(`La versión del paquete (${info.version}) debe ser mayor que la publicada (${current}).`);
  const buf = await fs.promises.readFile(file);
  const url = await store.putFile(`updates/caldito-update-${info.version}.zip`, buf);
  const update = {
    version: info.version, minShell: info.minShell, notes: String(notes || info.notes || '').slice(0, 2000),
    url, size: buf.length, sha256: crypto.createHash('sha256').update(buf).digest('hex'),
    publishedAt: new Date().toISOString(), publishedBy: store.getSession().name,
  };
  return store.setUpdate(update);
}

/* ---------- reparación ---------- */
const rm = (p) => fs.promises.rm(p, { recursive: true, force: true });
const TOOLS = {
  async minecraft() { const r = prefs.gameDir(); await Promise.all(['versions', 'libraries', 'natives', path.join('assets', 'indexes')].map((d) => rm(path.join(r, d)))); return 'Minecraft se volverá a descargar al pulsar JUGAR.'; },
  async java() { await rm(path.join(app.getPath('userData'), 'runtime')); return 'Java se volverá a descargar al pulsar JUGAR.'; },
  async mods(instanceId, onProgress) {
    // Traemos lo último que publicó el equipo, borramos lo que instaló el launcher y lo descargamos de nuevo.
    await store.refresh().catch(() => {});
    const inst = store.getInstance(instanceId);
    const dir = prefs.instanceDir(inst.id);
    const managed = path.join(dir, '.caldito-managed.json');
    let files = [];
    try { files = JSON.parse(fs.readFileSync(managed, 'utf8')).files || []; } catch {}
    await Promise.all(files.map((f) => rm(path.join(dir, 'mods', path.basename(f)))));
    await rm(managed);
    const { syncMods, syncFiles } = require('./modpack');
    if (inst.loader !== 'vanilla' && inst.mods.length) await syncMods(dir, inst.mods, onProgress);
    if (inst.loader !== 'vanilla' && (inst.files || []).length) await syncFiles(dir, inst.files, onProgress);
    if (inst.loader === 'vanilla') return `"${inst.name}" está en modo vanilla: no usa mods.`;
    return `Mods de "${inst.name}" actualizados: ${inst.mods.length} del equipo. Los de skins y menú se completan al pulsar JUGAR.`;
  },
  async cache() { await rm(path.join(app.getPath('userData'), 'data-cache.json')); await store.refresh(); return 'Caché de datos borrada y recargada.'; },
  async settings() { prefs.reset(); return 'Ajustes de este PC restablecidos.'; },
};
async function repair(tool, arg, onProgress) {
  if (!TOOLS[tool]) throw new Error('Herramienta desconocida.');
  return TOOLS[tool](arg, onProgress);
}

async function diagnostics() {
  const st = status();
  const d = store.getData();
  const v = store.view();
  const p = prefs.get();
  return [
    `Caldito Launcher ${st.running} (instalado ${st.installed}, programa ${st.shell}, Electron ${st.electron})`,
    `Sistema: ${os.type()} ${os.release()} ${process.arch} · RAM ${Math.round(os.totalmem() / 1073741824)} GB`,
    `Datos: ${v.sync.provider}${v.sync.repo ? ' ' + v.sync.repo : ''} (${v.sync.source})${v.sync.error ? ' · error: ' + v.sync.error : ''}`,
    `Sesión: ${v.session ? v.session.role + ' ' + v.session.name : 'ninguna'}`,
    `Instancias: ${d.instances.map((i) => `${i.name} [${i.host}:${i.port} ${i.mcVersion}/${i.loader} · ${i.mods.length} mods]`).join('; ')}`,
    `Carpeta del juego: ${prefs.gameDir()} · Java: ${p.javaPath || 'automático'} · RAM: ${p.ramMB || 'recomendada'}`,
    `Actualización publicada: ${st.published ? st.published.version : 'ninguna'}${st.note ? ' · ' + st.note : ''}`,
  ].join('\n');
}

module.exports = { status, install, revert, restart, publish, inspectPackage, repair, diagnostics, BOOT, cmp };
