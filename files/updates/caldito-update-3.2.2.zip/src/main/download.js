'use strict';
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { Readable, Transform } = require('stream');
const { pipeline } = require('stream/promises');

const UA = 'CalditoStudio-Launcher/2.0 (github.com/caldito-studio)';

async function fetchJson(url) {
  const res = await fetch(url, { headers: { 'User-Agent': UA, 'Cache-Control': 'no-cache' } });
  if (!res.ok) throw new Error(`HTTP ${res.status} al pedir ${url}`);
  return res.json();
}

function sha1File(file) {
  return new Promise((resolve, reject) => {
    const h = crypto.createHash('sha1');
    fs.createReadStream(file)
      .on('data', (d) => h.update(d))
      .on('end', () => resolve(h.digest('hex')))
      .on('error', reject);
  });
}

/**
 * Descarga un archivo a disco (vía .part para no dejar archivos a medias).
 * onProgress(bytesDescargados, bytesTotales)
 */
async function downloadFile(url, dest, { sha1, onProgress } = {}) {
  await fs.promises.mkdir(path.dirname(dest), { recursive: true });
  if (url.startsWith('file:')) {
    // Archivos guardados en este PC (modo local).
    await fs.promises.copyFile(new URL(url), dest + '.part');
    if (sha1 && (await sha1File(dest + '.part')) !== sha1.toLowerCase()) {
      await fs.promises.rm(dest + '.part', { force: true });
      throw new Error(`Hash incorrecto en ${path.basename(dest)}`);
    }
    await fs.promises.rename(dest + '.part', dest);
    return dest;
  }
  const res = await fetch(url, { headers: { 'User-Agent': UA } });
  if (!res.ok || !res.body) throw new Error(`HTTP ${res.status} al descargar ${url}`);

  const total = Number(res.headers.get('content-length')) || 0;
  let done = 0;
  const counter = new Transform({
    transform(chunk, _enc, cb) {
      done += chunk.length;
      if (onProgress) onProgress(done, total);
      cb(null, chunk);
    },
  });

  const tmp = dest + '.part';
  await pipeline(Readable.fromWeb(res.body), counter, fs.createWriteStream(tmp));

  if (sha1) {
    const got = await sha1File(tmp);
    if (got.toLowerCase() !== sha1.toLowerCase()) {
      await fs.promises.rm(tmp, { force: true });
      throw new Error(`Hash incorrecto en ${path.basename(dest)} (esperado ${sha1}, obtenido ${got})`);
    }
  }
  await fs.promises.rename(tmp, dest);
  return dest;
}

async function fetchBuffer(url) {
  const res = await fetch(url, { headers: { 'User-Agent': UA } });
  if (!res.ok) throw new Error(`HTTP ${res.status} al descargar ${url}`);
  return Buffer.from(await res.arrayBuffer());
}

module.exports = { fetchJson, fetchBuffer, downloadFile, sha1File, UA };
