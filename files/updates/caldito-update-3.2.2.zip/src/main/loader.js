'use strict';
const fs = require('fs');
const path = require('path');
const { fetchJson } = require('./download');

const FABRIC_META = 'https://meta.fabricmc.net/v2/versions/loader';
const QUILT_META = 'https://meta.quiltmc.org/v3/versions/loader';

/**
 * Prepara el perfil del cargador de mods (Fabric o Quilt) dentro de
 * <root>/versions/<id>/<id>.json y devuelve el id para usar como "custom".
 * Para vanilla devuelve null.
 */
async function prepareLoader(root, mc) {
  const loader = (mc.loader || 'vanilla').toLowerCase();
  if (loader === 'vanilla') return null;

  const meta = loader === 'fabric' ? FABRIC_META : loader === 'quilt' ? QUILT_META : null;
  if (!meta) throw new Error(`Cargador no soportado: ${mc.loader}. Usa "vanilla", "fabric" o "quilt".`);

  let lv = mc.loaderVersion;
  if (!lv || lv === 'latest') {
    const list = await fetchJson(`${meta}/${mc.version}`);
    if (!list.length) throw new Error(`${loader} no tiene versiones para Minecraft ${mc.version}.`);
    const stable = list.find((v) => v.loader.stable !== false) || list[0];
    lv = stable.loader.version;
  }

  const profile = await fetchJson(`${meta}/${mc.version}/${lv}/profile/json`);
  const id = profile.id;
  const dir = path.join(root, 'versions', id);
  await fs.promises.mkdir(dir, { recursive: true });
  await fs.promises.writeFile(path.join(dir, `${id}.json`), JSON.stringify(profile, null, 2));
  return id;
}

module.exports = { prepareLoader };
