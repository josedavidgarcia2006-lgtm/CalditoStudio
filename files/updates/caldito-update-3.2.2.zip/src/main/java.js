'use strict';
const fs = require('fs');
const path = require('path');
const { app } = require('electron');
const { downloadFile } = require('./download');

/** Versión de Java que necesita cada versión de Minecraft. */
function requiredJava(mcVersion) {
  const [, minor = 0, patch = 0] = mcVersion.split('.').map(Number);
  if (minor > 20 || (minor === 20 && patch >= 5)) return 21;
  if (minor >= 17) return 17;
  return 8;
}

function platform() {
  const os = { win32: 'windows', darwin: 'mac', linux: 'linux' }[process.platform];
  const arch = { x64: 'x64', arm64: 'aarch64' }[process.arch];
  if (!os || !arch) throw new Error(`Plataforma no soportada: ${process.platform}/${process.arch}`);
  return { os, arch };
}

function findJavaBinary(dir, depth = 0) {
  const exe = process.platform === 'win32' ? 'javaw.exe' : 'java';
  const candidate = path.join(dir, 'bin', exe);
  if (fs.existsSync(candidate)) return candidate;
  if (depth > 3 || !fs.existsSync(dir)) return null;
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    if (!e.isDirectory()) continue;
    const found = findJavaBinary(path.join(dir, e.name), depth + 1);
    if (found) return found;
  }
  return null;
}

/**
 * Devuelve una ruta a Java válida; si no hay una gestionada, descarga
 * Eclipse Temurin (Adoptium) para la versión requerida.
 */
async function ensureJava(mcVersion, customPath, onProgress) {
  if (customPath) {
    if (!fs.existsSync(customPath)) throw new Error(`No existe Java en: ${customPath}`);
    return customPath;
  }
  const major = requiredJava(mcVersion);
  const root = path.join(app.getPath('userData'), 'runtime', `java-${major}`);
  const existing = findJavaBinary(root);
  if (existing) return existing;

  const { os, arch } = platform();
  const url = `https://api.adoptium.net/v3/binary/latest/${major}/ga/${os}/${arch}/jre/hotspot/normal/eclipse`;
  const isZip = os === 'windows';
  const archive = path.join(app.getPath('temp'), `caldito-java-${major}.${isZip ? 'zip' : 'tar.gz'}`);

  onProgress?.({ task: `Descargando Java ${major}`, done: 0, total: 1 });
  await downloadFile(url, archive, {
    onProgress: (d, t) => onProgress?.({ task: `Descargando Java ${major}`, done: d, total: t || d }),
  });

  onProgress?.({ task: `Instalando Java ${major}`, done: 0, total: 1 });
  await fs.promises.mkdir(root, { recursive: true });
  if (isZip) {
    await require('extract-zip')(archive, { dir: root });
  } else {
    await require('tar').x({ file: archive, cwd: root });
  }
  await fs.promises.rm(archive, { force: true });

  const bin = findJavaBinary(root);
  if (!bin) throw new Error('No se encontró el ejecutable de Java tras instalarlo.');
  if (process.platform !== 'win32') await fs.promises.chmod(bin, 0o755);
  return bin;
}

module.exports = { ensureJava, requiredJava };
