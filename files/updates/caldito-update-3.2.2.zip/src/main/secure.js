'use strict';
// Utilidades criptográficas: códigos de acceso, huellas y cifrado AES-256-GCM.
const crypto = require('crypto');

const ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // sin 0/O ni 1/I para evitar confusiones

function normalize(code) {
  return String(code || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
}

/** Genera un código tipo XXXX-XXXX-XXXX (cada bloque = 4 caracteres de 32 posibles). */
function generateCode(groups = 3, prefix = '') {
  const parts = [];
  for (let g = 0; g < groups; g++) {
    let s = '';
    for (let i = 0; i < 4; i++) s += ALPHABET[crypto.randomInt(ALPHABET.length)];
    parts.push(s);
  }
  return (prefix ? prefix + '-' : '') + parts.join('-');
}

const randomId = () => crypto.randomBytes(6).toString('hex');
const randomSalt = () => crypto.randomBytes(16).toString('hex');

/** Huella del código (lo que se guarda en los datos compartidos). */
function hashCode(code, salt) {
  return crypto.createHash('sha256').update(`${salt}:${normalize(code)}`).digest('hex');
}

function deriveKey(code, salt) {
  return crypto.pbkdf2Sync(normalize(code), Buffer.from(salt, 'hex'), 150000, 32, 'sha256');
}

function encrypt(key, value) {
  const iv = crypto.randomBytes(12);
  const c = crypto.createCipheriv('aes-256-gcm', key, iv);
  const data = Buffer.concat([c.update(JSON.stringify(value), 'utf8'), c.final()]);
  return { iv: iv.toString('base64'), tag: c.getAuthTag().toString('base64'), data: data.toString('base64') };
}

function decrypt(key, box) {
  const d = crypto.createDecipheriv('aes-256-gcm', key, Buffer.from(box.iv, 'base64'));
  d.setAuthTag(Buffer.from(box.tag, 'base64'));
  const out = Buffer.concat([d.update(Buffer.from(box.data, 'base64')), d.final()]);
  return JSON.parse(out.toString('utf8'));
}

function safeEqual(a, b) {
  const x = Buffer.from(String(a)), y = Buffer.from(String(b));
  return x.length === y.length && crypto.timingSafeEqual(x, y);
}

/* ---------- códigos de jugador verificables en cualquier PC ---------- */
// 12 caracteres = 60 bits: 6 bits de "versión" del código (para poder regenerarlo) + 54 bits de firma HMAC del nombre.
const PASS_KEY = require('./passkey');

function passCode(name, gen = 0) {
  gen = Number(gen) & 63;
  const mac = crypto.createHmac('sha256', PASS_KEY).update(`caldito-pass:${String(name).toLowerCase()}:${gen}`).digest();
  let v = (BigInt(gen) << 54n) | (BigInt('0x' + mac.subarray(0, 7).toString('hex')) >> 2n);
  let out = '';
  for (let i = 0; i < 12; i++) { out = ALPHABET[Number(v & 31n)] + out; v >>= 5n; }
  return out.match(/.{4}/g).join('-');
}

/** Devuelve la versión del código si es válido para ese nombre, o -1. */
function verifyPass(name, code) {
  const c = normalize(code);
  if (c.length !== 12) return -1;
  let v = 0n;
  for (const ch of c) {
    const i = ALPHABET.indexOf(ch);
    if (i < 0) return -1;
    v = (v << 5n) | BigInt(i);
  }
  const gen = Number(v >> 54n);
  return safeEqual(normalize(passCode(name, gen)), c) ? gen : -1;
}

/* ---------- códigos de equipo (moderador / desarrollador) válidos en cualquier PC ---------- */
// El código lleva dentro la llave del equipo (la misma en todos los launchers), el rol, el nombre y una firma.
// Va ofuscado con la llave del launcher para que no se lea a simple vista.
function b32(buf) {
  let bits = 0, val = 0, out = '';
  for (const byte of buf) {
    val = (val << 8) | byte; bits += 8;
    while (bits >= 5) { out += ALPHABET[(val >>> (bits - 5)) & 31]; bits -= 5; }
  }
  if (bits > 0) out += ALPHABET[(val << (5 - bits)) & 31];
  return out;
}
function unb32(str) {
  let bits = 0, val = 0; const out = [];
  for (const ch of str) {
    const i = ALPHABET.indexOf(ch);
    if (i < 0) return null;
    val = ((val << 5) | i) & 0xffff; bits += 5;
    if (bits >= 8) { out.push((val >>> (bits - 8)) & 255); bits -= 8; }
  }
  return Buffer.from(out);
}
function teamStream(buf) {
  const key = crypto.createHash('sha256').update(Buffer.concat([Buffer.from('caldito-team-ofuscacion'), PASS_KEY])).digest();
  const c = crypto.createCipheriv('aes-256-ctr', key, Buffer.alloc(16, 7));
  return Buffer.concat([c.update(buf), c.final()]);
}

function encodeTeam({ id, role, gen, name }, devKey) {
  const idb = Buffer.from(String(id).padStart(12, '0').slice(-12), 'hex');
  let nb = Buffer.from(String(name), 'utf8');
  if (nb.length > 30) nb = nb.subarray(0, 30);
  const head = Buffer.concat([Buffer.from([1, role === 'mod' ? 1 : 0, Number(gen) & 255]), idb, devKey, Buffer.from([nb.length]), nb]);
  const mac = crypto.createHmac('sha256', devKey).update(Buffer.concat([Buffer.from('caldito-team'), head])).digest().subarray(0, 6);
  const body = b32(teamStream(Buffer.concat([head, mac])));
  return 'CALDO-' + body.match(/.{1,6}/g).join('-');
}

/** Lee un código de equipo largo. Devuelve { id, role, gen, name, devKey } o null. */
function decodeTeam(code) {
  let c = normalize(code);
  if (!c.startsWith('CALDO') || c.length < 60) return null;
  const raw = unb32(c.slice(5));
  if (!raw || raw.length < 3 + 6 + 32 + 1 + 6) return null;
  const buf = teamStream(raw);
  if (buf[0] !== 1) return null;
  const nlen = buf[3 + 6 + 32];
  const end = 3 + 6 + 32 + 1 + nlen;
  if (buf.length < end + 6) return null;
  const head = buf.subarray(0, end), mac = buf.subarray(end, end + 6);
  const devKey = Buffer.from(buf.subarray(9, 41));
  const want = crypto.createHmac('sha256', devKey).update(Buffer.concat([Buffer.from('caldito-team'), head])).digest().subarray(0, 6);
  if (!crypto.timingSafeEqual(want, Buffer.from(mac))) return null;
  return {
    role: buf[1] === 1 ? 'mod' : 'dev', gen: buf[2], id: buf.subarray(3, 9).toString('hex'),
    devKey, name: buf.subarray(42, end).toString('utf8'),
  };
}

module.exports = { encodeTeam, decodeTeam, passCode, verifyPass, normalize, generateCode, randomId, randomSalt, hashCode, deriveKey, encrypt, decrypt, safeEqual };
