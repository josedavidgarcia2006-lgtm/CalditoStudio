'use strict';
// Menús de Caldito Permadeath (FancyMenu) y pantalla de carga de Caldito Studio (Drippy Loading Screen).
//
//  · Menú principal: la sala de alquimia, con sus botones interactivos y animaciones.
//  · Conexión, carga del mundo, desconexión y mensajes: la luna púrpura.
//  · Ajustes: el grimorio, con los controles reales de Minecraft colocados en sus huecos.
//  · Resto de menús: fondos de la misma ilustración y botones, deslizadores y listas en morado
//    (estos últimos con el "estilo" de caldito-estilo.jar, que se copia a la carpeta mods).
//
// Todo se escribe en la instancia al pulsar JUGAR, así que cada jugador lo tiene sin configurar nada.
// Si el equipo publica su propia configuración de FancyMenu desde el launcher, se usa esa en su lugar.
const fs = require('fs');
const path = require('path');

const ASSETS = path.join(__dirname, '..', 'game', 'fancymenu', 'assets');
const STYLE_JAR = path.join(__dirname, '..', 'game', 'estilo', 'caldito-estilo.jar');
const STYLE_JAR_NAME = 'caldito-estilo.jar';
const A = (f) => `[source:local]config/fancymenu/assets/caldito/${f}`;

/* ------------------------------------------------------------------ formato de FancyMenu */
function container(type, props) {
  return `${type} {\n${Object.entries(props).map(([k, v]) => `  ${k} = ${v}`).join('\n')}\n}`;
}
// Sin desenfoque ni capa oscura de Minecraft 1.21 sobre nuestras ilustraciones.
const NO_BLUR = { show_screen_background_overlay_on_custom_background: false, apply_vanilla_background_blur: false };
function layout(identifier, parts, { behindVanilla = false } = {}) {
  const meta = container('layout-meta', {
    identifier, render_custom_elements_behind_vanilla: behindVanilla, last_edited_time: Date.now(), is_enabled: true,
    widget_identifier_revision: 2, randommode: false, randomgroup: 1, randomonlyfirsttime: false, layout_index: 0,
    ...NO_BLUR,
  });
  return `type = fancymenu_layout\n\n${[meta, ...parts].join('\n\n')}\n`;
}
const background = (file) => [
  container('menu_background', {
    instance_identifier: 'caldito_background', background_type: 'image', image_path: A(file),
    slide: false, repeat_texture: false, parallax: false, invert_parallax: false, restart_animated_on_menu_load: false,
  }),
  container('customization', { action: 'backgroundoptions', keepaspectratio: false }),
];
const hide = (id) => container('vanilla_button', { element_type: 'vanilla_button', instance_identifier: id, is_hidden: true });

/*
 * Posición proporcional a la ilustración (1672x941 px), que se estira a toda la pantalla:
 * así cada botón y cada animación quedan encima de su dibujo en cualquier tamaño de ventana.
 */
const ART_W = 1672;
const ART_H = 941;
const calc = (expr) => `{"placeholder":"calc","values":{"expression":"${expr}","decimal":"false"}}`;
const GW = '{"placeholder":"guiwidth"}';
const GH = '{"placeholder":"guiheight"}';
function onArt(x0, y0, x1, y1) {
  return {
    anchor_point: 'top-left', sticky_anchor: false, x: 0, y: 0, width: 100, height: 20,
    advanced_posx: calc(`${GW}*${x0}/${ART_W}`), advanced_posy: calc(`${GH}*${y0}/${ART_H}`),
    advanced_width: calc(`${GW}*${x1 - x0}/${ART_W}`), advanced_height: calc(`${GH}*${y1 - y0}/${ART_H}`),
  };
}
const artImage = (id, file, box) => container('element', { element_type: 'image', instance_identifier: id, ...onArt(...box), source: A(file) });
function artButton(id, hoverFile, box, action, value = '') {
  return container('element', {
    element_type: 'custom_button', instance_identifier: id, ...onArt(...box), label: '',
    backgroundnormal: A('transparente.png'), backgroundhovered: A(hoverFile), navigatable: true,
    [`[executable_action_instance:${id}_action][action_type:${action}]`]: value,
  });
}
const moveVanilla = (id, box) => container('vanilla_button', { element_type: 'vanilla_button', instance_identifier: id, ...onArt(...box) });

/* ------------------------------------------------------------------ menú principal: sala de alquimia */
// Coordenadas en la ilustración (las mismas que usa tools/make-menu-art.py).
const SALA = {
  entrar: [165, 300, 526, 456],
  opciones: [165, 519, 526, 623],
  salir: [194, 686, 497, 792],
  velas: [[674, 430], [719, 468], [1153, 681]],
  caldero: [790, 430, 960, 640],
  pocion: [585, 555, 700, 690],
  luna: [1240, 157, 74],
  ventana: [800, 60, 1460, 600],
};

function titleScreen(inst) {
  const port = Number(inst.port) || 25565;
  const address = port === 25565 ? inst.host : `${inst.host}:${port}`;
  const [lx, ly, lr] = SALA.luna;
  const halo = lr + 56;
  return layout('title_screen', [
    ...background('sala.png'),
    ...['singleplayer', 'multiplayer', 'realms', 'options', 'quit', 'language', 'accessibility', 'playdemo'].map((b) => hide(`mc_titlescreen_${b}_button`)),
    hide('titlescreen_mods_button'),
    hide('minecraft_logo_widget'), hide('minecraft_splash_widget'), hide('minecraft_branding_widget'), hide('minecraft_realms_notification_icons_widget'),
    // Animaciones (capas transparentes sobre la ilustración, que no se modifica)
    artImage('caldito_anim_luna', 'anim_luna.apng', [lx - halo, ly - halo, lx + halo, ly + halo]),
    artImage('caldito_anim_relampago', 'anim_relampago.apng', SALA.ventana),
    ...SALA.velas.map(([x, y], i) => artImage(`caldito_anim_vela${i + 1}`, `anim_vela${i + 1}.apng`, [x - 40, y - 48, x + 40, y + 48])),
    artImage('caldito_anim_caldero', 'anim_caldero.apng', SALA.caldero),
    artImage('caldito_anim_pocion', 'anim_pocion.apng', SALA.pocion),
    artImage('caldito_anim_motas', 'anim_motas.apng', [0, 0, ART_W, ART_H]),
    // Botones dibujados en la estantería: brillan al pasar el ratón
    artButton('caldito_btn_entrar', 'btn_entrar_hover.png', SALA.entrar, 'joinserver', address),
    artButton('caldito_btn_opciones', 'btn_opciones_hover.png', SALA.opciones, 'opengui', 'options_screen'),
    artButton('caldito_btn_salir', 'btn_salir_hover.png', SALA.salir, 'quitgame'),
  ]);
}

/* ------------------------------------------------------------------ ajustes: grimorio */
// El fondo es el grimorio sin sus recuadros; cada control de Minecraft lleva como textura su recuadro del libro
// (sin el texto), más grande y en filas iguales. Coordenadas: NUEVOS en tools/make-menu-art.py.
const GRIMORIO = [
  ['fov', [366, 214, 820, 284], ['fancymenu_options_options.generic_value', 'fancymenu_options_options.fov'], true],
  ['online', [861, 214, 1310, 284], ['fancymenu_options_context_button', 'fancymenu_options_options.online']],
  ['skin', [357, 290, 820, 360], ['fancymenu_options_options.skincustomisation']],
  ['sonidos', [861, 290, 1320, 360], ['fancymenu_options_options.sounds']],
  ['video', [348, 366, 820, 436], ['fancymenu_options_options.video']],
  ['controles', [861, 366, 1329, 436], ['fancymenu_options_options.controls']],
  ['idioma', [340, 442, 820, 512], ['fancymenu_options_options.language']],
  ['chat', [861, 442, 1339, 512], ['fancymenu_options_options.chat']],
  ['recursos', [331, 518, 820, 588], ['fancymenu_options_options.resourcepack']],
  ['accesibilidad', [861, 518, 1348, 588], ['fancymenu_options_options.accessibility']],
  ['telemetria', [322, 594, 820, 664], ['fancymenu_options_options.telemetry']],
  ['creditos', [861, 594, 1358, 664], ['fancymenu_options_options.credits_and_attribution']],
  ['hecho', [548, 676, 1126, 750], ['fancymenu_options_gui.done']],
];
function grimButton(id, name, box, slider) {
  const tex = slider
    ? { backgroundnormal: A('grim_palanca.png'), backgroundhovered: A('grim_palanca_hover.png'),
        slider_background_texture_normal: A('grim_fov.png'), slider_background_texture_highlighted: A('grim_fov.png') }
    : { backgroundnormal: A(`grim_${name}.png`), backgroundhovered: A(`grim_${name}_hover.png`), background_texture_inactive: A(`grim_${name}_inactivo.png`) };
  return container('vanilla_button', {
    element_type: 'vanilla_button', instance_identifier: id, ...onArt(...box),
    ...tex, nine_slice_custom_background: false, restartbackgroundanimations: true,
  });
}
function optionsScreen() {
  // Escala de interfaz automática solo en esta pantalla: el texto queda proporcional a los botones del libro
  // (los botones ya se colocan en proporción a la ilustración, así que solo crece la letra).
  const parts = [...background('grimorio_ajustes.png'), hide('fancymenu_options_options.title'),
    // FancyMenu solo aplica la escala automática si además hay una escala fija (base 1).
    container('customization', { action: 'setscale', scale: 1 }),
    container('customization', { action: 'autoscale', basewidth: 560, baseheight: 315 })];
  for (const [name, box, ids, slider] of GRIMORIO) for (const id of ids) parts.push(grimButton(id, name, box, slider));
  return layout('options_screen', parts);
}

/* ------------------------------------------------------------------ pantallas y sus clases */
// identificador de FancyMenu → [clase en el juego (Fabric), clase con nombres de desarrollo]
const SCREENS = {
  title_screen: ['net.minecraft.class_442', 'net.minecraft.client.gui.screen.TitleScreen'],
  options_screen: ['net.minecraft.class_429', 'net.minecraft.client.gui.screen.option.OptionsScreen'],
  // Luna púrpura: conexión, carga del mundo, desconexión y mensajes de espera
  connect_screen: ['net.minecraft.class_412', 'net.minecraft.client.gui.screen.multiplayer.ConnectScreen'],
  receiving_level_screen: ['net.minecraft.class_434', 'net.minecraft.client.gui.screen.DownloadingTerrainScreen'],
  disconnected_screen: ['net.minecraft.class_419', 'net.minecraft.client.gui.screen.DisconnectedScreen'],
  level_loading_screen: ['net.minecraft.class_3928', 'net.minecraft.client.gui.screen.world.LevelLoadingScreen'],
  progress_screen: ['net.minecraft.class_435', 'net.minecraft.client.gui.screen.ProgressScreen'],
  generic_dirt_message_screen: ['net.minecraft.class_424', 'net.minecraft.client.gui.screen.MessageScreen'],
  generic_waiting_screen: ['net.minecraft.class_7534', 'net.minecraft.client.gui.screen.TaskScreen'],
  // Submenús de ajustes: grimorio difuminado
  video_settings_screen: ['net.minecraft.class_446', 'net.minecraft.client.gui.screen.option.VideoOptionsScreen'],
  sound_options_screen: ['net.minecraft.class_443', 'net.minecraft.client.gui.screen.option.SoundOptionsScreen'],
  controls_screen: ['net.minecraft.class_458', 'net.minecraft.client.gui.screen.option.ControlsOptionsScreen'],
  language_select_screen: ['net.minecraft.class_426', 'net.minecraft.client.gui.screen.option.LanguageOptionsScreen'],
  skin_customization_screen: ['net.minecraft.class_440', 'net.minecraft.client.gui.screen.option.SkinOptionsScreen'],
  accessibility_options_screen: ['net.minecraft.class_4189', 'net.minecraft.client.gui.screen.option.AccessibilityOptionsScreen'],
  chat_options_screen: ['net.minecraft.class_404', 'net.minecraft.client.gui.screen.option.ChatOptionsScreen'],
  mouse_settings_screen: ['net.minecraft.class_4288', 'net.minecraft.client.gui.screen.option.MouseOptionsScreen'],
  online_options_screen: ['net.minecraft.class_6777', 'net.minecraft.client.gui.screen.option.OnlineOptionsScreen'],
  credits_and_attribution_screen: ['net.minecraft.class_8219', 'net.minecraft.client.gui.screen.option.CreditsAndAttributionScreen'],
  telemetry_info_screen: ['net.minecraft.class_7944', 'net.minecraft.client.gui.screen.option.TelemetryInfoScreen'],
  pack_selection_screen: ['net.minecraft.class_5375', 'net.minecraft.client.gui.screen.pack.PackScreen'],
  // Multijugador y avisos: luna difuminada
  join_multiplayer_screen: ['net.minecraft.class_500', 'net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen'],
  direct_join_server_screen: ['net.minecraft.class_420', 'net.minecraft.client.gui.screen.multiplayer.DirectConnectScreen'],
  edit_server_screen: ['net.minecraft.class_422', 'net.minecraft.client.gui.screen.multiplayer.AddServerScreen'],
  confirm_screen: ['net.minecraft.class_410', 'net.minecraft.client.gui.screen.ConfirmScreen'],
  confirm_link_screen: ['net.minecraft.class_407', 'net.minecraft.client.gui.screen.ConfirmLinkScreen'],
  alert_screen: ['net.minecraft.class_403', 'net.minecraft.client.gui.screen.NoticeScreen'],
  popup_screen: ['net.minecraft.class_8816', 'net.minecraft.client.gui.screen.PopupScreen'],
  // Dentro de la partida: velo sobre el mundo, detrás de los botones
  pause_screen: ['net.minecraft.class_433', 'net.minecraft.client.gui.screen.GameMenuScreen'],
  death_screen: ['net.minecraft.class_418', 'net.minecraft.client.gui.screen.DeathScreen'],
};
const LUNA = ['connect_screen', 'receiving_level_screen', 'disconnected_screen', 'level_loading_screen', 'progress_screen', 'generic_dirt_message_screen', 'generic_waiting_screen'];
const AJUSTES = ['video_settings_screen', 'sound_options_screen', 'controls_screen', 'language_select_screen', 'skin_customization_screen', 'accessibility_options_screen',
  'chat_options_screen', 'mouse_settings_screen', 'online_options_screen', 'credits_and_attribution_screen', 'telemetry_info_screen', 'pack_selection_screen'];
const LUNA_DIFUMINADA = ['join_multiplayer_screen', 'direct_join_server_screen', 'edit_server_screen', 'confirm_screen', 'confirm_link_screen', 'alert_screen', 'popup_screen'];

const simpleScreen = (identifier, file) => layout(identifier, background(file));

/** Todos los diseños de Caldito: nombre de archivo → contenido. */
function allLayouts(inst) {
  const out = {
    'caldito_menu_principal.txt': titleScreen(inst),
    'caldito_ajustes.txt': optionsScreen(),
    'caldito_pantalla_carga.txt': loadingScreen(),
  };
  for (const id of LUNA) out[`caldito_luna_${id}.txt`] = simpleScreen(id, 'conexion.png');
  for (const id of AJUSTES) out[`caldito_grimorio_${id}.txt`] = simpleScreen(id, 'fondo_ajustes.jpg');
  for (const id of LUNA_DIFUMINADA) out[`caldito_menu_${id}.txt`] = simpleScreen(id, 'fondo_luna.jpg');
  out['caldito_pausa.txt'] = layout('pause_screen', [artImage('caldito_velo_pausa', 'velo_pausa.png', [0, 0, ART_W, ART_H])], { behindVanilla: true });
  out['caldito_muerte.txt'] = layout('death_screen', [artImage('caldito_velo_muerte', 'velo_muerte.png', [0, 0, ART_W, ART_H])], { behindVanilla: true });
  return out;
}

/**
 * FancyMenu solo personaliza las pantallas apuntadas en customizablemenus.txt (también el menú principal).
 * Se añaden las de Caldito sin tocar las que el jugador haya activado por su cuenta.
 */
function enableScreens(fm) {
  const file = path.join(fm, 'customizablemenus.txt');
  let text = '';
  try { text = fs.readFileSync(file, 'utf8'); } catch {}
  if (!/type\s*=\s*customizablemenus/.test(text)) text = 'type = customizablemenus\n';
  for (const classes of Object.values(SCREENS)) {
    for (const cls of classes) {
      if (!new RegExp(`^\\s*${cls.replace(/\./g, '\\.')}\\s*\\{`, 'm').test(text)) text = text.replace(/\s*$/, '') + `\n\n${cls} {\n}\n`;
    }
  }
  fs.writeFileSync(file, text);
}

/* ------------------------------------------------------------------ pantalla de carga (Drippy) */
function loadingScreen() {
  return `type = fancymenu_layout\n\n${[
    container('layout-meta', {
      identifier: 'drippy_loading_overlay', render_custom_elements_behind_vanilla: false, last_edited_time: Date.now(), is_enabled: true,
      widget_identifier_revision: 2, randommode: false, randomgroup: 1, randomonlyfirsttime: false, layout_index: 0,
    }),
    container('menu_background', {
      instance_identifier: 'caldito_loading_background', background_type: 'image', image_path: A('carga_fondo.jpg'),
      slide: false, repeat_texture: false, parallax: false, invert_parallax: false, restart_animated_on_menu_load: false,
    }),
    container('customization', { action: 'backgroundoptions', keepaspectratio: false }),
    hide('mojang_logo'),
  ].join('\n\n')}\n`;
}

/**
 * Ajusta options.txt de FancyMenu. La barra de edición nunca se ve al entrar:
 *  · Staff (moderadores y desarrolladores): se abre y se cierra con Ctrl + Alt + C.
 *  · Jugadores: "modo modpack", sin barra ni atajos, así no pueden ver ni tocar el editor.
 */
function patchOptions(dir, staff) {
  const file = path.join(dir, 'options.txt');
  const want = { show_customization_overlay: 'false', modpack_mode: staff ? 'false' : 'true', show_welcome_screen: 'false' };
  let text = '';
  try { text = fs.readFileSync(file, 'utf8'); } catch {}
  if (!text) {
    text = `##[customization]\n\nB:modpack_mode = '${want.modpack_mode}';\nB:show_customization_overlay = 'false';\n\n##[tutorial]\n\nB:show_welcome_screen = 'false';\n`;
  } else {
    for (const [k, v] of Object.entries(want)) {
      const re = new RegExp(`(B:${k}\\s*=\\s*')(true|false)(';)`);
      text = re.test(text) ? text.replace(re, `$1${v}$3`) : text + `\nB:${k} = '${v}';\n`;
    }
  }
  fs.writeFileSync(file, text);
}

/** Copia (o quita) el estilo morado de botones, deslizadores y listas. */
function installStyle(gameDir, enabled) {
  const target = path.join(gameDir, 'mods', STYLE_JAR_NAME);
  if (!enabled) { fs.rmSync(target, { force: true }); return; }
  fs.mkdirSync(path.dirname(target), { recursive: true });
  let same = false;
  try { same = fs.statSync(target).size === fs.statSync(STYLE_JAR).size && fs.readFileSync(target).equals(fs.readFileSync(STYLE_JAR)); } catch {}
  if (!same) fs.copyFileSync(STYLE_JAR, target);
}

/**
 * Escribe la configuración de Caldito en la instancia.
 * customLayouts = true cuando el equipo publicó su propia configuración (entonces solo se tocan las opciones).
 */
function prepare(gameDir, inst, { staff = false, customLayouts = false } = {}) {
  const fm = path.join(gameDir, 'config', 'fancymenu');
  const assets = path.join(fm, 'assets', 'caldito');
  const layouts = path.join(fm, 'customization');
  fs.mkdirSync(assets, { recursive: true });
  fs.mkdirSync(layouts, { recursive: true });
  for (const f of fs.readdirSync(ASSETS)) fs.copyFileSync(path.join(ASSETS, f), path.join(assets, f));
  installStyle(gameDir, true);
  if (!customLayouts) {
    const wanted = allLayouts(inst);
    // Quita diseños de Caldito de versiones anteriores que ya no se usan
    for (const f of fs.readdirSync(layouts)) {
      if (f.startsWith('caldito_') && f.endsWith('.txt') && !(f in wanted)) fs.rmSync(path.join(layouts, f), { force: true });
    }
    for (const [f, text] of Object.entries(wanted)) fs.writeFileSync(path.join(layouts, f), text);
    enableScreens(fm);
  }
  patchOptions(fm, staff);
}

/** Instancia sin menú de Caldito: se quita el estilo para que no quede a medias. */
function remove(gameDir) {
  installStyle(gameDir, false);
}

module.exports = { prepare, remove, titleScreen, optionsScreen, loadingScreen, allLayouts, enableScreens, SCREENS };
