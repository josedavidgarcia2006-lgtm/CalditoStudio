'use strict';
/* =====================================================================
   Caldito Launcher · núcleo de la interfaz (todos los usuarios)
   ===================================================================== */
const api = window.caldito;
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];

const S = {
  view: null,       // lo que manda el proceso principal (datos publicados + sesión)
  draft: null,      // copia en edición de la personalización (solo devs)
  pc: null, presets: {}, fonts: [], defaults: null, appVersion: '',
  status: null, statuses: {}, busy: false, running: false, logs: [], current: 'home',
  instanceId: '', updateInfo: null,
};
const CA = (window.CA = { S, $, $$, hooks: {} });

/* ---------- utilidades ---------- */
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const clone = (o) => JSON.parse(JSON.stringify(o));
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const fmtDate = (d) => { const x = new Date(String(d || '').slice(0, 10) + 'T12:00:00'); return isNaN(x) ? '' : x.toLocaleDateString('es', { day: 'numeric', month: 'short', year: 'numeric' }); };
const gb = (mb) => (mb / 1024).toFixed(mb % 1024 ? 1 : 0) + ' GB';
const isDev = () => S.view?.session?.role === 'dev';
const isStaff = () => ['dev', 'mod'].includes(S.view?.session?.role);
Object.assign(CA, { esc, clone, sleep, fmtDate, gb, isDev, isStaff });

/* ---------- instancia elegida ---------- */
function instances() { return (cur().instances || []).filter((i) => i.visible !== false || isStaff()); }
function selInstance() {
  const list = instances();
  return list.find((i) => i.id === S.instanceId) || list[0] || null;
}
const addrOf = (i) => (i ? (Number(i.port) && Number(i.port) !== 25565 ? `${i.host}:${i.port}` : i.host) : '');
Object.assign(CA, { instances, selInstance, addrOf });

function toast(msg, kind = '') {
  const t = $('#toast');
  t.textContent = msg;
  t.className = 'toast show ' + kind;
  clearTimeout(toast._t);
  toast._t = setTimeout(() => t.classList.remove('show'), kind === 'err' ? 5200 : 3200);
}
CA.toast = toast;

/** Ejecuta una acción mostrando errores, y deshabilitando el botón mientras dura. */
async function act(btn, fn, okMsg) {
  if (btn) btn.disabled = true;
  try {
    const r = await fn();
    const msg = typeof okMsg === 'function' ? okMsg(r) : okMsg;
    if (msg) toast(msg, 'ok');
    return r;
  } catch (e) {
    toast(e.message, 'err');
    log('[ERROR] ' + e.message);
    return undefined;
  } finally {
    if (btn) btn.disabled = false;
  }
}
CA.act = act;

/* ---------- modal ---------- */
function openModal({ title, html = '', actions = [], onOpen }) {
  $('#modalTitle').textContent = title;
  $('#modalBody').innerHTML = html;
  const box = $('#modalActions');
  box.innerHTML = '';
  for (const a of actions) {
    const b = document.createElement('button');
    b.className = a.kind || 'ghost';
    b.textContent = a.label;
    b.addEventListener('click', async () => { const keep = await a.onClick?.(b); if (keep !== true) closeModal(); });
    box.appendChild(b);
  }
  $('#modal').hidden = false;
  onOpen?.($('#modalBody'));
}
function closeModal() { $('#modal').hidden = true; }
$('#modalX').addEventListener('click', closeModal);
$('#modal').addEventListener('click', (e) => e.target.id === 'modal' && closeModal());
document.addEventListener('keydown', (e) => { if (e.key === 'Escape') { closeModal(); $('#accountMenu').hidden = true; } });

function confirmBox(title, text, okLabel = 'Aceptar', danger = false) {
  return new Promise((res) => {
    openModal({
      title, html: `<p class="hint">${text}</p>`,
      actions: [{ label: 'Cancelar', onClick: () => res(false) }, { label: okLabel, kind: danger ? 'ghost danger' : 'primary', onClick: () => res(true) }],
    });
    $('#modalX').onclick = () => res(false);
  });
}
function showCode(title, code, hint) {
  openModal({
    title,
    html: `<p class="hint">${hint}</p><div class="code-big${String(code).length > 30 ? ' long' : ''}">${esc(code)}</div>`,
    actions: [{ label: 'Copiar código', kind: 'primary', onClick: () => { navigator.clipboard.writeText(code); toast('Código copiado', 'ok'); return true; } }, { label: 'Listo' }],
  });
}
Object.assign(CA, { openModal, closeModal, confirmBox, showCode });

/* ---------- lo que se está mostrando (borrador del dev o publicado) ---------- */
function cur() { return S.draft || S.view; }
CA.cur = cur;

/* ---------- tema ---------- */
const FONT_STACK = (f, fallback) => (f && f !== 'Sistema' ? `'${f}', ${fallback}` : fallback);
function applyTheme(t) {
  const r = document.documentElement.style;
  for (const [k, v] of Object.entries(t.colors || {})) r.setProperty(`--${k}`, v);
  r.setProperty('--font-display', FONT_STACK(t.fonts?.display, 'system-ui, sans-serif'));
  r.setProperty('--font-body', FONT_STACK(t.fonts?.body, 'system-ui, sans-serif'));
  r.setProperty('--radius', `${t.radius ?? 14}px`);
  r.setProperty('--scale', t.fontScale || 1);
  r.setProperty('--bg-opacity', t.backgroundOpacity ?? 0.25);
  const bg = $('#bgImage');
  if (t.background) { bg.style.backgroundImage = `url("${t.background.replace(/"/g, '%22')}")`; bg.classList.add('on'); }
  else { bg.style.backgroundImage = ''; bg.classList.remove('on'); }
  document.body.classList.toggle('no-anim', t.animations === false);
  renderLogos(t.logo);
}
CA.renderLogos = (c) => renderLogos(c);
function renderLogos(custom) {
  for (const slot of $$('[data-logo]')) {
    slot.innerHTML = custom ? `<img src="${esc(custom)}" alt="" />` : window.CALDITO_LOGO;
  }
}

function fillText(str) {
  const i = selInstance();
  return String(str ?? '').replaceAll('{ip}', addrOf(i)).replaceAll('{instance}', i?.name || '').replaceAll('{player}', S.view?.session?.name || '');
}
function applyTexts(t) {
  for (const el of $$('[data-t]')) el.textContent = fillText(t[el.dataset.t] ?? '');
  for (const el of $$('[data-t-split]')) {
    const [first, ...rest] = String(t[el.dataset.tSplit] || '').split(' ');
    el.parentElement.innerHTML = `<b data-t-split="${el.dataset.tSplit}">${esc(first)}</b>${rest.length ? `<span>${esc(rest.join(' '))}</span>` : ''}`;
  }
  const [first, ...rest] = String(t.studioName || '').split(' ');
  $('#splashWordmark').innerHTML = `<b>${esc(first)}</b>${rest.length ? `<span>${esc(rest.join(' '))}</span>` : ''}`;
  document.title = t.appTitle || 'Caldito Launcher';
}
CA.fillText = fillText;

/** Vuelve a pintar todo lo que depende de la personalización. */
function applyAll() {
  const c = cur();
  applyTheme(c.theme);
  applyTexts(c.texts);
  if (!$('#app').hidden) { buildTabs(); renderHome(); renderNews(); renderAccount(); }
}
CA.applyAll = applyAll;

/* ---------- pantalla de carga ---------- */
function splashProgress(p) { $('#splashBar').style.width = `${p}%`; }
async function runSplash(work, cached) {
  const dur = cached?.splash?.durationMs ?? 2600;
  const start = Date.now();
  splashProgress(12);
  const result = await work((p) => splashProgress(p));
  const remaining = Math.max(0, (S.view?.splash?.durationMs ?? dur) - (Date.now() - start));
  splashProgress(100);
  await sleep(remaining + 200);
  $('#splash').classList.add('out');
  document.body.classList.remove('booting');
  return result;
}
CA.previewSplash = async () => {
  const sp = $('#splash');
  $('#splashBarWrap').hidden = cur().splash.showBar === false;
  splashProgress(0);
  sp.classList.remove('out');
  await sleep(50);
  splashProgress(100);
  await sleep(cur().splash.durationMs || 2600);
  sp.classList.add('out');
};

/* ---------- navegación por rol ---------- */
const STAFF_TABS = [['instances', null], ['mods', 'Mods'], ['console', 'Consola']];
const DEV_TABS = [['custom', 'Personalizar'], ['codes', 'Códigos'], ['connection', 'Conexión']];
function allowedViews() {
  const base = ['home', 'news', 'skins', 'repair'];
  if (isStaff()) base.push('instances', 'mods', 'console');
  if (isDev()) base.push('custom', 'codes', 'connection');
  return base;
}
function buildTabs() {
  const t = cur().texts;
  const tabs = [['home', t.navHome || 'Inicio'], ['news', t.navNews || 'Noticias'], ['skins', t.navSkins || 'Skins'],
    ...(isStaff() ? STAFF_TABS.map(([v, l]) => [v, l || t.instancesTitle || 'Instancias']) : []),
    ...(isDev() ? DEV_TABS : [])];
  // Reparar se abre con el botón junto a JUGAR.
  $('#repairDot').hidden = !S.updateInfo?.available;
  $('#tabs').innerHTML = tabs.map(([v, l]) => `<button class="tab ${S.current === v ? 'active' : ''}" data-view="${v}">${esc(l)}</button>`).join('');
  $$('#tabs .tab').forEach((b) => b.addEventListener('click', () => go(b.dataset.view)));
}
function go(view) {
  if (!allowedViews().includes(view)) view = 'home';
  S.current = view;
  $$('#tabs .tab').forEach((t) => t.classList.toggle('active', t.dataset.view === view));
  $$('.view').forEach((v) => v.classList.toggle('active', v.id === `view-${view}`));
  if (view === 'console') renderLog();
  CA.hooks[view]?.();
}
CA.go = go;
document.addEventListener('click', (e) => {
  const g = e.target.closest('[data-goto]');
  if (g) go(g.dataset.goto);
});
$('#repairBtn').addEventListener('click', () => go('repair'));
$$('[data-win]').forEach((b) => b.addEventListener('click', () => api.win[b.dataset.win]()));

/* ---------- login ---------- */
let loginMode = 'player';
function showLogin(msg = '') {
  renderConnectBox();
  $('#app').hidden = true;
  $('#accountChip').hidden = true;
  $('#tabs').innerHTML = '';
  $('#login').hidden = false;
  $('#loginError').textContent = msg;
  document.body.classList.remove('is-dev');
  setTimeout(() => (loginMode === 'player' ? ($('#playerName').value ? $('#playerCode') : $('#playerName')) : $('#devCode')).focus(), 100);
}
$$('[data-login]').forEach((b) => b.addEventListener('click', () => {
  loginMode = b.dataset.login;
  $$('[data-login]').forEach((x) => x.classList.toggle('on', x === b));
  $('#playerForm').hidden = loginMode !== 'player';
  $('#devForm').hidden = loginMode !== 'dev';
  $('#loginError').textContent = '';
  (loginMode === 'player' ? $('#playerCode') : $('#devCode')).focus();
}));
$('#playerName').addEventListener('input', (e) => { e.target.value = e.target.value.replace(/[^A-Za-z0-9_]/g, '').slice(0, 16); });
$('#playerCode').addEventListener('input', (e) => {
  const raw = e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 12);
  e.target.value = raw.match(/.{1,4}/g)?.join('-') || '';
});
$('#devShow').addEventListener('click', () => {
  const i = $('#devCode');
  i.type = i.type === 'password' ? 'text' : 'password';
  $('#devShow').textContent = i.type === 'password' ? 'Mostrar' : 'Ocultar';
});
async function doLogin(form, fn) {
  const btn = $('button[type=submit]', form);
  btn.disabled = true;
  $('#loginError').textContent = '';
  try {
    S.view = await fn();
    enterApp();
  } catch (e) {
    $('#loginError').textContent = e.message;
  } finally {
    btn.disabled = false;
  }
}
$('#playerForm').addEventListener('submit', (e) => { e.preventDefault(); doLogin(e.target, () => api.auth.player($('#playerCode').value, $('#playerName').value.trim())); });
$('#devForm').addEventListener('submit', (e) => { e.preventDefault(); doLogin(e.target, () => api.auth.dev($('#devCode').value, $('#devRemember').checked)); });

function renderConnectBox() {
  const v = S.view;
  const gh = v.sync.provider === 'github';
  $('#connectToggle').textContent = gh ? 'Cambiar de servidor / equipo' : 'Conectar con los datos de tu equipo (opcional)';
  $('#connectForm').hidden = true;
  $('#connectInfo').textContent = gh ? `Conectado a ${v.sync.connectionCode}` : '';
}
$('#connectToggle').addEventListener('click', () => { $('#connectForm').hidden = !$('#connectForm').hidden; $('#connectCode').focus(); });
$('#connectForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const btn = $('button', e.target);
  btn.disabled = true;
  $('#loginError').textContent = '';
  try {
    S.view = await api.auth.connect($('#connectCode').value);
    S.instanceId = '';
    applyAll();
    renderConnectBox();
    $('#connectForm').hidden = true;
    refreshStatus();
    toast('¡Conectado! Ahora escribe tu código de acceso.', 'ok');
    $('#playerCode').focus();
  } catch (err) {
    $('#loginError').textContent = err.message;
  } finally { btn.disabled = false; }
});

function enterApp() {
  $('#login').hidden = true;
  $('#app').hidden = false;
  $('#playerCode').value = '';
  $('#devCode').value = '';
  document.body.classList.toggle('is-dev', isDev());
  document.body.classList.toggle('is-staff', isStaff());
  S.draft = null;
  S.current = 'home';
  applyAll();
  go('home');
  idleDock();
  CA.hooks.enter?.();
  toast(`¡Hola, ${S.view.session.name}!`, 'ok');
}

/* ---------- cuenta ---------- */
function renderAccount() {
  const s = S.view?.session;
  if (!s) return;
  $('#accountChip').hidden = false;
  const initial = (s.name || '?')[0].toUpperCase();
  $('#accountAvatar').textContent = initial;
  $('#menuAvatar').textContent = initial;
  $('#accountName').textContent = s.name;
  $('#menuName').textContent = s.name;
  $('#accountRole').textContent = { dev: 'DEV', mod: 'MOD', player: 'Jugador' }[s.role];
  $('#menuRole').textContent = { dev: 'Desarrollador', mod: 'Moderador', player: 'Jugador' }[s.role];
  const needMs = instances().some((i) => i.authMode === 'microsoft') || !!S.pc?.microsoftName;
  $('#msBlock').hidden = !needMs;
  if (needMs) {
    const n = S.pc?.microsoftName;
    $('#msStatus').textContent = n ? `Cuenta de Minecraft: ${n}` : 'Este servidor requiere una cuenta de Minecraft premium.';
    $('#msLink').textContent = n ? 'Cambiar cuenta de Microsoft' : 'Vincular cuenta de Microsoft';
    $('#msUnlink').hidden = !n;
  }
}
$('#accountChip').addEventListener('click', (e) => {
  e.stopPropagation();
  const m = $('#accountMenu');
  const r = $('#accountChip').getBoundingClientRect();
  m.style.right = `${window.innerWidth - r.right}px`;
  m.hidden = !m.hidden;
});
document.addEventListener('click', (e) => { if (!e.target.closest('#accountMenu')) $('#accountMenu').hidden = true; });
$('#logoutBtn').addEventListener('click', async () => {
  if (S.draft && !(await confirmBox('Cambios sin publicar', 'Si cierras sesión se perderán los cambios de personalización sin publicar.', 'Cerrar sesión', true))) return;
  $('#accountMenu').hidden = true;
  S.view = await api.auth.logout();
  S.draft = null;
  applyAll();
  showLogin();
});
$('#msLink').addEventListener('click', (e) => act(e.currentTarget, async () => {
  const name = await api.auth.microsoft();
  S.pc = await api.pc.get();
  renderAccount();
  return name;
}, (n) => `Cuenta vinculada: ${n}`));
$('#msUnlink').addEventListener('click', (e) => act(e.currentTarget, async () => {
  await api.auth.microsoftUnlink();
  S.pc = await api.pc.get();
  renderAccount();
}, 'Cuenta de Microsoft desvinculada'));

/* ---------- servidor ---------- */
async function refreshStatus() {
  const list = instances();
  await Promise.all(list.map(async (i) => {
    try { S.statuses[i.id] = await api.ping(i.id); } catch { S.statuses[i.id] = { online: false }; }
  }));
  S.status = S.statuses[selInstance()?.id] || null;
  renderStatus();
  renderInstancePick();
}
function renderStatus() {
  S.status = S.statuses[selInstance()?.id] || null;
  const st = S.status, t = cur().texts;
  const on = !!st?.online;
  // Inicio
  $('#srvDot').className = 'dot ' + (st ? (on ? 'on' : 'off') : '');
  $('#srvState').textContent = st ? (on ? t.online : t.offline) : 'Comprobando…';
  $('#srvPlayers').textContent = on ? `${st.players.online}/${st.players.max}` : '–';
  $('#srvPing').textContent = on ? `${st.latency} ms` : '–';
  const v = on ? (/\b1\.\d{1,2}(?:\.\d{1,2})?\b/.exec(st.version)?.[0] || st.version) : '–';
  $('#srvVersion').textContent = v.length > 14 ? v.slice(0, 14) + '…' : v;
  $('#srvMotd').textContent = !st ? '' : on ? (cur().sections.motd ? st.motd.trim() : '') : t.offlineMotd;
  $('#srvSample').innerHTML = on && cur().sections.playerList ? st.players.sample.map((n) => `<span>${esc(n)}</span>`).join('') : '';
  // Login
  const ls = $('#loginStatus');
  $('.dot', ls).className = 'dot ' + (st ? (on ? 'on' : 'off') : '');
  $('.ms-text', ls).textContent = !st ? 'Comprobando servidor…' : on ? `${t.online} · ${st.players.online}/${st.players.max} jugadores` : t.offline;
  CA.hooks.status?.();
}
$('#srvCopy').addEventListener('click', () => { navigator.clipboard.writeText($('#srvCopy').textContent); toast('IP copiada', 'ok'); });
CA.refreshStatus = refreshStatus;

/* ---------- inicio ---------- */
function renderHome() {
  const c = cur(), sec = c.sections, t = c.texts;
  $('#heroEyebrow').textContent = t.heroEyebrow;
  $('#heroEyebrow').hidden = !t.heroEyebrow;
  $('#heroLogo').hidden = !sec.heroLogo;
  $('.steam', $('#heroLogo')).hidden = !sec.steam;
  $$('.splash-logo .steam, .login-logo .steam').forEach((s) => (s.hidden = !sec.steam));
  $('#serverBlock').hidden = !sec.serverStatus;
  $('#srvCopy').textContent = addrOf(selInstance());
  renderInstancePick();

  // Noticias resumidas
  $('#homeNews').hidden = !sec.newsOnHome;
  const items = sortedNews().slice(0, Math.max(1, Number(sec.newsOnHomeCount) || 3));
  $('#newsMini').innerHTML = items.map((n) => `
    <li data-news="${esc(n.id)}">
      <div class="meta">${esc(n.tag || 'Noticia')} · ${esc(fmtDate(n.date))}</div>
      <h4>${esc(n.title)}</h4><p>${esc(n.body)}</p>
    </li>`).join('') || '<li class="empty small">No hay noticias todavía.</li>';
  $$('#newsMini [data-news]').forEach((li) => li.addEventListener('click', () => openNews(li.dataset.news)));

  // Botones rápidos
  const btns = (c.buttons || []).filter((b) => b.visible !== false);
  $('#quickButtons').hidden = !sec.quickButtons || !btns.length;
  $('#quickButtons').innerHTML = btns.map((b, i) => `<button class="ghost" data-qb="${i}">${esc(b.icon || '')} ${esc(b.label)}</button>`).join('');
  $$('#quickButtons [data-qb]').forEach((el) => el.addEventListener('click', () => runButton(btns[+el.dataset.qb])));

  $('#homeSide').hidden = $('#homeNews').hidden && $('#quickButtons').hidden;
  $('.home-grid').classList.toggle('full', $('#homeSide').hidden);
  renderStatus();
  if (!S.busy && !S.running) idleDock();
}
/* ---------- selector de instancias ---------- */
function instIcon(el, i) {
  el.style.backgroundImage = i?.image ? `url("${i.image}")` : '';
  el.textContent = i?.image ? '' : i?.icon || '🎮';
}
function renderInstancePick() {
  const i = selInstance();
  if (!i) return;
  instIcon($('#instPickIcon'), i);
  $('#instPickName').textContent = i.name;
  const st = S.statuses[i.id];
  $('#instPickDot').className = 'dot ' + (st ? (st.online ? 'on' : 'off') : '');
  $('#instPick').classList.toggle('single', instances().length < 2);
}
function renderInstanceMenu() {
  const t = cur().texts;
  $('#instMenu').innerHTML = `<div class="pop-head"><b>${esc(t.instancesTitle || 'Instancias')}</b></div>` + instances().map((i) => {
    const st = S.statuses[i.id];
    const stTxt = !st ? 'Comprobando…' : st.online ? `${st.players.online}/${st.players.max} · ${t.online}` : t.offline;
    return `<button class="inst-opt ${i.id === selInstance()?.id ? 'on' : ''}" data-inst="${esc(i.id)}">
      <span class="inst-icon" data-icon="${esc(i.id)}"></span>
      <span class="meta"><b>${esc(i.name)}${i.visible === false ? ' <span class="pill muted">oculta</span>' : ''}</b><small>${esc(i.description || addrOf(i))}</small></span>
      <span class="st"><span class="dot ${st ? (st.online ? 'on' : 'off') : ''}"></span>${esc(stTxt)}</span></button>`;
  }).join('');
  $$('#instMenu [data-icon]').forEach((el) => instIcon(el, instances().find((x) => x.id === el.dataset.icon)));
  $$('#instMenu [data-inst]').forEach((b) => b.addEventListener('click', () => selectInstance(b.dataset.inst)));
}
function selectInstance(id) {
  S.instanceId = id;
  api.pc.set({ selectedInstance: id }).catch(() => {});
  $('#instMenu').hidden = true;
  renderHome();
  if (!S.busy && !S.running) idleDock();
}
$('#instPick').addEventListener('click', (e) => {
  e.stopPropagation();
  const m = $('#instMenu');
  if (m.hidden) { renderInstanceMenu(); const r = $('#instPick').getBoundingClientRect(); m.style.left = `${r.left}px`; m.style.bottom = `${window.innerHeight - r.top + 8}px`; }
  m.hidden = !m.hidden;
});
document.addEventListener('click', (e) => { if (!e.target.closest('#instMenu')) $('#instMenu').hidden = true; });
CA.renderInstancePick = renderInstancePick;

async function runButton(b) {
  if (!b) return;
  if (b.type === 'folder') return act(null, () => api.openFolder(b.value || 'root', selInstance()?.id));
  return act(null, () => api.openLink(b.value));
}
CA.renderHome = renderHome;

/* ---------- noticias ---------- */
function sortedNews() { return [...(cur().news || [])].sort((a, b) => String(b.date).localeCompare(String(a.date))); }
function renderNews() {
  const items = sortedNews();
  $('#newsList').innerHTML = items.map((n) => `
    <article class="news-card ${n.image ? '' : 'noimg'}" id="news-${esc(n.id)}">
      ${n.image ? `<img src="${esc(n.image)}" alt="" />` : ''}
      <div class="body">
        <span class="tag">${esc(n.tag || 'Noticia')}</span><span class="date">${esc(fmtDate(n.date))}</span>
        <h3>${esc(n.title)}</h3><p>${esc(n.body)}</p>
        ${n.url ? `<button class="link" data-url="${esc(n.url)}">Leer más →</button>` : ''}
      </div>
    </article>`).join('') || '<div class="empty">No hay noticias todavía.</div>';
  $$('#newsList img').forEach((img) => img.addEventListener('error', () => { img.closest('.news-card').classList.add('noimg'); img.remove(); }));
  $$('#newsList [data-url]').forEach((b) => b.addEventListener('click', () => act(null, () => api.openLink(b.dataset.url))));
}
function openNews(id) {
  go('news');
  const el = document.getElementById('news-' + id);
  if (el) { el.scrollIntoView({ behavior: 'smooth', block: 'start' }); el.classList.remove('flash'); void el.offsetWidth; el.classList.add('flash'); }
}
$('#newsEdit').addEventListener('click', () => { go('custom'); CA.openSub?.('newsEd'); });

/* ---------- consola ---------- */
function log(line) {
  line = String(line);
  S.logs.push(line);
  if (S.logs.length > 4000) S.logs.splice(0, 800);
  if (S.current === 'console') {
    const c = $('#console');
    const atBottom = c.scrollTop + c.clientHeight >= c.scrollHeight - 30;
    c.textContent += line.endsWith('\n') ? line : line + '\n';
    if (atBottom) c.scrollTop = c.scrollHeight;
  }
}
function renderLog() {
  const c = $('#console');
  c.textContent = S.logs.map((l) => (l.endsWith('\n') ? l : l + '\n')).join('') || 'Aquí aparecerán los registros al pulsar JUGAR.\n';
  c.scrollTop = c.scrollHeight;
}
CA.log = log;
$('#logClear').addEventListener('click', () => { S.logs = []; renderLog(); });
$('#logCopy').addEventListener('click', () => { navigator.clipboard.writeText(S.logs.join('\n')); toast('Registro copiado', 'ok'); });
$('#logFolder').addEventListener('click', () => act(null, () => api.openFolder('logs', selInstance()?.id)));

/* ---------- jugar ---------- */
function setDock(stage, task, pct) {
  if (stage != null) $('#dockStage').textContent = stage;
  if (task != null) $('#dockTask').innerHTML = task;
  if (pct != null) $('#dockFill').style.width = `${Math.max(0, Math.min(100, pct))}%`;
}
function idleDock() {
  const t = cur().texts;
  const ip = $('#srvCopy').textContent;
  setDock(t.readyTitle, esc(t.readySubtitle || '').replace('{ip}', `<b>${esc(ip)}</b>`).replace('{instance}', esc(selInstance()?.name || '')).replace('{player}', esc(S.view?.session?.name || '')), 0);
  $('#playLabel').textContent = t.play;
  $('#playBtn').disabled = false;
  $('#playBtn').classList.remove('running');
}
api.onStage(({ text }) => setDock(text, '', null));
api.onProgress(({ task, done, total }) => {
  const pct = total ? (done / total) * 100 : 0;
  const extra = total > 10000 ? ` · ${(done / 1048576).toFixed(1)} / ${(total / 1048576).toFixed(1)} MB` : total > 1 ? ` · ${done}/${total}` : '';
  setDock(null, esc(task || '') + extra, pct);
});
api.onLog(log);
api.onWarn?.(({ text }) => { toast(text, 'err'); log('[Caldito] ' + text); });
api.onGame(({ running, code }) => {
  S.running = running;
  const t = cur().texts;
  if (running) {
    setDock(t.runningTitle, esc(fillText(t.runningSubtitle)), 100);
    $('#playLabel').textContent = t.playing;
    $('#playBtn').classList.add('running');
    $('#playBtn').disabled = true;
  } else {
    S.busy = false;
    idleDock();
    if (code && code !== 0) toast(`Minecraft se cerró con código ${code}. ${isDev() ? 'Revisa la consola.' : 'Avisa a un desarrollador.'}`, 'err');
  }
});
$('#playBtn').addEventListener('click', async () => {
  if (S.busy || S.running) return;
  S.busy = true;
  $('#playBtn').disabled = true;
  $('#playLabel').textContent = cur().texts.preparing;
  try {
    await api.play(selInstance()?.id);
  } catch (e) {
    S.busy = false;
    idleDock();
    log('[ERROR] ' + e.message);
    toast(e.message, 'err');
    if (/Microsoft/i.test(e.message)) { $('#accountChip').click(); }
  }
});

/* ---------- refresco periódico (noticias nuevas, códigos revocados…) ---------- */
async function periodicRefresh() {
  if (S.busy) return;
  try {
    const v = await api.refresh();
    if (!v.session && S.view?.session) {
      S.view = v; S.draft = null; applyAll();
      showLogin(v.revoked ? 'Tu acceso fue desactivado. Pide un código nuevo a un desarrollador.' : '');
      return;
    }
    S.view = v;
    S.updateInfo = await api.update.status().catch(() => S.updateInfo);
    if (!S.draft) applyAll();
    CA.hooks.refreshed?.();
  } catch {}
}
CA.periodicRefresh = periodicRefresh;

/* ---------- arranque ---------- */
(async function init() {
  // Antes de nada, aplicamos los valores por defecto para que la carga ya luzca bien.
  renderLogos('');
  const boot = await runSplash(async (progress) => {
    progress(30);
    const b = await api.boot();
    progress(70);
    S.view = b.view; S.pc = b.pc; S.presets = b.presets; S.fonts = b.fonts; S.defaults = b.defaults; S.appVersion = b.appVersion;
    S.defaultInstance = b.defaultInstance; S.updateInfo = b.update; S.instanceId = b.pc.selectedInstance || '';
    applyTheme(S.view.theme);
    applyTexts(S.view.texts);
    $('#splashBarWrap').hidden = S.view.splash.showBar === false;
    await Promise.race([refreshStatus(), sleep(2500)]);
    progress(92);
    return b;
  });
  applyAll();
  if (boot.view.session) enterApp();
  else showLogin();
  if (boot.view.sync.error && boot.view.sync.source !== 'remote') toast('Sin conexión con los datos compartidos: usando la última copia guardada.', 'err');
  else if (boot.update?.available && boot.view.session) setTimeout(() => toast(`Hay una actualización del launcher (${boot.update.published.version}). Ve a ${cur().texts.navRepair || 'Reparar'}.`, 'ok'), 1200);
  else if (boot.update?.note) toast(boot.update.note, 'err');
  setInterval(refreshStatus, 30000);
  setInterval(periodicRefresh, 180000);
})();
