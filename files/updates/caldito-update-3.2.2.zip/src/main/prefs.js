'use strict';
// Ajustes que solo afectan a este PC (no se publican).
const fs = require('fs');
const path = require('path');
const os = require('os');
const { app, safeStorage } = require('electron');

const file = () => path.join(app.getPath('userData'), 'pc-settings.json');
const DEFAULTS = { ramMB: 0, javaPath: '', gameDir: '', width: 1280, height: 720, fullscreen: false, afterLaunch: 'keep', jvmArgs: '', detectedVersion: {}, microsoft: null, activeSkin: null, activeCape: 'none', selectedInstance: '', lastUpdateCheck: null };
let cache = null;

function load() {
  if (!cache) {
    try { cache = { ...DEFAULTS, ...JSON.parse(fs.readFileSync(file(), 'utf8')) }; } catch { cache = { ...DEFAULTS }; }
    // 3.0.1: antes el launcher se ocultaba al abrir Minecraft; ahora se queda abierto.
    if (!cache.keepOpenMigrated) { cache.afterLaunch = 'keep'; cache.keepOpenMigrated = true; save(); }
  }
  return cache;
}
function save() { fs.mkdirSync(path.dirname(file()), { recursive: true }); fs.writeFileSync(file(), JSON.stringify(cache, null, 2)); }

function get() {
  const { microsoft, ...pub } = load();
  return { ...pub, microsoftName: microsoft?.name || null, totalMemMB: Math.floor(os.totalmem() / 1048576), defaultGameDir: defaultGameDir() };
}
function set(patch) {
  load();
  for (const k of ['ramMB', 'javaPath', 'gameDir', 'width', 'height', 'fullscreen', 'afterLaunch', 'jvmArgs', 'detectedVersion', 'activeSkin', 'activeCape', 'selectedInstance', 'cslCache']) if (k in patch) cache[k] = patch[k];
  save();
  return get();
}
function setMicrosoft(acc) {
  load();
  if (acc?.refresh) {
    acc = { ...acc, refresh: safeStorage.isEncryptionAvailable() ? 'enc:' + safeStorage.encryptString(acc.refresh).toString('base64') : 'raw:' + Buffer.from(acc.refresh).toString('base64') };
  }
  cache.microsoft = acc;
  save();
}
function getMicrosoft() {
  const m = load().microsoft;
  if (!m) return null;
  const r = m.refresh || '';
  const refresh = r.startsWith('enc:') ? safeStorage.decryptString(Buffer.from(r.slice(4), 'base64')) : Buffer.from(r.slice(4), 'base64').toString();
  return { ...m, refresh };
}
function defaultGameDir() { return path.join(app.getPath('userData'), 'minecraft'); }
function gameDir() { return load().gameDir || defaultGameDir(); }

/** RAM a usar: la elegida en este PC, o la recomendada por el servidor sin pasar del 60 % del equipo. */
function effectiveRam(serverRam) {
  const total = Math.floor(os.totalmem() / 1048576);
  const chosen = load().ramMB || serverRam || 4096;
  return Math.max(1024, Math.min(chosen, Math.floor(total * 0.6)));
}

/** Carpeta propia de cada instancia (mundos, mods, ajustes); lo pesado se comparte en gameDir(). */
function instanceDir(id) { return path.join(gameDir(), 'instances', String(id).replace(/[^\w.-]/g, '_')); }
function reset() { const ms = load().microsoft; cache = { ...DEFAULTS, microsoft: ms }; save(); return get(); }

module.exports = { get, set, raw: load, setMicrosoft, getMicrosoft, gameDir, instanceDir, effectiveRam, reset };
