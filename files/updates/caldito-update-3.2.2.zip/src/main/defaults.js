'use strict';
// Valores por defecto de todo lo personalizable. Lo que los desarrolladores
// publiquen se mezcla encima de esto, así que añadir campos nuevos aquí es seguro.

const PRESETS = {
  caldito: {
    name: 'Caldito (púrpura)',
    colors: {
      bg: '#0e0914', bg2: '#160e20', surface: '#1d1329', surface2: '#271a37', line: '#3a2850',
      text: '#f6e2d0', muted: '#a993b8', accent: '#c58aff', accent2: '#7b2fd0', accentText: '#fff6ec',
      glow: '#7a2bc0', success: '#7ee0a1', danger: '#ff5d73', logo: '#f6e2d0',
    },
  },
  fogon: {
    name: 'Fogón (naranja)',
    colors: {
      bg: '#17110d', bg2: '#1f1712', surface: '#261c15', surface2: '#2f231a', line: '#3b2c21',
      text: '#f6e7d3', muted: '#b39b84', accent: '#ffc24b', accent2: '#ff7a1a', accentText: '#2a1406',
      glow: '#ff7a1a', success: '#9ccc65', danger: '#e5533d', logo: '#f6e7d3',
    },
  },
  noche: {
    name: 'Noche (azul)',
    colors: {
      bg: '#0a0e17', bg2: '#0f1522', surface: '#151d2e', surface2: '#1c263b', line: '#28354f',
      text: '#e6eefc', muted: '#8d9cb8', accent: '#7cc4ff', accent2: '#3b6fe0', accentText: '#06121f',
      glow: '#2f5fd0', success: '#6fe0b0', danger: '#ff6b81', logo: '#e6eefc',
    },
  },
  menta: {
    name: 'Menta (verde)',
    colors: {
      bg: '#0b120f', bg2: '#101a15', surface: '#15231c', surface2: '#1c2e25', line: '#2a4136',
      text: '#e7f6ee', muted: '#8fb3a1', accent: '#8ff0b5', accent2: '#23a866', accentText: '#05170d',
      glow: '#1f9a5c', success: '#8ff0b5', danger: '#ff6b6b', logo: '#e7f6ee',
    },
  },
  salsa: {
    name: 'Salsa (rojo)',
    colors: {
      bg: '#140a0b', bg2: '#1d0f10', surface: '#271416', surface2: '#331a1d', line: '#4a2529',
      text: '#fbe9e4', muted: '#c19a96', accent: '#ff8f7a', accent2: '#d62839', accentText: '#fff4f1',
      glow: '#b81d2c', success: '#9be08f', danger: '#ff5d5d', logo: '#fbe9e4',
    },
  },
};

const FONTS = ['Montserrat', 'Poppins', 'Nunito', 'Inter', 'Fredoka', 'Rubik', 'Space Grotesk', 'Press Start 2P', 'JetBrains Mono', 'Sistema'];

function defaultInstance() {
  return {
    id: 'principal',
    name: 'Caldito Safio',
    description: 'Servidor principal de Caldito Studio.',
    icon: '🍲',
    image: '',
    color: '',
    visible: true,
    host: 'calditosafio.mcsh.gg',
    port: 25565,
    mcVersion: 'auto',
    fallbackVersion: '1.21.1',
    loader: 'fabric',
    loaderVersion: 'latest',
    authMode: 'offline',
    ramMB: 4096,
    skins: true,           // instala CustomSkinLoader para ver skins y capas de Caldito (Fabric/Quilt)
    menu: true,            // menú Permadeath (FancyMenu) y pantalla de carga de Caldito (Drippy)
    mods: [],
    files: [],             // configuración publicada por el equipo (p. ej. config/fancymenu)
  };
}

function defaults() {
  return {
    schema: 2,
    theme: {
      preset: 'caldito',
      colors: { ...PRESETS.caldito.colors },
      fonts: { display: 'Montserrat', body: 'Nunito' },
      radius: 14,
      fontScale: 1,
      logo: '',              // '' = logo de Caldito Studio; si no, imagen en data URL
      background: '',        // imagen de fondo opcional (data URL o https)
      backgroundOpacity: 0.25,
      animations: true,
    },
    texts: {
      studioName: 'CALDITO STUDIO',
      appTitle: 'Caldito Launcher',
      splashText: 'Calentando el caldo…',
      heroEyebrow: 'Servidor oficial',
      heroTitle: 'Caldito Studio',
      tagline: 'Hecho a fuego lento, servido caliente.',
      play: 'JUGAR',
      preparing: 'CALENTANDO…',
      playing: 'EN JUEGO',
      readyTitle: 'Listo para servir',
      readySubtitle: 'Se conectará directo a {ip}',
      runningTitle: 'Minecraft en marcha',
      runningSubtitle: '¡Buen provecho!',
      newsTitle: 'Del fogón',
      newsPageTitle: 'Noticias',
      online: 'En línea',
      offline: 'Apagado',
      offlineMotd: 'El servidor está apagado ahora mismo. Vuelve a intentarlo en un rato.',
      loginTitle: 'Bienvenido a la cocina',
      loginSubtitle: 'Inicia sesión para entrar al servidor.',
      playerTab: 'Jugador',
      devTab: 'Desarrollador',
      playerHint: 'Escribe tu nombre y el código de acceso que te dio un desarrollador del equipo.',
      devHint: 'Acceso para el equipo de Caldito Studio.',
      navHome: 'Inicio',
      navNews: 'Noticias',
      navSkins: 'Skins',
      navRepair: 'Reparar',
      instancesTitle: 'Instancias',
      footer: '© Caldito Studio',
    },
    sections: {
      serverStatus: true,
      motd: true,
      playerList: true,
      newsOnHome: true,
      newsOnHomeCount: 3,
      quickButtons: true,
      heroLogo: true,
      steam: true,
    },
    splash: { durationMs: 2600, showBar: true },
    buttons: [
      { id: 'b-discord', label: 'Discord', icon: '💬', type: 'link', value: 'https://discord.com', visible: true },
      { id: 'b-folder', label: 'Carpeta del juego', icon: '📁', type: 'folder', value: 'root', visible: true },
      { id: 'b-shots', label: 'Capturas', icon: '🖼️', type: 'folder', value: 'screenshots', visible: true },
    ],
    instances: [defaultInstance()],
    capes: [],               // capas oficiales añadidas por los desarrolladores
    skins: { repo: '', branch: 'main' },
    skinsSecret: null,       // token del repo de skins, cifrado con la llave de jugadores
    playerKeyEnc: null,      // llave de jugadores, cifrada con la llave de desarrolladores
    playerVault: {},         // llave de jugadores, cifrada con el código de cada jugador
    update: null,            // última actualización del launcher publicada
    news: [
      {
        id: 'n-bienvenida',
        title: '¡Bienvenido al launcher de Caldito Studio!',
        date: '2026-11-19',
        tag: 'Anuncio',
        body: 'Desde aquí entras al servidor con un solo clic. El launcher descarga el juego, Java y los mods necesarios por ti.',
        image: '',
        url: '',
      },
    ],
    players: [],
    devs: [],
    vault: {},
    secrets: null,
    updatedAt: null,
    updatedBy: null,
  };
}

module.exports = { defaults, defaultInstance, PRESETS, FONTS };
