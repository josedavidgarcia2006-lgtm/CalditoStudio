'use strict';
// Horas de juego: el launcher cuenta el tiempo con Minecraft abierto y lo publica en el
// repositorio de jugadores (el mismo de las skins) como stats/<nombre>.json.
const fs = require('fs');
const path = require('path');
const { app } = require('electron');
const store = require('./datastore');
const { UA } = require('./download');

const file = () => path.join(app.getPath('userData'), 'playtime.json');
const load = () => { try { return JSON.parse(fs.readFileSync(file(), 'utf8')); } catch { return {}; } };
const save = (d) => { fs.mkdirSync(path.dirname(file()), { recursive: true }); fs.writeFileSync(file(), JSON.stringify(d, null, 2)); };

let session = null; // { name, instance, last }

/** Suma el tiempo transcurrido desde la última marca y lo publica. */
async function flush(final = false) {
  if (!session) return;
  const now = Date.now();
  const secs = Math.max(0, Math.round((now - session.last) / 1000));
  session.last = now;
  const all = load();
  const me = all[session.name] || { totalSeconds: 0, byInstance: {}, sessions: 0, firstPlayed: new Date().toISOString() };
  me.totalSeconds += secs;
  me.byInstance[session.instance] = (me.byInstance[session.instance] || 0) + secs;
  me.lastPlayed = new Date().toISOString();
  if (final) me.sessions += 1;
  all[session.name] = me;
  save(all);
  await publish(session.name, me).catch(() => {});
  if (final) session = null;
}

async function publish(name, me) {
  const gh = store.skinsProvider();
  if (!gh?.token) return; // sin repositorio de jugadores: solo se guarda en este PC
  await gh.putRaw(`stats/${name}.json`, Buffer.from(JSON.stringify({ name, ...me }, null, 2)), `Horas de ${name}`);
}

let timer = null;
function start(name, instance) {
  session = { name, instance, last: Date.now() };
  clearInterval(timer);
  timer = setInterval(() => flush(false), 5 * 60 * 1000);
}
async function stop() {
  clearInterval(timer);
  timer = null;
  await flush(true);
}

/** Para Códigos: horas de todos los jugadores (desde el repositorio o, si no hay, este PC). */
async function list() {
  store.requireDev();
  const out = {};
  for (const [n, v] of Object.entries(load())) out[n.toLowerCase()] = { totalSeconds: v.totalSeconds, lastPlayed: v.lastPlayed, source: 'pc' };
  const d = store.getData();
  if (!d.skins?.repo) return { stats: out, shared: false };
  const gh = store.skinsProvider();
  const res = await fetch(`https://api.github.com/repos/${d.skins.repo}/contents/stats?ref=${encodeURIComponent(d.skins.branch || 'main')}`, {
    headers: { 'User-Agent': UA, Accept: 'application/vnd.github+json', ...(gh?.token ? { Authorization: `Bearer ${gh.token}` } : {}) },
  });
  if (res.status === 404) return { stats: out, shared: true };
  if (!res.ok) throw new Error(`GitHub respondió ${res.status} al leer las horas.`);
  const files = (await res.json()).filter((f) => f.type === 'file' && f.name.endsWith('.json'));
  await Promise.all(files.map(async (f) => {
    try {
      const r = await fetch(`${f.download_url}?t=${Date.now()}`, { headers: { 'User-Agent': UA } });
      const v = await r.json();
      const key = String(v.name || f.name.replace(/\.json$/, '')).toLowerCase();
      out[key] = { totalSeconds: Number(v.totalSeconds) || 0, lastPlayed: v.lastPlayed, sessions: v.sessions, source: 'repo' };
    } catch {}
  }));
  return { stats: out, shared: true };
}

module.exports = { start, stop, flush, list };
