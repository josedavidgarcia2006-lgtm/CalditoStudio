'use strict';
// Dónde viven los datos compartidos del launcher.
//  - local:  un archivo en este PC (para probar; no se comparte).
//  - github: un repositorio público de GitHub. Todos los launchers leen de ahí;
//            solo los desarrolladores (que tienen el token cifrado) pueden escribir.
const fs = require('fs');
const path = require('path');
const { pathToFileURL } = require('url');
const { app } = require('electron');
const { UA } = require('./download');

class LocalProvider {
  constructor() {
    this.kind = 'local';
    this.root = path.join(app.getPath('userData'), 'store');
    this.file = path.join(this.root, 'launcher-data.json');
  }
  async read() {
    try { return JSON.parse(await fs.promises.readFile(this.file, 'utf8')); }
    catch (e) { if (e.code === 'ENOENT') return null; throw e; }
  }
  async write(data) {
    await fs.promises.mkdir(this.root, { recursive: true });
    const tmp = this.file + '.tmp';
    await fs.promises.writeFile(tmp, JSON.stringify(data, null, 2));
    await fs.promises.rename(tmp, this.file);
  }
  async putFile(rel, buffer) {
    const dest = path.join(this.root, 'files', rel);
    await fs.promises.mkdir(path.dirname(dest), { recursive: true });
    await fs.promises.writeFile(dest, buffer);
    return pathToFileURL(dest).href;
  }
  async deleteFile(url) {
    if (url?.startsWith('file:')) await fs.promises.rm(new URL(url), { force: true }).catch(() => {});
  }
}

class GitHubProvider {
  constructor({ repo, branch = 'main', path: p = 'launcher-data.json' }, token = null) {
    if (!/^[\w.-]+\/[\w.-]+$/.test(repo || '')) throw new Error('Repositorio de GitHub inválido. Usa el formato usuario/repositorio.');
    this.kind = 'github';
    this.repo = repo;
    this.branch = branch || 'main';
    this.path = p || 'launcher-data.json';
    this.token = token;
  }
  setToken(t) { this.token = t; }

  headers(extra = {}) {
    const h = { 'User-Agent': UA, 'X-GitHub-Api-Version': '2022-11-28', ...extra };
    if (this.token) h.Authorization = `Bearer ${this.token}`;
    return h;
  }
  api(p) { return `https://api.github.com/repos/${this.repo}/contents/${p.split('/').map(encodeURIComponent).join('/')}`; }
  rawUrl(p) { return `https://raw.githubusercontent.com/${this.repo}/${this.branch}/${p.split('/').map(encodeURIComponent).join('/')}`; }

  async read() {
    const res = await fetch(`${this.api(this.path)}?ref=${encodeURIComponent(this.branch)}`, {
      headers: this.headers({ Accept: 'application/vnd.github.raw+json', 'Cache-Control': 'no-cache' }),
    });
    if (res.status === 404) return null;
    if (res.status === 403 || res.status === 429) {
      // Límite de peticiones anónimas: caemos al CDN de raw (puede ir ~5 min atrasado).
      const r2 = await fetch(this.rawUrl(this.path) + `?t=${Date.now()}`, { headers: { 'User-Agent': UA } });
      if (r2.ok) return r2.json();
    }
    if (!res.ok) throw new Error(`GitHub respondió ${res.status} al leer los datos.`);
    return res.json();
  }

  async sha(p) {
    const res = await fetch(`${this.api(p)}?ref=${encodeURIComponent(this.branch)}`, { headers: this.headers({ Accept: 'application/vnd.github+json' }) });
    if (res.status === 404) return null;
    if (!res.ok) throw new Error(await this.err(res, 'leer'));
    return (await res.json()).sha;
  }

  async err(res, verb) {
    let msg = '';
    try { msg = (await res.json()).message || ''; } catch {}
    if (res.status === 401) return 'El token de GitHub no es válido o caducó.';
    if (res.status === 403 || res.status === 404) return `GitHub no deja ${verb}: revisa que el token tenga permiso "Contents: Read and write" sobre ${this.repo}. ${msg}`;
    return `GitHub respondió ${res.status} al ${verb}. ${msg}`;
  }

  async putRaw(p, buffer, message) {
    if (!this.token) throw new Error('No hay token de GitHub configurado para publicar.');
    const sha = await this.sha(p);
    const put = (withBranch) => fetch(this.api(p), {
      method: 'PUT',
      headers: this.headers({ Accept: 'application/vnd.github+json', 'Content-Type': 'application/json' }),
      body: JSON.stringify({ message, content: Buffer.from(buffer).toString('base64'), ...(withBranch ? { branch: this.branch } : {}), ...(sha ? { sha } : {}) }),
    });
    let res = await put(true);
    // Repositorio recién creado y vacío: la rama aún no existe; GitHub la crea con el primer archivo.
    if (!res.ok && !sha && (res.status === 404 || res.status === 422)) res = await put(false);
    if (!res.ok) throw new Error(await this.err(res, 'escribir'));
  }

  async write(data, message = 'Actualizar launcher') {
    await this.putRaw(this.path, Buffer.from(JSON.stringify(data, null, 2)), message);
  }

  async putFile(rel, buffer) {
    // Los archivos grandes (mods pesados) van a una "release" de GitHub: admite hasta 2 GB por archivo.
    if (buffer.length > 25 * 1024 * 1024) return this.putReleaseAsset(rel, buffer);
    const p = `files/${rel}`;
    await this.putRaw(p, buffer, `Subir ${path.basename(rel)}`);
    return this.rawUrl(p);
  }

  /* ---------- archivos grandes en la release "caldito-archivos" ---------- */
  releaseDownloadPrefix() { return `https://github.com/${this.repo}/releases/download/`; }

  async releaseId() {
    if (this._releaseId) return this._releaseId;
    const tag = 'caldito-archivos';
    const h = this.headers({ Accept: 'application/vnd.github+json' });
    let res = await fetch(`https://api.github.com/repos/${this.repo}/releases/tags/${tag}`, { headers: h });
    if (res.status === 404) {
      const create = () => fetch(`https://api.github.com/repos/${this.repo}/releases`, {
        method: 'POST',
        headers: this.headers({ Accept: 'application/vnd.github+json', 'Content-Type': 'application/json' }),
        body: JSON.stringify({ tag_name: tag, name: 'Archivos del Caldito Launcher', body: 'Mods y archivos grandes que reparte el Caldito Launcher. No borrar.' }),
      });
      res = await create();
      if (res.status === 422) {
        // Repositorio vacío: hace falta un primer archivo para poder crear la release.
        await this.putRaw('files/LEEME.txt', Buffer.from('Archivos del Caldito Launcher.\n'), 'Preparar repositorio');
        res = await create();
      }
    }
    if (!res.ok) throw new Error(await this.err(res, 'escribir'));
    this._releaseId = (await res.json()).id;
    return this._releaseId;
  }

  async releaseAssets(id) {
    const out = [];
    for (let page = 1; page < 30; page++) {
      const res = await fetch(`https://api.github.com/repos/${this.repo}/releases/${id}/assets?per_page=100&page=${page}`, { headers: this.headers({ Accept: 'application/vnd.github+json' }) });
      if (!res.ok) throw new Error(await this.err(res, 'leer'));
      const list = await res.json();
      out.push(...list);
      if (list.length < 100) break;
    }
    return out;
  }

  async putReleaseAsset(rel, buffer) {
    if (!this.token) throw new Error('No hay token de GitHub configurado para publicar.');
    if (buffer.length > 1900 * 1024 * 1024) throw new Error('Archivo demasiado grande (máx. 1,9 GB).');
    const id = await this.releaseId();
    // GitHub cambia los caracteres raros del nombre; lo normalizamos nosotros para conocer el enlace final.
    const name = path.basename(rel).replace(/[^\w.+-]/g, '_');
    for (const a of await this.releaseAssets(id)) {
      if (a.name === name) {
        await fetch(`https://api.github.com/repos/${this.repo}/releases/assets/${a.id}`, { method: 'DELETE', headers: this.headers({ Accept: 'application/vnd.github+json' }) });
      }
    }
    const res = await fetch(`https://uploads.github.com/repos/${this.repo}/releases/${id}/assets?name=${encodeURIComponent(name)}`, {
      method: 'POST',
      headers: this.headers({ Accept: 'application/vnd.github+json', 'Content-Type': 'application/octet-stream' }),
      body: buffer,
    });
    if (!res.ok) throw new Error(await this.err(res, 'subir el archivo'));
    return (await res.json()).browser_download_url;
  }

  async deleteRaw(p, message) {
    const sha = await this.sha(p).catch(() => null);
    if (!sha) return;
    const res = await fetch(this.api(p), {
      method: 'DELETE',
      headers: this.headers({ Accept: 'application/vnd.github+json', 'Content-Type': 'application/json' }),
      body: JSON.stringify({ message: message || `Eliminar ${p}`, sha, branch: this.branch }),
    });
    if (!res.ok) throw new Error(await this.err(res, 'borrar'));
  }

  async deleteFile(url) {
    if (url?.startsWith(this.releaseDownloadPrefix()) && this.token) {
      try {
        const name = decodeURIComponent(url.split('/').pop());
        const id = await this.releaseId();
        for (const a of await this.releaseAssets(id)) {
          if (a.name === name) await fetch(`https://api.github.com/repos/${this.repo}/releases/assets/${a.id}`, { method: 'DELETE', headers: this.headers({ Accept: 'application/vnd.github+json' }) });
        }
      } catch {}
      return;
    }
    const prefix = this.rawUrl('files/');
    if (!url?.startsWith(prefix) || !this.token) return;
    const p = 'files/' + url.slice(prefix.length).split('/').map(decodeURIComponent).join('/');
    const sha = await this.sha(p).catch(() => null);
    if (!sha) return;
    await fetch(this.api(p), {
      method: 'DELETE',
      headers: this.headers({ Accept: 'application/vnd.github+json', 'Content-Type': 'application/json' }),
      body: JSON.stringify({ message: `Eliminar ${path.basename(p)}`, sha, branch: this.branch }),
    }).catch(() => {});
  }

  /** Comprueba que el token puede escribir en el repo. */
  async test() {
    const res = await fetch(`https://api.github.com/repos/${this.repo}`, { headers: this.headers({ Accept: 'application/vnd.github+json' }) });
    if (res.status === 404) throw new Error(`No existe el repositorio ${this.repo} o el token no tiene acceso.`);
    if (!res.ok) throw new Error(await this.err(res, 'leer'));
    const info = await res.json();
    if (info.private) throw new Error('El repositorio es privado: los jugadores no podrían leerlo. Hazlo público (Settings → General → Change visibility).');
    if (this.token && info.permissions && !info.permissions.push) throw new Error('El token no tiene permiso de escritura en el repositorio.');
    return info;
  }
}

module.exports = { LocalProvider, GitHubProvider };
