'use strict';
const { contextBridge, ipcRenderer } = require('electron');

const call = async (ch, ...args) => {
  const r = await ipcRenderer.invoke(ch, ...args);
  if (!r.ok) throw new Error(r.error);
  return r.data;
};
const on = (ch, cb) => {
  const fn = (_e, d) => cb(d);
  ipcRenderer.on(ch, fn);
  return () => ipcRenderer.removeListener(ch, fn);
};

contextBridge.exposeInMainWorld('caldito', {
  win: { minimize: () => ipcRenderer.send('win:minimize'), maximize: () => ipcRenderer.send('win:maximize'), close: () => ipcRenderer.send('win:close') },
  boot: () => call('boot'),
  refresh: () => call('refresh'),
  auth: {
    player: (c, n) => call('auth:player', c, n),
    dev: (c, r) => call('auth:dev', c, r),
    logout: () => call('auth:logout'),
    connect: (c) => call('auth:connect', c),
    microsoft: () => call('auth:microsoft'),
    microsoftUnlink: () => call('auth:microsoftUnlink'),
  },
  ping: (target) => call('server:ping', target),
  play: (instanceId) => call('game:play', instanceId),
  openFolder: (w, inst) => call('folder:open', w, inst),
  openLink: (u) => call('link:open', u),
  pc: { get: () => call('pc:get'), set: (p) => call('pc:set', p), pickDir: () => call('pc:pickDir'), pickJava: () => call('pc:pickJava') },
  skins: {
    list: () => call('skins:list'),
    upload: (kind) => call('skins:upload', kind),
    importName: (n) => call('skins:importName', n),
    update: (id, p) => call('skins:update', id, p),
    remove: (kind, id) => call('skins:remove', kind, id),
    apply: (o) => call('skins:apply', o),
    mojangProfile: () => call('skins:mojangProfile'),
    mojangCape: (id) => call('skins:mojangCape', id),
  },
  update: {
    status: () => call('update:status'),
    install: () => call('update:install'),
    revert: () => call('update:revert'),
    restart: () => call('update:restart'),
    publish: (notes) => call('update:publish', notes),
    retire: () => call('update:retire'),
  },
  repair: { run: (tool, arg) => call('repair:run', tool, arg), diagnostics: () => call('repair:diagnostics') },
  staff: {
    saveInstances: (l) => call('staff:saveInstances', l),
    modContext: (i) => call('staff:modContext', i),
    modSearch: (i, q) => call('staff:modSearch', i, q),
    modAddModrinth: (i, id) => call('staff:modAddModrinth', i, id),
    modAddModrinthMany: (i, ids) => call('staff:modAddModrinthMany', i, ids),
    modUpload: (i) => call('staff:modUpload', i),
    modAddUrl: (i, u) => call('staff:modAddUrl', i, u),
    modRemove: (i, id) => call('staff:modRemove', i, id),
    pickImage: () => call('staff:pickImage'),
    modsFolderScan: (i) => call('staff:modsFolderScan', i),
    modsFolderOpen: (i) => call('staff:modsFolderOpen', i),
    modsFolderPublish: (i) => call('staff:modsFolderPublish', i),
    configPublish: (i) => call('staff:configPublish', i),
    configReset: (i) => call('staff:configReset', i),
  },
  dev: {
    publish: (p) => call('dev:publish', p),
    pickImage: (kb) => call('dev:pickImage', kb),
    pickCape: () => call('dev:pickCape'),
    exportTheme: (j) => call('dev:exportTheme', j),
    importTheme: () => call('dev:importTheme'),
    playerCreate: (n, note) => call('dev:playerCreate', n, note),
    playerUpdate: (id, p) => call('dev:playerUpdate', id, p),
    playerDelete: (id) => call('dev:playerDelete', id),
    devCreate: (n, role) => call('dev:devCreate', n, role),
    devUpdate: (id, p) => call('dev:devUpdate', id, p),
    devDelete: (id) => call('dev:devDelete', id),
    githubConnect: (c) => call('dev:githubConnect', c),
    useLocal: () => call('dev:useLocal'),
    skinsRepo: (c) => call('dev:skinsRepo', c),
    stats: () => call('dev:stats'),
  },
  onStage: (cb) => on('game:stage', cb),
  onProgress: (cb) => on('game:progress', cb),
  onLog: (cb) => on('game:log', cb),
  onGame: (cb) => on('game:game', cb),
  onWarn: (cb) => on('game:warn', cb),
  onUpdateProgress: (cb) => on('update:progress', cb),
  onRepairProgress: (cb) => on('repair:progress', cb),
});
