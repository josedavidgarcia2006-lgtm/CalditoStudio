'use strict';
// Búsqueda e instalación de mods desde Modrinth (API pública v2).
const { fetchJson } = require('./download');

const API = 'https://api.modrinth.com/v2';

async function search(query, mcVersion, loader) {
  const facets = [['project_type:mod'], [`versions:${mcVersion}`]];
  if (loader && loader !== 'vanilla') facets.push([`categories:${loader}`]);
  const url = `${API}/search?limit=24&index=relevance&query=${encodeURIComponent(query || '')}&facets=${encodeURIComponent(JSON.stringify(facets))}`;
  const r = await fetchJson(url);
  return r.hits.map((h) => ({
    id: h.project_id, slug: h.slug, title: h.title, description: h.description,
    icon: h.icon_url, downloads: h.downloads, author: h.author,
    client: h.client_side, server: h.server_side,
  }));
}

async function bestVersion(projectId, mcVersion, loader) {
  const loaders = loader === 'quilt' ? ['quilt', 'fabric'] : [loader];
  const url = `${API}/project/${projectId}/version?loaders=${encodeURIComponent(JSON.stringify(loaders))}&game_versions=${encodeURIComponent(JSON.stringify([mcVersion]))}`;
  const versions = await fetchJson(url);
  return versions.find((v) => v.version_type === 'release') || versions[0] || null;
}

/** Devuelve el mod y sus dependencias obligatorias, listos para publicar. */
async function resolve(projectId, mcVersion, loader, seen = new Set()) {
  if (seen.has(projectId)) return [];
  seen.add(projectId);
  const v = await bestVersion(projectId, mcVersion, loader);
  if (!v) throw new Error(`No hay versión de este mod para Minecraft ${mcVersion} con ${loader}.`);
  const file = v.files.find((f) => f.primary) || v.files[0];
  const project = await fetchJson(`${API}/project/${projectId}`);
  const out = [{
    name: project.title, file: file.filename, url: file.url, sha1: file.hashes.sha1, size: file.size,
    source: 'modrinth', projectId, versionId: v.id, version: v.version_number, icon: project.icon_url || '',
  }];
  for (const dep of v.dependencies || []) {
    if (dep.dependency_type === 'required' && dep.project_id) {
      try { out.push(...(await resolve(dep.project_id, mcVersion, loader, seen))); } catch {}
    }
  }
  return out;
}

module.exports = { search, resolve };
